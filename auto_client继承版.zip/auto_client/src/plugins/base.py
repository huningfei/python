from conf import settings # 导入配置文件
# 类模式
class BasePlugin():# 定义一个基本类去收集系统上面的信息
    def __init__(self):
        self.hostname=settings.HOSTNAME
        self.username=settings.USERNAME
        self.port=settings.PORT
        self.password=settings.PASSWORD

    def exec_cmd(self,cmd):
        if settings.MODE=="AGENT":
            import subprocess
            result=subprocess.getoutput(cmd)
        elif settings.MODE=="SSH":
            import paramiko
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(hostname=self.hostname, port=self.port, username=self.username, password=self.password)
            stdin, stdout, stderr = ssh.exec_command(cmd)
            result = stdout.read()
            ssh.close()
        elif settings.MODE=="SALT":
            import subprocess
            result = subprocess.getoutput('salt "c1.com" cmd.run "%s"' % cmd)
        else:
            raise Exception("模式选择错误：AGENT,SSH,SALT")
        return result

# 这是用的传参的方式
# class Basic():
#     def __init__(self):
#         pass
#     @classmethod
#     def settings(cls):
#         return cls()
#     def process(self,cmd_func,test):
#         if test:
#             output = {
#                 'os_platform': "linux",
#                 'os_version': "CentOS release 6.6 (Final)\nKernel \r on an \m",
#                 'hostname': 'c1.com'
#             }
#         else:
#             output = {
#                 'os_platform': cmd_func("uname").strip(),
#                 'os_version': cmd_func("cat /etc/issue").strip().split('\n')[0],
#                 'hostname': cmd_func("hostname").strip(),
#             }
#         return output
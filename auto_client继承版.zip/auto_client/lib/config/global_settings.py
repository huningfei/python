
TEST = True

NAME = "GAOXU"
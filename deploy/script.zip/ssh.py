import paramiko
from io import StringIO

key_str = """-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAABFwAAAAdzc2gtcn
NhAAAAAwEAAQAAAQEAoiCXmWbF6Mc6ZDLLpSSoypmo0BW9JFUVCdCMCSiXBHg7mP9vtddo
sfEZsmclyB35YJEn+Q6WHpaJzomRqGCqUJ6ZDnl6dAzpf1fuGsD7gp19RWwd3l3RoAMM0a
JTz4mFPCElLc1grpRvSNjJZum4l7ZUHXF1wivyg7+nQ5opdgws465ZXTet+G+0C09y4bII
gLKq/Ql2Pl13lZvR/nk+xV1lujx1s9SnyZIobMNVWG8xh5VMGP+hGECmUrVN2baObBNqS1
bd3lE0dh2EWYuOU7TfuC5K0u4iPkxdzGqS7QMIBbjJF+zCTt8GfksS5j7NhwryLorRuE/+
cQvld4vntwAAA9BWwGG9VsBhvQAAAAdzc2gtcnNhAAABAQCiIJeZZsXoxzpkMsulJKjKma
jQFb0kVRUJ0IwJKJcEeDuY/2+112ix8RmyZyXIHflgkSf5DpYelonOiZGoYKpQnpkOeXp0
DOl/V+4awPuCnX1FbB3eXdGgAwzRolPPiYU8ISUtzWCulG9I2Mlm6biXtlQdcXXCK/KDv6
dDmil2DCzjrlldN634b7QLT3LhsgiAsqr9CXY+XXeVm9H+eT7FXWW6PHWz1KfJkihsw1VY
bzGHlUwY/6EYQKZStU3Zto5sE2pLVt3eUTR2HYRZi45TtN+4LkrS7iI+TF3MapLtAwgFuM
kX7MJO3wZ+SxLmPs2HCvIuitG4T/5xC+V3i+e3AAAAAwEAAQAAAQEAg0QsOlHRz4TvLA1M
gOtLlq4O1lujhnU00Xt+xjONAltutZOrmOlNpTT2f1Gwb3SFYsBkQuyicyWjcgxEWLXbb+
bZObT1hlyl+SryZ8r0WG627Kx7Cn2fqhSOHnV1skVAEM0tUwZET1VzPOH5P0/g20UOmcAx
fgMjGbTk8oExLJepIlIKlliAYlipR/W+mE9I7DKQ3w+ge5wNn7nTWBGN39o+ss9FuFHT/G
BAOCe2eP8+ZqWw1W94nPRpLNcqBPvLRSz6xafSGF9FhEF2celaa5Jv+MBRw5K0zbnH81aJ
jDVl3OYHJ9ODPoe1YcCcgxi5xcWK+0DRgnEA7wCxKc3m8QAAAIB4C/1+YlOOjGAn1/4O24
8Hl56tcGcUuR/dXZZB7tQi4rg0h9dFhDYP5OH7eybqNbzkNW3CcSOUaThRZu6hlP1rcnyC
xW62UNGAHpSdmHr43sZ0DORfAizDg7Co0ovtdbU0T+I5SYTuULKLiKcTDhWsWQ2cwIpYWc
3bgm3mH/24PQAAAIEAzAvPcJomgLNzX2bWbPFdp1IJ4Z3qzC9YzdyE+y9sNtgBlp+upHR0
NbP7OJSAouDJ0IED+HRXxvxyTGUg5Qek1V+nPl6udSFkAi9VUoi0dVfJEDmvChnQhLTOEN
CpLSGv5lm82rZoxcVKJDGUxDf+pJJ8zyaB0LD0f/V44eykmAUAAACBAMtoawdn1t+egT+n
F6RUDbQoQ7KVC8/qbSCyhVXW7gxKm1rxYaajn5GKFPhuNSz88xYGGCzeIkKWP4FqbXsa2m
w1SQUrrs7EO+UYgBBzxpYeX7e0EUKnSCqCGW5B+quciB+9laaLTXRNPcDM9U4S/aUFWRKn
LbcScRUEpDK0d3mLAAAAE0FkbWluaXN0cmF0b3JAeXgtUEMBAgMEBQYH
-----END OPENSSH PRIVATE KEY-----"""
file_obj = StringIO(key_str)
print(file_obj)
private_key = paramiko.RSAKey(file_obj)
transport = paramiko.Transport(('192.168.7.32', 22))
transport.connect(username='root', pkey=private_key)

ssh = paramiko.SSHClient()
ssh._transport = transport

stdin, stdout, stderr = ssh.exec_command('df')
result = stdout.read()

transport.close()

print(result)

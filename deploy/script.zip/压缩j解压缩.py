import shutil

# 压缩文件
shutil.make_archive(base_name=r'C:\Users\Administrator\Desktop\deploy\script',format='zip',root_dir=r'C:\Users\Administrator\Desktop\deploy\script')
# base_name 要压缩成那个文件
# root_dir 要压缩那个目录里面的文件
# 解压文件
# shutil.unpack_archive(r'C:\Users\Administrator\Desktop\deploy\id_rsa.zip',
                      # extract_dir=r'C:\Users\uuu')

<?php
/**
 * cache 独立应用
 * User: nengzhi
 * Date: 15-10-18
 */
class XbFunc_Cachefunc{

	private static $cache_obj = null;
	private static $obj = null;
	private static $cache_tag = 'TyFunc_Cachefunc_tag_';
	
	public function __construct(){
		$cache_factory = new XbCache_Factory();
		self::$cache_obj = $cache_factory->getCacheAdapter();
	}
	
	/**
	 * 单例获取
	 * 保证一条进程只产生一个Module对象
	 */
	public static function getInstance() {
	
		if (empty ( self::$obj )) {
			self::$obj = new XbFunc_Cachefunc();
		}
		return self::$obj;
	}

	/**
	 * 添加一个cache缓存
	 * @param unknown $memkey
	 * @param unknown $value 
	 * @param unknown $timeleap
	 * @return boolean
	 */
	public function set($memkey,$value, $timeleap){
		return self::$cache_obj->set($memkey,$value,$timeleap);
	}
	/**
	 * 获取一个cache缓存
	 * @param unknown $memkey
	 */
	public function get($memkey){
		return self::$cache_obj->get($memkey);
	}
	/**
	 * 删除一个cache缓存
	 * @param unknown $memkey
	 */
	public function delete($memkey){
		return self::$cache_obj->delete($memkey);
	}
}
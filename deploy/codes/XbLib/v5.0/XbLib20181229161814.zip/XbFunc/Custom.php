<?php
/**
 * Created by lobo.
 * User: lobo
 * Email: wu_poem@foxmail.com
 * Date: 15-3-30
 * Time: 下午5:20
 */
class XbFunc_Custom{

    /**
     * 让array_column()函数兼容低版本PHP
     * array_column 用于获取二维数组中的元素(PHP 5.5新增函数)
     * i_array_column() 返回input数组中键值为$columnKey的列， 如果指定了可选参数$index_key，那么input数组中的这一列的值将作为返回数组中对应值的键
     */
    public static function i_array_column($input, $columnKey, $indexKey=null){
        if(!function_exists('array_column')){
            $columnKeyIsNumber  = (is_numeric($columnKey))?true:false;
            $indexKeyIsNull            = (is_null($indexKey))?true :false;
            $indexKeyIsNumber     = (is_numeric($indexKey))?true:false;
            $result                         = array();
            foreach((array)$input as $key=>$row){
                if($columnKeyIsNumber){
                    $tmp= array_slice($row, $columnKey, 1);
                    $tmp= (is_array($tmp) && !empty($tmp))?current($tmp):null;
                }else{
                    $tmp= isset($row[$columnKey])?$row[$columnKey]:null;
                }
                if(!$indexKeyIsNull){
                    if($indexKeyIsNumber){
                      $key = array_slice($row, $indexKey, 1);
                      $key = (is_array($key) && !empty($key))?current($key):null;
                      $key = is_null($key)?0:$key;
                    }else{
                      $key = isset($row[$indexKey])?$row[$indexKey]:0;
                    }
                }
                $result[$key] = $tmp;
            }
            return $result;
        }else{
            return array_column($input, $columnKey, $indexKey);
        }
    }

    /**
     * PHP 多维数组排序
     * 根据二维数组中某个项排序
     * $multi_array 要排序的数组，$sort_key 排序标志，$sort 排序方式
     */
    public static function multi_array_sort($multi_array,$sort_key,$sort=SORT_ASC){
        $multi_arrayIsArray  =  is_array($multi_array)?true:false;
        $sort_keyIsNull  =  empty($sort_key)?true:false;

        if($multi_arrayIsArray && !$sort_keyIsNull){
            foreach ($multi_array as $row_array){
                $key_array[] =( is_array($row_array) && !empty($row_array[$sort_key]) )?$row_array[$sort_key]:null;
            }
        }else{
           return false;
        }
        if($multi_arrayIsArray && !empty($key_array)){
            $result = array_multisort($key_array,$sort,$multi_array);
        }
        return (isset($result) && $result)?$multi_array:false;
    }

    /**
     * 计算两个日期之间的天数
     * @param  $a a日期，例：2014-11-19
     * @param  $b b日期，例：2014-11-22
     * @return 天数
     */
    public static function count_days($a,$b){
        if (strstr($a, '-') && strstr($b, '-')) {
            $a = strtotime($a);
            $b = strtotime($b);
        }
        $a_dt=getdate($a);
        $b_dt=getdate($b);
        $a_new=mktime(12,0,0,$a_dt['mon'],$a_dt['mday'],$a_dt['year']);
        $b_new=mktime(12,0,0,$b_dt['mon'],$b_dt['mday'],$b_dt['year']);
        return round(abs($a_new-$b_new)/86400);
    }

    /**
     * 将去掉 HTML 标记，javascript 代码
     * 和空白字符。还会将一些通用的
     * HTML 实体转换成相应的文本。
     */
    public static function escapeHTML($string){
        $string = strval($string);
        if(trim($string)!='')
        {
            $string = html_entity_decode($string , ENT_QUOTES , "UTF-8");
            $escapestring = htmlentities($string , ENT_QUOTES , "UTF-8");
        }

        return !empty($escapestring)?$escapestring:'';
    }
    /**
     * 弹出错误的信息
     * @param  string $msg      
     * @param  string $redirect 
     * @return null           
     */
    public static function showMsg($msg , $redirect = '')
    {
        if (empty($msg)) {
            return false;
        }
        $str = '';
        header('Content-type:text/html;charset=utf-8');
        $str .= '<script>alert("'.$msg.'");';
        if (!empty($redirect)) {
            $str .= 'window.location.href="'.$redirect.'";';
        }else{
            $str .= 'history.go(-1);';
        }
        $str .= '</script>';
        echo $str;exit();
    }
    /**
     * $dateTime 时间加上 $num 个（年、月、日）
     * @param  int $dateTime （时间戳）
     * @param  int $num  (正整数是 加 负整数 减)   
     * @param  string $plusType 
     * @return          
     */
    public static function datePlus($dateTime, $num , $plusType)
    {
        if (intval($dateTime) <= 0 || intval($num) <= 0 
            || !in_array($plusType ,array('day','month','year'))) {
            return 0;
        }
        $year = date('Y',$dateTime);
        $month = date('m',$dateTime);
        $day = date('d',$dateTime);
        $surplus = $dateTime - strtotime(date('Y-m-d',$dateTime));

        switch ($plusType) {
            case 'day':
                return $dateTime + ($num * 86400);
                break;
            case 'month':
                $_year = $year + sprintf('%d',$num / 12) ;
                $_month = $month + ($num % 12) ;
                if($_month > 12){
                    $_year += intval($_month / 12) ;
                    $_month = $_month % 12 ;
                }
                $maxDay = cal_days_in_month(CAL_GREGORIAN,$_month,$_year) ;
                $_day =  $maxDay < $day ? $maxDay : $day ; 
                return strtotime($_year . '-' . $_month . '-' . $_day) + $surplus;
                break;
            case 'year':
                $date = ($year - $num) . '-' . $month . '-' . $day;
                return strtotime($date) + $surplus;
                break;
            
            default:
                return 0;
                break;
        }
    }
    /**
     * 计算　收益
     * @param  　float $amount      投资金额
     * @param  　float $rate        年化利率
     * @param  ｉｎｔ $period      透支期限
     * @param  ｓｔｒｉｎｇ $period_type 投资期限类型
     * @return               
     */
    public static function profit($amount ,$rate,$period , $period_type)
    {
        if ($amount <= 0 || $period <= 0) {
            return false;
        }
        switch ($period_type) {
            case 'day':
                return $amount * $rate * $period / 365 / 100 ;
                break;
            case 'month':
                return $amount * $rate * $period / 12 / 100 ;
                break;

            default:
                return false;
                break;
        }
    }
    /**
     * 年华收益率
     * @param  [type] $mount       总金额
     * @param  [type] $profit      待收利息
     * @param  [type] $period      周期
     * @param  [type] $period_type 周期类型（day 、 month）
     * @return [type]              [description]
     */
    public static function loanRate($amount , $profit , $period , $period_type)
    {
        if ($amount <= 0 || $period <= 0) {
            return false;
        }
        switch ($period_type) {
            case 'day':
                return $profit * 365 / $period / $amount * 100;
                break;
            case 'month':
                return $profit * 12 / $period / $amount * 100;
                break;
            default:
                return false;
                break;
        }
    }

    /**
     * 校验合法性
     * @param $post_data
     * @param $token
     * @return bool
     */
    public static function checkToken($post_data,$token){
        if(empty($post_data)){
            return false;
        }
        $token_str = '';
        ksort($post_data);
        foreach($post_data as $val){
            $token_str .= $val;
        }
        $token_str = md5(md5($token_str));
        return $token_str === $token;
    }
    /**
     *　将ｇｂｋ转ｕｔｆ８
     * @param $val
     * @return string
     */
    public static function enUTF8($val){
        $enclist = array(
            'UTF-8', 'ASCII', 'GB2312','GBK','BIG5',
            'ISO-8859-1', 'ISO-8859-2', 'ISO-8859-3', 'ISO-8859-4', 'ISO-8859-5',
            'ISO-8859-6', 'ISO-8859-7', 'ISO-8859-8', 'ISO-8859-9', 'ISO-8859-10',
            'ISO-8859-13', 'ISO-8859-14', 'ISO-8859-15', 'ISO-8859-16',
            'Windows-1251', 'Windows-1252', 'Windows-1254'
        );
        if(mb_detect_encoding($val , $enclist) == 'UTF-8')
        {
            return $val;
        }
        return mb_convert_encoding($val, 'UTF-8','GB2312');
    }
}

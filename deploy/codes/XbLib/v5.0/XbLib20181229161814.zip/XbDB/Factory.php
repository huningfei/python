<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2014-9-22
 * UTF-8
 */
class XbDB_Factory{
	private $adapter = null;
	private $db_config = null;
	private $db_tag = null;
	
	/**
	 * 获得 DBFactory
	 * @param unknown $XbDB_tag
	 * @param string $XbDB_adapter
	 * @throws Exception
	 */
	function __construct($db_tag,$XbDB_adapter='mysql'){
		$env = getenv('RUNTIME_ENVIROMENT') ? getenv('RUNTIME_ENVIROMENT') : (defined('SHELL_VARIABLE') ? SHELL_VARIABLE : '');
		$env = empty($env)?'local':$env;
		$config = require(LIBRARY_DIR.'/Conf/'.$env.'/db.php');
		if(!isset($config[$db_tag])){
			throw new Exception('can not found the XbDB_config env:'.$env.' XbDB_tag:'.$db_tag);
		}
		$this->db_config = $config[$db_tag];
		$this->adapter = $XbDB_adapter;
		$this->db_tag = $db_tag;
	}
	
	/**
	 * 
	 * @return Ambigous <NULL,XbDB_Abstract,XbDB_Interface>
	 */
	public function getDBAdapter(){
		$adapter = null;
		switch ($this->adapter){
			case 'mysql':
				$adapter = new XbDB_Adapter_Mysql($this->db_config,$this->db_tag);
				break;
			default:
		}
		return $adapter;
	}
}

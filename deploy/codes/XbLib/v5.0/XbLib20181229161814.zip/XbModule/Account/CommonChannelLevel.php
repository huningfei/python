<?php


class XbModule_Account_CommonChannelLevel {
    
    private $channel_level_model;
    
    private static $obj;
    
    private $token_expire = 2592000;    //token生存期30天
    
    private function __construct() {
        $this->channel_level_model = new XbModel_Account_CommonChannelLevel();
    }
    
    /**
     * 单例
     * 
     * @return XbModule_Account_CommonChannelLevel
     */
    public static function getInstance() {
        if (!self::$obj) {
            self::$obj = new self();
        }
        
        return self::$obj;
    }
    
    /**
     * 获取渠道等级设置
     * 
     * @param string $channel_id
     * @param string $level_id
     * @param string $type
     * @param number $page
     * @param number $perpage
     */
    public function getChannelLevel($channel_id = '', $level_id = '', $type = '', $page = 1, $perpage = 10,$mch_id=1) {
        return $this->channel_level_model->getChannelLevel($channel_id, $level_id, $type, $page, $perpage,$mch_id);
    }
    
    /**
     * 获取渠道费率
     * 
     * @param unknown $id
     * @return unknown
     */
    public function getChannelLevelById($id) {
        return $this->channel_level_model->getChannelLevelById($id);
    }
    
    /**
     * 编辑通道费率
     * 
     * @param unknown $id
     * @param unknown $level_id
     * @param unknown $channel_id
     * @param unknown $rate
     * @param unknown $fee
     * @param unknown $type
     * @return unknown
     */
    public function updateChannelLevel($id, $level_id = '', $channel_id = '', $rate = '', $fee = '', $type = '',$mch_id='') {
        return $this->channel_level_model->updateChannelLevel($id, $level_id, $channel_id, $rate, $fee, $type,$mch_id='');
    }
    
    /**
     * 增加通道费率
     * 
     * @param unknown $level_id
     * @param unknown $channel_id
     * @param unknown $rate
     * @param unknown $fee
     * @param unknown $type
     * @return unknown
     */
    public function addChannelLevel($level_id, $channel_id, $rate, $fee, $type,$mch_id) {
        return $this->channel_level_model->addChannelLevel($level_id, $channel_id, $rate, $fee, $type,$mch_id);
    }
    /**
     * @desc 获取等级对应的所有ID
     * @param    int      $channel_id     通道ID
     * @return   array
     */
    public function getCClByChannelId($channel_id){
        return $this->channel_level_model->getCClByChannelId($channel_id);
    }

    /**
     * @desc 获取开启的通道各等级费率
     * @return   array
     */
    public function getOpenChannelLevel($mch_id=1){
        $level = XbModule_Account_Level::getInstance()->getAllLevel(false,0,$mch_id);
        $channel_level = XbModule_Account_CommonChannelLevel::getInstance()->getChannelLevel('', '', 1, 1, 999,$mch_id);
        $channel_level_repayment = XbModule_Repayment_ChannelLevel::getInstance()->getChannelLevel('', '', '', 1, 999,$mch_id);
        $res_channel = XbModule_Account_Channel::getInstance()->getChannel(1);
        $res_channel_repayment = XbModule_Repayment_Channel::getInstance()->getChannel(1);
        $res = array();
        foreach ($level as $key => $value) {
            $res[$value['level']] = array();

            foreach ($res_channel as $ke => $va) {
                foreach ($channel_level as $k => $v) {
                    if ($v['channel_id'] == $va['channel_id'] && $v['level_id'] == $value['level']) {
                        $res[$value['level']][] = array(
                            'channel_id'    => $va['channel_id'],
                            'channel_name'  => $va['channel_name'],
                            'rate'          => $v['rate'],
                            'fee'           => $v['fee'],
                            'channel_type'  => '1',
                        );

                    }
                }
            }

            foreach ($res_channel_repayment as $ke => $va) {
                foreach ($channel_level_repayment as $k => $v) {
                    if ($v['channel_id'] == $va['channel_id'] && $v['level_id'] == $value['level']) {
                        $res[$value['level']][] = array(
                            'channel_id'    => $va['channel_id'],
                            'channel_name'  => $va['channel_name'].'还款',
                            'rate'          => $v['rate'],
                            'fee'           => $v['fee'],
                            'channel_type'  => '2',
                        );

                    }
                }
            }
        }
        return $res;
    }

    /**
     * @desc    根据channel_id获取渠道等级
     * @param   int     $channel_id     根据channel_id获取渠道等级
     * @param   int     $level          等级
     * @param   int     $mch_id         身份
     * @return  array   $return         返回渠道信息
     */
    public function getChannelLevelByChannelId($channel_id, $level, $mch_id){
        return $this->channel_level_model->getChannelLevelByChannelId($channel_id, $level, $mch_id);

    }


}
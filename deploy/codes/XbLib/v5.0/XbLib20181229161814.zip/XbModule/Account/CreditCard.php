<?php
/**
 * @desc    信用卡
 * @author  qien
 * @date    17.12.21
 */
class XbModule_Account_CreditCard{
    private $creditCard_model = null;
    private static $obj = null;

    /**
     * 封闭构造
     * XbModel_Account_CreditCard constructor.
     */
    private function __construct() {
        $this->creditCard_model = new XbModel_Account_CreditCard();
    }

    /**
     * 单例
     * @return null|XbModule_Account_CreditCard
     */
    public static function getInstance() {
        if (empty(self::$obj)) {
            self::$obj = new XbModule_Account_CreditCard();
        }
        return self::$obj;
    }

    /**
     * @desc    增加信用卡
     * @param   int     $uid        用户id
     * @param   string  $bank       银行名称
     * @param   string  $bankCode   银行编码
     * @param   string  $cardNumber 信用卡号
     * @param   string  $type       信用卡
     * @param   string  $mch_code   用户mch_code
     * @return  boolen  $return     返回执行结果
     */
    public function addCreditCard($uid, $bank, $bankCode, $cardNumber, $telephone){
        return $this->creditCard_model->addCreditCard($uid, $bank, $bankCode, $cardNumber, $telephone);
    }

    /**
     * @desc    根据id查询信用卡信息
     * @param   int     $id
     * @return  array   $return
     */
    public function getInfoById($id){
        return $this->creditCard_model->getInfoById($id);
    }

    /**
     * @desc    修改信用卡cvv与有效期
     * @param   int     $id
     * @param   int     $cvv
     * @param   int     $validDate
     * @return  array   $return
     */
    public function updateCardCvv($id, $uid,$cvv, $validDate){
        return $this->creditCard_model->updateCardCvv($id, $uid,$cvv, $validDate);
    }

    /**
     * @desc    根据卡号查询信息
     * @param   string  $cardNumber     银行卡号
     * @return  array   $return         返回搜索结果
     */
    public function getInfoByCardNumber($cardNumber){
        return $this->creditCard_model->getInfoByCardNumber($cardNumber);
    }

    /**
     * @desc    删除信用卡
     * @param   int     $uid    用户id
     * @param   string  $cardId 卡号id
     * @return  array   $return 返回执行结果
     */
    public function delCreditCard($uid, $cardId){
        return $this->creditCard_model->delCreditCard($uid, $cardId);
    }

    /**
     * @desc    统计用户信用卡
     * @param   int     $uid    用户id
     * @return  int     $return
     */
    public function countCreditCard($uid){
        return $this->creditCard_model->countCreditCard($uid);
    }

    /**
     * @desc    获取用户所有信用卡信息
     * @param   int     $uid    用户id
     * @return  array   $return 返回搜索结果
     */
    public function getAllCreditCard($uid,$start=0,$limit=0,$type=false){
        return $this->creditCard_model->getAllCreditCard($uid,$start,$limit,$type);
    }

    /**
     * @desc    获取用户未添加还款资料的信用卡
     * @param   int     $uid    用户uid
     * @param   int     $status 信用卡状态
     * @return  array   $return 用户信用卡信息
     */
    public function getRepaymentCreditCard($uid, $status){
        return $this->creditCard_model->getRepaymentCreditCard($uid, $status);
    }

    /**
     * @desc    添加信用卡信息
     * @param   int     $cid            信用卡id
     * @param   int     $uid            用户uid
     * @param   int     $cardDate       信用卡日期
     * @param   int     $cvv            信用卡验证后三位
     * @param   int     $billDate       信用卡账单日
     * @param   int     $payDate        信用卡还款日
     * @param   int     $amountLimit    信用卡额度
     * @return  boolen  $return         返回执行情况
     */
    public function addRepaymentInfo($cid, $uid, $cardDate, $cvv, $billDate, $payDate, $amountLimit){
        if(!XbLib_Verify::checkInt($cardDate, 4, 4) || !XbLib_Verify::checkInt($cvv, 3, 3) || !XbLib_Verify::checkInt($billDate, 1, 2) || !XbLib_Verify::checkInt($payDate, 1, 2) || !XbLib_Verify::checkInt($amountLimit, 4, 11)){
            return new XbLib_WebError(4501);
        }
        $userProfile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);
        if(!$userProfile || $userProfile['status'] != 3){
            return new XbLib_WebError(4213);
        }
        $cardInfo = XbModule_Account_CreditCard::getInstance()->getInfoById($cid);
        if(!$cid || !$cardInfo || $cardInfo['uid'] != $uid){
            return new XbLib_WebError(4212);
        }
        return $this->creditCard_model->addRepaymentInfo($cid, $uid, $cardDate, $cvv, $billDate, $payDate, $amountLimit);
    }

    /**
     * @desc    删除还款信用卡信息
     */
    public function delRepaymentInfo($uid, $cid){
        return $this->creditCard_model->delRepaymentInfo($uid, $cid);
    }

    /**
     * @desc    修改还款信用卡还款信息
     */
    public function updateRepaymentInfo($cid, $uid, $billDate, $payDate, $amountLimit){
        if(!XbLib_Verify::checkInt($billDate, 1, 2) || !XbLib_Verify::checkInt($payDate, 1, 2) || !XbLib_Verify::checkInt($amountLimit, 4, 11)){
            return new XbLib_WebError(4501);
        }
        if(strlen($billDate) == 1) $billDate = '0'.$billDate;
        if(strlen($payDate) == 1) $payDate = '0'.$payDate;
        $userProfile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);
        if(!$userProfile || $userProfile['status'] != 3){
            return new XbLib_WebError(4213);
        }
        $cardInfo = XbModule_Account_CreditCard::getInstance()->getInfoById($cid);
        if(!$cid || !$cardInfo || $cardInfo['uid'] != $uid){
            return new XbLib_WebError(4212);
        }
        if($cardInfo['status'] != 1){
            return new XbLib_WebError(4502);
        }
        return $this->creditCard_model->updateRepaymentInfo($cid, $uid, $billDate, $payDate, $amountLimit);
    }

    /**
     * @desc    修改信用卡还款提醒
     */
    public function updateRepaymentWarn($cid, $uid, $status){
        $statusArr = array(0, 1);
        if(!in_array($status, $statusArr)){
            return new XbLib_WebError(4511);
        }
        $cardInfo = XbModule_Account_CreditCard::getInstance()->getInfoById($cid);
        if(!$cid || !$cardInfo || $cardInfo['uid'] != $uid){
            return new XbLib_WebError(4212);
        }
        if($cardInfo['status'] != 1){
            return new XbLib_WebError(4502);
        }
        return $this->creditCard_model->updateRepaymentWarn($cid, $uid, $status);
    }

    /*
     * @desc    获取还款信用卡提醒用户
     */
    public function getAllRepaymentWarn($date, $type,  $limit, $num){
        return $this->creditCard_model->getAllRepaymentWarn($date, $type,  $limit, $num);
    }
}
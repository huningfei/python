<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/12/23
 * Time: 17:55
 */
class XbModule_Account_JpushApp
{
    private $JpushApp_model = null;
    private static $obj = null;
    public static $message = array(
//        'reg' => array(
//            'title'   => '欢迎您成功注册小白信用卡',
//            'content' => '欢迎来到小白信用卡，您在此可以轻松完成信用卡收款功能，提现秒到账，邀请其他用户更可拿到分润！',
//            'url'     => 'message',
//            'isLogin' => 'true'
//        ),
//        'inviteReg' => array(
//            'title'   => '您邀请的用户已完成注册',
//            'content' => '您邀请的用户phone已完成注册，实名之后邀请关系才能生效！',
//            'url'     => 'message',
//            'isLogin' => 'true'
//        ),
//        'inviteAuth' => array(
//            'title'   => '您邀请的用户已完成实名认证',
//            'content' => '您邀请的用户phone已成功完成实名认证，邀请关系已生效！',
//            'url'     => 'message',
//            'isLogin' => 'true'
//        ),
//        'profit' => array(
//            'title'   => '您邀请的用户完成一笔收款',
//            'content' => '您邀请的用户phone成功收款1笔，去看看是否拿到分润吧！',
//            'url'     => 'message',
//            'isLogin' => 'true'
//        ),
//        'authFail' => array(
//            'title'   => '您的实名认证失败',
//            'content' => '您填写的实名信息有误，请重新填写提交！',
//            'url'     => 'message',
//            'isLogin' => 'true'
//        ),
//        'authSuccess' => array(
//            'title'   => '您的实名认证成功',
//            'content' => '您已经实名认证成功，快去收款吧！',
//            'url'     => 'message',
//            'isLogin' => 'true'
//        ),
//        'commonRepayment' => array(
//            'title'   => '恭喜您成功还款amount元至您尾号cardNumber的信用卡',
//            'content' => '恭喜您成功还款amount元至您尾号cardNumber的信用卡，去看看您的订单详情吧！',
//            'url'     => 'message',
//            'isLogin' => 'true'
//        ),
//        'wiseSingleRepayment' => array(
//            'title'   => '小白已成功为您执行一次智能还款任务',
//            'content' => '您的智能还款计划已成功执行一笔还款任务，还款金额：amount.查看还款详情',
//            'url'     => 'message',
//            'isLogin' => 'true'
//        ),
//        'wiseRepaymentStop' => array(
//            'title'   => '您的还款计划已暂停执行',
//            'content' => '尊敬的用户您好，您的还款计划已暂停执行，去看看是什么原因吧。',
//            'url'     => 'message',
//            'isLogin' => 'true'
//        ),
//        'wiseRepaymentSuccess' => array(
//            'title'   => '恭喜您尾号cardNumber信用卡的智能还款计划已全部完成',
//            'content' => '尊敬的用户您好，您尾号cardNumber信用卡的智能还款计划已全部完成',
//            'url'     => 'message',
//            'isLogin' => 'true'
//        ),
//        'repaymentBillDate' => array(
//            'title'   => '账单日提醒',
//            'content' => '尊敬的用户您好，您尾号cardNumber的cardBank信用卡账单日已到，点击查看',
//            'url'     => 'message',
//            'isLogin' => 'true'
//        ),
//        'repaymentPayDate' => array(
//            'title'   => '还款日提醒',
//            'content' => '尊敬的用户您好，您尾号cardNumber的cardBank信用卡最后还款日已到，为避免信用卡逾期，请点击还款。',
//            'url'     => 'message',
//            'isLogin' => 'true'
//        ),
//        'bankcardUpdateFail' => array(
//            'title'   => '储蓄卡编辑提醒',
//            'content' => '尊敬的用户您好，您的储蓄卡编辑操作失败，请重新提交。',
//            'url'     => 'message',
//            'isLogin' => 'true'
//        ),
//        'awardremind' => array(
//            'title'   => '您有money元红包 即将失效',
//            'content' => '您的账户中有money元的红包明天就失效了，立即点击领取吧',
//            'url'     => 'message',
//            'isLogin' => 'true'
//        ),
//        'awardarrive' => array(
//            'title'   => '恭喜您，收到name共计money元，点击立即领取',
//            'content' => '您参加name活动的money元奖励已经到账，点击即可领取到账户余额。',
//            'url'     => 'message',
//            'isLogin' => 'true'
//        ),
    );

    /**
     * 封闭构造
     * XbModel_Account_JpushApp constructor.
     */
    private function __construct()
    {
        $this->JpushApp_model = new XbModel_Account_JpushApp();
    }

    /**
     * 单例
     * @return null|XbModule_Account_JpushApp
     */
    public static function getInstance() {
        if (empty(self::$obj)) {
            self::$obj = new XbModule_Account_JpushApp();
        }
        return self::$obj;
    }

    //推送消息入库
    public function addJpush($uid,$title,$content,$type,$bid=''){
        return $this->JpushApp_model->addJpush($uid,$title,$content,$type,$bid);
    }

    //推送消息入库
    public function send_znx($uid,$msg,$type,$bid=''){
        return $this->JpushApp_model->addJpush($uid,$msg['title'],$msg['content'],$type,$bid);
    }

    //查询消息
    public function getMessageList($uid,$page=''){
        return $this->JpushApp_model->getMessageList($uid,$page);
    }

    /**
     * @desc    统计未读消息
     * @param   int     $uid    用户id
     * @return  int     $return 返回未读数量
     */
    public function getNotReadNum($uid){
        return $this->JpushApp_model->getNotReadNum($uid);
    }

    /**
     * @desc    更改消息为已读
     * @param   int     $uid    用户id
     * @return  int     $return 返回结果
     */
    public function updateIsRead($uid){
        return $this->JpushApp_model->updateIsRead($uid);
    }
}
<?php
/**
 * @desc    渠道
 * @author  yurong
 * @date    18.03.12
 */
class XbModule_Account_Channel {
    private $channel_model = null;
    private static $obj = null;
    /**
     * 封闭构造
     * XbModel_Account_Channel constructor.
     */
    private function __construct() {
        $this->channel_model = new XbModel_Account_Channel();
    }

    /**
     * 单例
     * @return null|XbModule_Account_Channel
     */
    public static function getInstance() {
        if (empty(self::$obj)) {
            self::$obj = new XbModule_Account_Channel();
        }
        return self::$obj;
    }

    /**
     * @desc    获取渠道列表
     * @param   int     $channel_tag      有无积分（1：有积分；2：无积分）
     * @param   int     $type             通道类型
     * @param   int     $start            偏移量
     * @param   int     $limit            每页显示条数
     * @return  array   $return           返回执行结果
     */
    public function getChannelList($channel_tag,$type,$start,$limit){
        return $this->channel_model->getChannelList($channel_tag,$type,$start,$limit);
    }
    /**
     * @desc  获取渠道数量
     * @param   int     $channel_tag      有无积分（1：有积分；2：无积分）
     * @param   int     $type             通道类型
     */
    public function getChannelCount($channel_tag,$type){
        $res =  $this->channel_model->getChannelCount($channel_tag,$type);
        return $res['num'];
    }

    /**
     * @desc  获取通道详细信息
     * @param   int     $id               ID
     * @param   int     $type             通道类型
     */
    public function getChannelDetail($id){
        return $this->channel_model->getChannelDetail($id);
    }
    /**
     * @desc  编辑通道信息
     * @param    array       $data      存储信息
     * @return   boolean     $return    返回执行结果
     */
    public function edit($id,$channel_id,$channel_name,$timelines,$type,$with_integral,$without_integral,$is_settlement,$time,$week,$rate_cost,$without_rate_cost,$service_cost,$status,$desc,$channel_day_max_charge){
        return $this->channel_model->edit($id,$channel_id,$channel_name,$timelines,$type,$with_integral,$without_integral,$is_settlement,$time,$week,$rate_cost,$without_rate_cost,$service_cost,$status,$desc,$channel_day_max_charge);
    }

    /**
     * @desc    根据channel_id获取渠道信息
     * @param   int     $channel_id     渠道channnel_id
     * @return  array   $return         返回渠道信息
     */
    public function getChannelByChannelid($channel_id){
        return $this->channel_model->getChannelByChannelid($channel_id);
    }

    /**
     * @desc    根据用户等级获取渠道信息
     * @param   int     $level          用户等级
     * @return  array   $return         返回渠道信息
     */
    public function getChannelInfoByLevel($level, $status='1',$channel_id){
        return $this->channel_model->getChannelInfoByLevel($level, $status,$channel_id);
    }

    /**
     * @desc    根据用户等级获取渠道信息
     * @param   int     $channel        用户等级
     * @return  array   $return         返回渠道信息
     */
    public function getChannelInfoByChannelLevel($channel, $status=''){
        return $this->channel_model->getChannelInfoByChannelLevel($channel, $status);
    }

    /**
     * @desc    推荐渠道
     * @param   int     $uid        用户id
     * @param   int     $amount     刷卡金额
     * @return  array   $return     返回推荐通道
     */
    public function getPayChannel($uid, $amount){
        $userLevelInfo = XbModule_Account_UsersLevel::getInstance()->getUserLevelByUid($uid);
        $userChannelCode = XbModule_Account_UsersChannel::getInstance()->getAllUserChannelByUid($uid, '2,3');
        if(!$userChannelCode){

        }
        $userChannelId = implode(',', array_column($userChannelCode, 'channel_id'));
        //获取用户等级相关通道-开启通道
        $levelChannel = $this->channel_model->getChannelInfoByLevel($userLevelInfo['level'], 1, $userChannelId);
        $payChannel   = array();
        $integralCount   = 0;   //有积分通道个数
        $unintegralCount = 0;   //无积分通道个数
        if($levelChannel){
            //判断交易时间|start
            $integralChannel   = array();
            $unintegralChannel = array();
            $limitChannel      = array();
            $integralReason    = '';
            $unintegralReason  = '';
            $integralStatus    = true;
            $unintegralStatus  = true;
            foreach($levelChannel as $k=>$v){
                $res = XbLib_ChannelTools::checkChannelTime($v['time'], $v['week']);
                if($res){
                    $limitChannel[] = $v;
                    if($v['type'] == 1) $integralCount += 1;
                    if($v['type'] == 2) $unintegralCount += 1;
                }
                if($integralStatus && $v['type'] == 1) $integralChannel[]   = $v;
                if($unintegralStatus && $v['type'] == 2) $unintegralChannel[] = $v;
            }
            if($integralCount > 0){
                $integralChannel = array();
            }else{
                $integralReason = '时间不在银行规定时间内';
                $integralStatus = false;
            }
            if($unintegralCount > 0){
                $unintegralChannel = array();
            }else{
                $unintegralReason = '时间不在银行规定时间内';
                $unintegralStatus = false;
            }
            //判断交易时间|end

            //判断交易金额|start
            $integralCount = 0;
            $unintegralCount = 0;
            foreach($limitChannel as $k=>$v){
                if($amount >= $v['mininum_charge'] && $amount <= $v['mininum_charge']){
                    if($v['type'] == 1) $integralCount += 1;
                    if($v['type'] == 2) $unintegralCount += 1;
                }else{
                    unset($limitChannel[$k]);
                }
                if($integralStatus && $v['type'] == 1) $integralChannel[]   = $v;
                if($unintegralStatus && $v['type'] == 2) $unintegralChannel[] = $v;
            }
            if($integralCount > 0){
                $integralChannel = array();
            }else{
                $integralReason = '时间不在银行规定时间内';
                $integralStatus = false;
            }
            if($unintegralCount > 0){
                $unintegralChannel = array();
            }else{
                $unintegralReason = '时间不在银行规定时间内';
                $unintegralStatus = false;
            }
            //判断交易金额|end

            //判断通道金额|start
            $integralCount = 0;
            $unintegralCount = 0;
            foreach($limitChannel as $k=>$v){
                //$countChannelAmount = XbModule_Account_Order::getInstance()->
                if($amount >= $v['mininum_charge'] && $amount <= $v['mininum_charge']){
                    if($v['type'] == 1) $integralCount += 1;
                    if($v['type'] == 2) $unintegralCount += 1;
                }else{
                    unset($limitChannel[$k]);
                }
                if($integralStatus && $v['type'] == 1) $integralChannel[]   = $v;
                if($unintegralStatus && $v['type'] == 2) $unintegralChannel[] = $v;
            }
            if($integralCount > 0){
                $integralChannel = array();
            }else{
                $integralReason = '时间不在银行规定时间内';
                $integralStatus = false;
            }
            if($unintegralCount > 0){
                $unintegralChannel = array();
            }else{
                $unintegralReason = '时间不在银行规定时间内';
                $unintegralStatus = false;
            }
            //判断通道金额|end
        }
        return $payChannel;
    }

    /**
     * @desc    根据channel_id获取渠道信息
     * @param   int     $channel_id     渠道channnel_id
     * @param   int     $level          相关等级
     * @return  array   $return         返回渠道信息
     */
    public function getChannelByChannelidLevel($channel_id, $level){
        return $this->channel_model->getChannelByChannelidLevel($channel_id, $level);
    }
    /**
     * @desc 获取通道银行卡
     * @param    int     $channel_id    通道ID
     * @param    int     $type          银行卡类型
     * @return   array   $return        返回还行结果
     * */
    public  function getChannelBankList($channel_id,$type){
        return $this->channel_model->getChannelBankList($channel_id,$type);
    }
    /**
     * @desc 编辑通道开关状态
     * @param     int     $channel_id   通道ID
     * @param     int     $end_time     结束时间
     * @return    boolean $return       返回执行结果
     */
    public function changChannelStatus($channel_id,$end_time=''){
        return $this->channel_model->changeChannelStatus($channel_id,$end_time);
    }
    /**
     * @desc 获取前一天关闭的通道
     * @param     string   $start_time  开始时间
     * @param     string   $end_time    结束时间
     * @return    array    $return      返回执行结果
     * */
    public function getChannelByUpdateTime($start_time,$end_time,$channel_id){
        return $this->channel_model->getChannelByUpdateTime($start_time,$end_time,$channel_id);
    }
    /**
     * @desc 获取可用通道
     * @param  int    $status   通道状态
     * @return  array $return   返回执行结果
     * */
    public function getChannel($status){
        return $this->channel_model->getChannel($status);
    }

    /**
     * @desc 获取开启的通道支持的银行卡
     * @return    array    $return      返回执行结果
     */
    public function getChannelBank(){
        return $this->channel_model->getChannelBank();
    }

    /**
     * @desc 获取所有通道支持的银行卡
     * @return    array    $return      返回执行结果
     */
    public function getChannelAllBank(){
        return $this->channel_model->getChannelAllBank();
    }
}
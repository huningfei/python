<?php
/**
 * @desc    等级
 * @author  qien
 * @date    18.01.22
 */
class XbModule_Account_Level {
    private $level_model = null;
    private static $obj = null;
    /**
     * 封闭构造
     * XbModel_Account_Level constructor.
     */
    private function __construct() {
        $this->level_model = new XbModel_Account_Level();
    }

    /**
     * 单例
     * @return null|XbModule_Account_Level
     */
    public static function getInstance() {
        if (empty(self::$obj)) {
            self::$obj = new XbModule_Account_Level();
        }
        return self::$obj;
    }

    /**
     * @desc    根据等级获取相关信息
     * @param   int     $level      等级
     * @return  array   $info       返回等级信息
     */
    public function getLevelByLevel($level){
        return $this->level_model->getLevelByLevel($level);
    }

    /**
     * @desc    获取所有等级信息
     * @return  array   $info       返回等级信息
     */
    public function getAllLevel($cost=false, $type = 0,$mch_id=1){
        return $this->level_model->getAllLevel($cost, $type,$mch_id);
    }
    
    /**
     * 获取指定等级的用户数量
     * 
     * @param unknown $level
     * @return unknown
     */
    public function getUsersNumByLevel($level) {
        return $this->level_model->getUsersNumByLevel($level);
    }


    /**
     * @desc    根据id获取等级信息
     * @param   int     $id     id
     * @return  array   $return
     */
    public function getLevel($id){
        return $this->level_model->getLevel($id);
    }

    /**
     * @desc   删除等级
     * @param  int    $id    id
     * @return bool   $res
     */
    public function delLevel($id){
        return $this->level_model->delLevel($id);
    }
    
    /**
     * 上传等级图标
     * 
     * @param unknown $level
     * @return boolean
     */
    public function saveIcon($level) {
        if (empty($_FILES['file']['tmp_name'])) {
            return false;
        }
        
        $img_data = $_FILES['file']['tmp_name'];
        
        $size = getimagesize($img_data);
        $file_type = $size['mime'];
        if (!in_array($file_type, array('image/png'))) {
            return false;
        }
        
        $file_extend = '.png';

        $file_name = "invite{$level}";
        
        //TODO
        $savePath = $_SERVER['DOCUMENT_ROOT'] . '/../xb_api/static/img/invite';
        
        $realpath = $savePath.'/'.$file_name.$file_extend;

        //mv文件
        if(!is_uploaded_file($img_data) || !@move_uploaded_file( $img_data, $realpath )){
            return false;
        }
        
        return true;
    }
    
    /**
     * 获取等级图标链接
     * 
     * @param unknown $level
     * @return string
     */
    public function getIconUrl($level) {
        $http = 'https://api.xiaobaijinfu.com';
        return $http . "/static/img/invite/invite{$level}.png";
    }

    /**
     * @desc 新增、修改等级
     * @param    array  $data   等级信息
     * @return   boolean $return 返回执行结果
     */
    public function editLevel($data){
//        echo 123;die;
        if(!$data['levelName']){
            return new XbLib_WebError(6010);
        }
        if(!$data['level']){
            return new XbLib_WebError(6011);
        }
        if(!$data['fee']){
            $data['fee'] = 0;
        }
        if(!$data['cost']){
            $data['cost'] = 0;
        }
        if(!$data['inviteNum']){
            $data['inviteNum'] = 0;
        }
        if(!$data['integralfee']){
            $data['integralfee'] = 0;
        }
        if(!$data['repaymentfee']){
            $data['repaymentfee'] = 0;
        }
        if($data['id']){
            return $this->level_model->updateLevel($data['id'],$data['levelName'],$data['level'],$data['fee'],$data['cost'],$data['inviteNum'],$data['is_redirect'],$data['type'],$data['integralfee'],$data['repaymentfee']);
        }else{
            return $this->level_model->createLevel($data['levelName'],$data['level'],$data['fee'],$data['cost'],$data['inviteNum'],$data['is_redirect'],$data['type'],$data['integralfee'],$data['repaymentfee'],$data['mch_id']);

        }
    }
    /**
     * @desc 获取等级对应费率
     * */
    public function getLevelRate($uid,$level){
        $return = [];
        $res =  $this->level_model->getLevelByLevel($level);
        if($res){
            $return['fee']          = $res['fee'];
            $return['integralfee']  = $res['integralfee'];
            $return['repaymentfee'] = $res['repaymentfee'];
        }
        return $return ? $return:false;
    }
    
    /**
     * 更新等级最低还款费率
     *
     * @param unknown $level_id
     * @param unknown $rate
     * @return boolean
     */
    public function updateLevelRepaymentRate($level_id, $rate) {
        return $this->level_model->updateLevelRepaymentRate($level_id, $rate);
    }
    
    /**
     * 更新收款费率
     *
     * @param unknown $level_id
     * @param unknown $fee
     * @param unknown $integral_fee
     * @return boolean
     */
    public function updateFee($level_id, $fee, $integral_fee) {
        return $this->level_model->updateFee($level_id, $fee, $integral_fee);
    }
    /**
     * 根据mch_id获取和level获取等级
     * @param unknown $mch_id
     * @param unknown $level
     * @return array
     */
    public function  getLeveByMchId($mch_id,$level){
        return $this->level_model->getLeveByMchId($mch_id,$level);
    }
}
<?php
/**
 * @desc    支付通道回调
 * @author  yurong
 * @date    18.03.25
 */
class XbLib_ChannelFunc_CallBackField{
    private static $obj;
    //易宝结算回调状态
    private static $yibao_sett_status = array(
        'RECEIVED'   =>1,//已接收
        'PROCESSING' =>2,//处理中
        'SUCCESSED'  =>3,//打款成功
        'FAILED'     =>4,//打款失败
        'REFUNED'    =>5,//已退款
        'CANCELLED'  =>6//已撤销
    );


    /*
     * */
    public static function getInstance(){
        if (empty(self::$obj)) {
            self::$obj = new XbLib_ChannelFunc_CallBackField();
        }
        return self::$obj;
    }
    public function getChannelObj($channel){
        if(!isset($channelObj[$channel])){
            $channelFactory = new XbLib_Paychannel_Factory($channel);
            $channelObj[$channel] = $channelFactory->getPaychannelAdapter();
        }
        return $channelObj[$channel];
    }
    /**
     *@desc  支付回调接口
     */
    public function callBackField($data){
        if( !$data) return false;
        XbFunc_Log::write('callBackField','支付回调数据：'.$data);
        //根据通道对数据进行重组
        $datas = $this->checkData($data);//对数据先首次处理
        $new_data = $this->getData($datas);//对数据二次处理
        if($new_data['code'] != 200)return false;

        //通过channel_code 获取uid
//        $new_data['uid'] = XbModule_Account_UsersChannel::getInstance()->getUserId($new_data['channel_code'])['uid'];
        //获取mch_id
//        $mch_id = XbModule_Account_Users::getInstance()->getUserById($new_data['uid'])['mch_id'];
//        $order =  XbModule_Account_Order::getInstance($mch_id)->getOrderByAnfOrderNo($new_data['axf_order_no']);

        $order_index = XbModule_Account_OrderIndex::getInstance()->getOrderIndexByOrderId($new_data['axf_order_no']);
        $new_data['uid'] = $order_index['uid'];
        $mch_id = $order_index['order_table_num'];
        $order =  XbModule_Account_Order::getInstance($mch_id)->getOrderById($order_index['order_table_id']);

        if ($order['status'] > 0) {
            return false;
        }

        //根据channel_id 查出费率
        $channel_level = XbModule_Account_Channel::getInstance()->getChannelInfoByChannelLevel($order['channel_id']);

        //创建结算订单号
        $new_data['order_id']    =  XbModule_Account_OrderCode::getInstance()->getOrderCode();
        //校验该通道是否支持结算接口
        $is_settlement = XbModule_Account_Channel::getInstance()->getChannelDetail( $channel_level['channel_id']);
        $new_data['channel_tag']  = 3;

        $new_data['rate'] = (int)$channel_level['fee'];
        $new_data['channel_id'] = $channel_level['channel_id'];
        if($is_settlement && $is_settlement['is_settlement'] ==1){
            $res_order_plan_money = XbModule_Account_Order::getInstance($mch_id)->getOrderPlayData($order['order_id']);
            if($res_order_plan_money){
                return false;
            }

            $new_data['after_amount'] = bcsub($new_data['amount'],$new_data['fee'],2);
            $res = $this->settlement($new_data);
            if($res){
                $new_data['fee'] = bcadd($new_data['fee'],$channel_level['fee']);
                $res = XbModule_Account_Order::getInstance($mch_id)->callBackField($new_data,1);
            }else{
                XbFunc_Log::write('callBackField','请求结算接口失败：'.json_encode($res));
            }
        }else{
            $res = XbModule_Account_Order::getInstance($mch_id)->callBackField($new_data,2);
            //取现成功微信推送调用，使用try...catch判断推送成功或失败，失败则写入日志
            if ($new_data['status'] == 1 && $res) {
//                try{
//                    $wxdata = array(
//                        'uid'         => $new_data['uid'],
//                        'orderamount' => number_format($order['amount'], 2, '.', ''),
//                        'date'        => date('Y-m-d H:i:s',$new_data['paytime']),
//                        'ordernumber' => $new_data['order_id']
//                    );
//                    XbLib_WechatTools_SendMsg::getInstance()->publicWxTemplateMsgSendFunc(4, $wxdata);
//                }catch (Exception $e){
//                    $log = json_encode($order);
//                    XbFunc_Log::write('WxMsgxiaoxi','推送消息失败：取现失败', $log);
//                }
                //优化推送消息
                $res_msg = XbLib_PushMsg::getInstance()->orderPayment($order['uid'],array('order_id'=>$order['id']));

                //TODO 此处调用钩子计算是否发奖励
                //TODO 似乎包含失败的情况，待确定
                
                XbLib_ActEvent_EventManager::attach(XbLib_ActEvent_CommonEvent::AFTER_WITHDRAW);

                XbLib_ActEvent_EventManager::trigger(XbLib_ActEvent_CommonEvent::AFTER_WITHDRAW, $this, [
                    'user_id' => $new_data['uid'],
                    'order_id' => $order['order_id'],
                    'mch_id' => $mch_id
                ]);
            }
        }
        if($res){
            //获取用户信息
            $user = XbModule_Account_Users::getInstance()->getUserById($new_data['uid']);
            if($user['mch_id'] == 1){
                XbModule_Account_Order::getInstance($mch_id)->synOrderProfit($order['order_id'], $new_data['uid'], $order['rate'], $order['amount'], $order['id']);
            }

            return $res;
        }

        return false;
    }
    /**
     * @desc  结算回调接口
     * */
    public function callBackSettlement($data){
        if(!$data) return false;
        XbFunc_Log::write('callBackField','结算回调数据：'.$data);
        $datas = $this->checkData($data);
        $new_data = $this->settGetData($datas);
        //通过channel_code 获取uid
        $new_data['uid'] = XbModule_Account_UsersChannel::getInstance()->getUserId($new_data['channel_code'])['uid'];
        //获取mch_id
        $mch_id = XbModule_Account_Users::getInstance()->getUserById($new_data['uid'])['mch_id'];
        $res = XbModule_Account_Order::getInstance($mch_id)->callBackSettlement($new_data);

        //取现成功微信推送调用，使用try...catch判断推送成功或失败，失败则写入日志
        if ($res) {
            //获取订单信息
            $axf_order_no = XbModule_Account_Order::getInstance($mch_id)->getOrderByPlayOrderNo($new_data['play_money_no'])['order_no'];
            if(!$axf_order_no){
                XbFunc_Log::write('WxMsgInfo','没有此订单信息'.$new_data['play_money_no']);
            }
            $order =  XbModule_Account_Order::getInstance($mch_id)->getOrderByAnfOrderNo($axf_order_no);
            XbFunc_Log::write('WxMsgInfo','订单信息'.json_encode($order));

            if($new_data['status'] == 3){
//                $date = $order['create_time'] ? $order['create_time'] : time();
//                $wxdata = array(
//                    'uid'         => $new_data['uid'],
//                    'orderamount' => number_format($order['amount'], 2, '.', ''),
//                    'date'        => date('Y-m-d H:i:s',$date),
//                    'ordernumber' => $order['order_id']
//                );
//                $result = XbLib_WechatTools_SendMsg::getInstance()->publicWxTemplateMsgSendFunc(4, $wxdata);
//                XbFunc_Log::write('WxMsgInfo','发送消息返回数据'.json_encode($result).'发送数据:'.json_encode($wxdata));
                //优化推送消息
                $res_msg = XbLib_PushMsg::getInstance()->orderPayment($order['uid'],array('order_id'=>$order['id']));
                //TODO 此处调用钩子计算是否发奖励
                
                XbLib_ActEvent_EventManager::attach(XbLib_ActEvent_CommonEvent::AFTER_WITHDRAW);
                
                XbLib_ActEvent_EventManager::trigger(XbLib_ActEvent_CommonEvent::AFTER_WITHDRAW, $this, [
                    'user_id' => $new_data['uid'],
                    'order_id' => $order['order_id'],
                    'mch_id' => $mch_id
                ]);
            }
            
        }
        return $res ? $res : false;
    }
    /**
     *@desc 结算回调--根据通道对数据进行重组
     */
    public function settGetData($data){
        $return = [];
        if(isset($data['customerNumber'])){
            $return = $this->yibaoSettGetData($data);
        }
        return $return;

    }
    /**
     * @desc 支付回调--根据通道对数据进行重组
     * **/
    public function getData($data){
        $return = [];
        if($data['customerNumber']){
            $return = $this->yibaoGetData($data);
        }elseif($data['USER_ID']){
            $return = $this->fujianmilianGetData($data);
        }
        return $return;
    }
    /**
     * @desc 重组福建米联支付回调数据
     * */
    public function fujianmilianGetData($data){
        $arr = [];
        $arr['order_id'] = $data['ORDER_ID'];
        $arr['axf_order_no'] = $data['ORDER_ID'];
        $arr['externalld'] = $data['ORDER_ID'];
        $arr['pay_time'] = $data['PAYCH_TIME'];
        $arr['pay_amount'] = $data['PAY_AMOUNT'];
        $arr['code'] = $data['RESP_CODE']=='0000'?200:$data['RESP_CODE'];
        $arr['status'] = $data['RESP_CODE']=='0000'?1:2;
        $arr['msg'] = $data['RESP_DESC'];
        $arr['channel_code'] = $data['USER_ID'];
        $arr['creditcardNumber'] = $data['ADD1'];
        //计算实际到账金额以及手机费
        $uid = XbModule_Account_UsersChannel::getInstance()->getUserId($arr['channel_code'])['uid'];
        $mch_id = XbModule_Account_Users::getInstance()->getUserById($uid)['mch_id'];
        $order = XbModule_Account_Order::getInstance($mch_id)->getOrderByAnfOrderNo($arr['axf_order_no']);
        $arr['paytime'] = $order['create_time'];
        $arr['rate'] = $order['rate'];
        $fee = sprintf("%.2f", bcmul( $arr['pay_amount'],$arr['rate'],4));
        $arr['fee'] = $fee + $order['single_fee'];
        $arr['after_amount'] = $arr['pay_amount'] - $arr['fee'] ;
        return $arr;
    }
    /**
     *@desc 重新组合易宝结算回调数据
     * */
    public function yibaoSettGetData($data){
        $arr = [];
        $arr['channel_code']            = $data['customerNumber'];
        $arr['play_money_no']           = $data['externalNo'];
        $arr['serial_no']               = $data['serialNo'];
        $arr['sett_transferway']       = $data['transferWay'];
        $arr['sett_amount']             = $data['amount'];
        $arr['sett_fee']                = $data['fee'];
        $arr['sett_basic_fee']          = $data['basicFee'];
        $arr['sett_extarget_fee']       = $data['exTargetFee'];
        $arr['actual_amount']           = $data['actualAmount'];
        $arr['receiver']                 = $data['receiver'];
        $arr['receiver_bank']           = $data['receiverBank'];
        $arr['receiver_bank_card_no']  = $data['receiverBankCardNo'];
        $arr['reason']                   = $data['failReason'];
        $arr['pay_time']                 = $data['handleTime'];
        $arr['status']                   = self::$yibao_sett_status[$data['transferStatus']];
        return $arr;
    }
    /**
     *@desc 重新组合易宝支付回调数据
     */
    public function yibaoGetData($data){
        $arr = [];
        $arr['code']           = $data['code']=='0000' ? 200 : $data['code'];
        $arr['msg']            = $data['message'];
        $arr['axf_order_no']  = $data['requestId'];
        $arr['channel_code']  = $data['customerNumber'];
        $arr['externalld']    = $data['externalld'];
        $arr['paytime']       = strtotime($data['payTime']);
        $arr['amount']        = $data['amount'];
        $arr['fee']           = $data['fee'];
        $arr['status']        = $data['status']=='SUCCESS'?1:2;
        return $arr;
    }
    /**
     *@desc  根据通道用户标识参数 来 选择结算请求接口
     */
    public function settlement($new_data){
        if(!$new_data['channel_id']) return false;
        switch ($new_data['channel_id']){
            case 1:
                $channel_data['channel_code'] =$new_data['channel_code'];
                $channel_data['order_id']     =$new_data['order_id'];
                $channel_data['amount']       =$new_data['after_amount'];
                $channel_data['channel_tag']  =$new_data['channel_tag'];
                $channel_data['rate']          =$new_data['rate'];
                $result = XbLib_ChannelFunc_Channel::getInstance()->settlement($new_data['channel_id'],$channel_data);
                $return = $result && $result['code'] == '0000'?$result:false;
                break;
            case 2:
                break;
            default:
        }
        return $return;

    }
    /**
     *@desc 订单查询
     */
    public function tradeRevice($data){
        $res = XbLib_ChannelFunc_Channel::getInstance()->transfer($data['channel_id'],$data);
        return $res;
    }
    public function checkData($data){
        if(!is_null(json_decode($data))){
            $new_data = json_decode($data,true);
        }else if(strpos($data,'&')){
            $datas = urldecode($data);
            parse_str($datas,$new_data);
        }else if(is_array($data)){
            $new_data = $data;
        }else{
            $new_data = $data;
        }
        return $new_data;
    }

    //雅酷酷宝支付回调
    public function yakukubaoCallBackField($data){
        $status_arr = array(
            'WAIT_PAY'      => 0,//等待付款(系统不会异步通知)
            'PAY_FINISHED'  => 1,//已付款(系统会异步通知)
            'TRADE_FAILED'	=> 2,//交易失败(系统会异步通知)
            'TRADE_FINISHED'=> 1,//交易结束(系统会异步通知）支付成功
            'TRADE_CLOSED'  => 2,//交易关闭 (系统会异步通知) 超时未支付
        );
        $datas = $this->checkData($data);//对数据先首次处理
        $status   = $status_arr[$datas['trade_status']];
        $order_id = $datas['outer_trade_no'];

        $res_order_index = XbModule_Account_OrderIndex::getInstance()->getOrderIndexByOrderId($order_id);
        $callback_data['pay_time']  = strtotime($datas['gmt_payment']);
        $callback_data['serial_no'] = $datas['inner_trade_no'];
        $callback_data['msg']       = $datas['trade_status'];

        $res = XbModule_Account_Order::getInstance($res_order_index['order_table_num'])->yakuCallBackField($status, $res_order_index, $callback_data);

        return $res;

    }

    //雅酷酷宝代付回调
    public function yakukubaoCallBackSettlement($data) {
        $status_arr = array(
            'SUCCESS'       => 1,//成功(系统会异步通知)
            'FAILED'        => 2,//失败(系统会异步通知)
            'PROCESSING'	=> 0,//处理中(系统不会异步通知)
            'RETURNT_TICKET'=> 2,//银行退票(系统会异步通知)
        );
        $datas = $this->checkData($data);//对数据先首次处理

        $status   = $status_arr[$datas['withdraw_status']];
        $order_id = $datas['outer_trade_no'];

        $res_order_play = XbModule_Account_Order::getInstance()->getOrderByPlayOrderNo($order_id);
        $res_order_index = XbModule_Account_OrderIndex::getInstance()->getOrderIndexByOrderId($res_order_play['order_no']);
        $callback_data['serial_no'] = $datas['inner_trade_no'];

        $res = XbModule_Account_Order::getInstance($res_order_index['order_table_num'])->yakuCallBackSettlement($status, $res_order_index, $res_order_play, $callback_data);

        return $res;
    }

}
<?php

/**
 * @desc    支付通道调用通道
 * @author  qien
 * @date    18.03.23
 */
class XbLib_ChannelFunc_Channel
{
    private static $obj;
    private $channelObj = array();
    private $webBackUrl = 'https://m.xiaobaijinfu.com';
    public $channel = array(
        1 => 'yibao',
        2 => 'fujianyangtao',
//        3 => 'fujianliulian',
        4 => 'fujianyingtao',
        5 => 'fujianhuolongguo',
        6 => 'fujianboluo',
        7 => 'fujianyingtaojx',
        8 => 'fujianyingtaojxb',
        9 => 'yakukubao',
    );

    /*
     * */
    public static function getInstance()
    {
        if (empty(self::$obj)) {
            self::$obj = new XbLib_ChannelFunc_Channel();
        }
        return self::$obj;
    }

    public function getChannelObj($channel)
    {
        if (!isset($channelObj[$channel])) {
            $channelFactory = new XbLib_Paychannel_Factory($channel);
            $channelObj[$channel] = $channelFactory->getPaychannelAdapter();
        }
        return $channelObj[$channel];
    }

    /**
     * @desc    注册各通道
     * @param   array $data 用户信息
     * @return  array   $return     返回注册状态
     */
    public function signUp($data)
    {
        $return = array(
            'code' => 200,
            'msg' => '',
            'channelInfo' => array(),
            'error' => array()
        );

        $data['bankcardImage1'] = XbLib_FileHandle::getFileMessage($data['bankcardImage1']);
        $data['bankcardImage2'] = XbLib_FileHandle::getFileMessage($data['bankcardImage2']);
        $data['idcardImage1'] = XbLib_FileHandle::getFileMessage($data['idcardImage1']);
        $data['idcardImage2'] = XbLib_FileHandle::getFileMessage($data['idcardImage2']);

        //处理用户图片，如果大于500K，则剪裁一下
        $fileSize = 511000;
        if ($data['bankcardImage1']['size'] > $fileSize) $data['bankcardImage1'] = XbLib_FileHandle::reSizeImg($data['bankcardImage1']['path'], 400, 400);
        if ($data['bankcardImage2']['size'] > $fileSize) $data['bankcardImage2'] = XbLib_FileHandle::reSizeImg($data['bankcardImage2']['path'], 400, 400);
        if ($data['idcardImage1']['size'] > $fileSize) $data['idcardImage1'] = XbLib_FileHandle::reSizeImg($data['idcardImage1']['path'], 400, 400);
        if ($data['idcardImage2']['size'] > $fileSize) $data['idcardImage2'] = XbLib_FileHandle::reSizeImg($data['idcardImage2']['path'], 400, 400);
        $is_succ = false;
        foreach ($this->channel as $k => $v) {
            if ($k == 9 ){
                continue;
            }
            $channelInfo = XbModule_Account_Channel::getInstance()->getChannelByChannelid($k);
            if ($channelInfo) {
                $channelObj = $this->getChannelObj($v);
                $signUpInfo = $channelObj->buildSignData($data)->signUp();

                if (isset($signUpInfo['channel_code'])) {
                    $is_succ = true;
                    //进件成功
                    $channel_key = $signUpInfo['channel_key'] ? $signUpInfo['channel_key'] : '';
                    $return['channelInfo'][] = array('channel_id' => $k, 'channel_code' => $signUpInfo['channel_code'], 'channel_key' => $channel_key);
                } else {
                    //进件失败
                    $param = array_merge($signUpInfo, array('uid' => $data['uid'], 'channel_id' => $k, 'create_time' => time()));
                    $res = XbModule_Account_UsersProfile::getInstance()->userChannelError($param);
                    $param['channel_name'] = $channelInfo['channel_name'];
                    $return['error']['list'][] = $param;
                    $return['error']['is_succ'] = $is_succ;
                }
            }
            // echo"<pre>";var_dump($signUpInfo);
        }
        // die();
        XbFunc_Log::write('fujian', '用户【' . $data['phone'] . '】返回数据：' . json_encode($return));
        return $return;
    }

    /**
     * @desc  注册指定通道
     */
    public function signUpChannel($channel_id, $data)
    {
        if (!isset($this->channel[$channel_id])) return false;
        $return = array(
            'code' => 200,
            'msg' => '',
            'channelInfo' => array()
        );

        if($channel_id == 1){
            $data['bankcardImage1'] = XbLib_FileHandle::getFileMessage($data['bankcardImage1']);
            $data['bankcardImage2'] = XbLib_FileHandle::getFileMessage($data['bankcardImage2']);
            $data['idcardImage1'] = XbLib_FileHandle::getFileMessage($data['idcardImage1']);
            $data['idcardImage2'] = XbLib_FileHandle::getFileMessage($data['idcardImage2']);

            //处理用户图片，如果大于500K，则剪裁一下
            $fileSize = 511000;
            if ($data['bankcardImage1']['size'] > $fileSize) $data['bankcardImage1'] = XbLib_FileHandle::reSizeImg($data['bankcardImage1']['path'], 400, 400);
            if ($data['bankcardImage2']['size'] > $fileSize) $data['bankcardImage2'] = XbLib_FileHandle::reSizeImg($data['bankcardImage2']['path'], 400, 400);
            if ($data['idcardImage1']['size'] > $fileSize) $data['idcardImage1'] = XbLib_FileHandle::reSizeImg($data['idcardImage1']['path'], 400, 400);
            if ($data['idcardImage2']['size'] > $fileSize) $data['idcardImage2'] = XbLib_FileHandle::reSizeImg($data['idcardImage2']['path'], 400, 400);
        }

        $channelInfo = XbModule_Account_Channel::getInstance()->getChannelByChannelid($channel_id);
        if ($channelInfo) {
            $channelObj = $this->getChannelObj($this->channel[$channel_id]);
            $signUpInfo = $channelObj->buildSignData($data)->signUp();
//            var_dump($channelObj,$data,$signUpInfo);die();
            if (isset($signUpInfo['channel_code'])) {
                $channel_key = $signUpInfo['channel_key'] ? $signUpInfo['channel_key'] : '';
                $return['channelInfo'][] = array('channel_id' => $channel_id, 'channel_code' => $signUpInfo['channel_code'], 'channel_key' => $channel_key);
            }else{
                //进件失败
                $param = array_merge($signUpInfo, array('uid' => $data['uid'], 'channel_id' => $channel_id, 'create_time' => time()));
                $res = XbModule_Account_UsersProfile::getInstance()->userChannelError($param);
            }
        }
        XbFunc_Log::write('fujian', '用户【' . $data['phone'] . '】返回数据：' . json_encode($return));
        return $return;
    }

    /**
     * @desc    查询用户审核状态
     * @param   int $channel_id 通道channel_id
     * @param   array $data array('channel_code'=>'')
     * @return  array   $return         返回查询状态
     */
    public function getUserStatus($channel_id, $data)
    {
        if (!isset($this->channel[$channel_id])) return false;
        $channelObj = $this->getChannelObj($this->channel[$channel_id]);
        $res = $channelObj->buildSignData($data)->auditUserStatus();
        return $res;
    }

    /**
     * @desc    用户注册通道
     * @param   int     $channel_id     通道channel_id
     * @param   array   $data           下单数据
     * @return  array   $return         返回下单资料
     */
    public function userSignUp($channel_id, $data){
        if(!isset($this->channel[$channel_id])) return false;
        $channelObj = $this->getChannelObj($this->channel[$channel_id]);
        $res = $channelObj->buildSignData($data)->signUp();
        return $res;
    }

    /**
     * @desc    用户下单
     * @param   int $channel_id 通道channel_id
     * @param   array $data 下单数据
     * @return  array   $return         返回下单资料
     */
    public function createOrder($channel_id, $data)
    {
        if (!isset($this->channel[$channel_id])) return false;
        $channelObj = $this->getChannelObj($this->channel[$channel_id]);
        $res = $channelObj->buildSignData($data)->transaction();
        return $res;
    }
    //调用提现接口

    /**
     * @desc 结算接口
     */
    public function settlement($channel_id, $data)
    {
        if (!isset($this->channel[$channel_id])) return false;
        $channelObj = $this->getChannelObj($this->channel[$channel_id]);
        $result = $channelObj->buildSignData($data)->withdraw();
        return $result;
    }

    /**
     * @desc 订单查询
     */
    public function tradeRevice($channel_id, $data)
    {
        if (!isset($this->channel[$channel_id])) return false;
        $channelObj = $this->getChannelObj($this->channel[$channel_id]);
        $result = $channelObj->buildSignData($data)->tradeRevice();
        return $result;
    }

    /**
     * @desc 获取用户通道信息
     */
    public function getUserData($channel_id, $data)
    {
        if (!isset($this->channel[$channel_id])) return false;
        $channelObj = $this->getChannelObj($this->channel[$channel_id]);
        $result = $channelObj->buildSignData($data)->getUserData();
        return $result;
    }

    /**
     * @desc 获取用户余额
     */
    public function userBalance($channel_id, $data)
    {
        if (!isset($this->channel[$channel_id])) return false;
        $channelObj = $this->getChannelObj($this->channel[$channel_id]);
        $result = $channelObj->buildSignData($data)->userBalance();
        return $result;
    }

    /**
     * @desc 获取商户秘钥
     */
    public function gerUserKey($channel_id, $data)
    {
        if (!isset($this->channel[$channel_id])) return false;
        $channelObj = $this->getChannelObj($this->channel[$channel_id]);
        $result = $channelObj->buildSignData($data)->gerUserKey();
        return $result;
    }

    /**
     * @desc 修改用户费率
     * */
    public function updateRate($channel_id, $data)
    {
        if (!isset($this->channel[$channel_id])) return false;
        $channelObj = $this->getChannelObj($this->channel[$channel_id]);
        $result = $channelObj->buildSignData($data)->updateRate();
        return $result;
    }

    /**
     * @desc  获取通道是否支持当前信用卡
     * */
    public function getChannelBankList($channel_id, $data)
    {
        if (!isset($this->channel[$channel_id])) return false;
        if (in_array($channel_id, array(2, 3, 4, 7, 8, 9)) && $data['type'] == 2) return true;
        $res = XbModule_Account_Channel::getInstance()->getChannelBankList($channel_id, $data['type']);
        $is_check = false;
        if ($res) {
            foreach ($res as $key => $val) {
                if ($data['bankCode'] == $val['bankCode']) {
                    $is_check = $val;
                }
            }
        }
        return $is_check;
    }

    /**
     * @desc 结算订单查询
     */
    public function transfer($channel_id, $data)
    {
        if (!isset($this->channel[$channel_id])) return false;
        $channelObj = $this->getChannelObj($this->channel[$channel_id]);
        $result = $channelObj->buildSignData($data)->transfer();
        return $result;
    }

    /*
     * @desc 获取web跳转地址
     * */
    public function getWebUrl()
    {
        return 'https://m.xiaobaijinfu.com/dist/login#/dist/tit_webview';
    }

    /**
     * @desc 获取当前通道
     * */
    public function getChannelList()
    {
        return $this->channel;
    }
    
    /**
     * 修改结算储蓄卡信息
     * 
     * @param unknown $channel_id 频道id
     * @param unknown $data 数据（不需要order_id）
     * @return array [ code => 错误编号 0 成功 其它失败 msg => 错误信息 ]
     */
    public function updateUserBankAccount($channel_id, $data, $updateUserPhone = false) {
        if (!isset($this->channel[$channel_id])) return false;
        $channelObj = $this->getChannelObj($this->channel[$channel_id]);
        $result = $channelObj->buildSignData($data)->updateUserBankAccount($updateUserPhone);
        return $result;
    }
}
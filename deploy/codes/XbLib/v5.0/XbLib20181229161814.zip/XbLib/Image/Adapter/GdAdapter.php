<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2015-8-24
 * UTF-8
 */
class XbLib_Image_Adapter_GdAdapter extends XbLib_Image_Abstract {
	
	/*
	 * (non-PHPdoc) @see XbLib_Image_Abstract::getImgObj()
	 */
	protected function loadImgObj($img_path) {
		// TODO Auto-generated method stub
		switch ($this->imagesize ['mime']) {
			case 'image/jpg' :
			case 'image/jpeg' :
			case 'image/pjpeg' :
				$this->img = imagecreatefromjpeg ( $img_path );
				break;
			case 'image/png' :
				$this->img = imagecreatefrompng ( $img_path );
				break;
			case 'image/gif' :
				$this->img = imagecreatefromgif ( $img_path );
				break;
		}
	}
	
	/*
	 * (non-PHPdoc) @see XbLib_Image_Abstract::thumb()
	 */
	public function thumb($width, $height, $color = array()) {
		// TODO Auto-generated method stub
		$dst_width = 0;
		$dst_height = 0;
		$dst_x = 0;
		$dst_y = 0;
		
		// 无填充颜色 留白
		if (! empty ( $color )) {
			$dst_img = imagecreatetruecolor ( $width, $height );
			$dst_width = $width;
			$dst_height = $height;
		}
		
		// 原图比需要的扁 按照宽度缩放 否则 按照高度比缩放
		if ($this->imagesize [0] / $this->imagesize [1] > $width / $height) {
			//重新计算高度
			$height = intval ( $width / $this->imagesize [0] * $this->imagesize [1] );
			
		} else {
			$width = intval ( $height / $this->imagesize [1] * $this->imagesize [0] );
		}
		$this->width = $width;
		$this->height = $height;
		
		//合并画布画布
		if(!empty($color)){
			if($dst_height > $height){
				//调整高度居中位置
				$dst_y = intval(($dst_height - $height)/2);
			}
			if($dst_width > $width){
				//调整高度居中位置
				$dst_x = intval(($dst_width - $width)/2);
			}
			
			imagecolorallocate ( $dst_img, $color ['red'], $color ['green'], $color ['blue'] );
			$color = imagecolorallocate($dst_img, $color ['red'], $color ['green'], $color ['blue']);
			imagefill($dst_img, 0, 0, $color);
			imagecopyresampled ( $dst_img, $this->img, $dst_x, $dst_y, 0, 0, $this->width, $this->height, $this->imagesize [0], $this->imagesize [1] );
		}else{
			$dst_img = imagecreatetruecolor ( $this->width, $this->height );
			imagecopyresampled ( $dst_img, $this->img, $dst_x, $dst_y, 0, 0, $this->width, $this->height, $this->imagesize [0], $this->imagesize [1] );
		}
		

		$this->img = $dst_img;
	}
	
	/*
	 * (non-PHPdoc) @see XbLib_Image_Abstract::rotate()
	 */
	public function rotate($angle) {
		// TODO Auto-generated method stub
		$this->img = imagerotate ( $this->img, $angle, 0 );
		if (empty ( $this->img )) {
			return false;
		}
		// 重置长宽
		$this->imagesize [0] = imagesx ( $this->img );
		$this->imagesize [1] = imagesy ( $this->img );
		return true;
	}
	
	/*
	 * (non-PHPdoc) @see XbLib_Image_Abstract::watermark()
	 * 未测试
	 */
	public function watermark($waterFilePath) {
		// TODO Auto-generated method stub
		if (! file_exists ( $waterFilePath )) {
			return false;
		}
		
		$watermark_imagesize = getimagesize ( $waterFilePath );
		if (empty ( $watermark_imagesize )) {
			return false;
		}
		$watermark_image = null;
		switch ($watermark_imagesize ['mime']) {
			case 'image/jpg' :
			case 'image/jpeg' :
			case 'image/pjpeg' :
				$watermark_image = imagecreatefromjpeg ( $waterFilePath );
				break;
			case 'image/png' :
				$watermark_image = imagecreatefrompng ( $waterFilePath );
				break;
			case 'image/gif' :
				$watermark_image = imagecreatefromgif ( $waterFilePath );
				break;
		}
		imagecopyresampled ( $this->img, $watermark_image, 0, 0, 0, 0, $this->width, $this->height, $this->width, $this->height );
	}
	/*
	 * (non-PHPdoc) @see XbLib_Image_Abstract::output()
	 */
	public function output() {
		// TODO Auto-generated method stub
		header ( "content-type: {$this->imagesize ['mime']}" );
		switch ($this->imagesize ['mime']) {
			case 'image/jpg' :
			case 'image/jpeg' :
			case 'image/pjpeg' :
				imagejpeg ( $this->img );
				break;
			case 'image/png' :
				imagepng ( $this->img );
				$file_extend = '.png';
				break;
			case 'image/gif' :
				imagegif ( $this->img );
				break;
		}
	}
	
	/*
	 * (non-PHPdoc) @see XbLib_Image_Abstract::save()
	 */
	public function save($newPath) {
		// TODO Auto-generated method stub
		$res = false;
		switch ($this->imagesize ['mime']) {
			case 'image/jpg' :
			case 'image/jpeg' :
			case 'image/pjpeg' :
				$res = imagejpeg ( $this->img, $newPath );
				break;
			case 'image/png' :
				$res = imagepng ( $this->img, $newPath );
				$file_extend = '.png';
				break;
			case 'image/gif' :
				$res = imagegif ( $this->img, $newPath );
				break;
		}
		return $res;
	}
	/* (non-PHPdoc)
	 * @see XbLib_Image_Abstract::destroyImgResource()
	 */
	public function destroyImgResource() {
		// TODO Auto-generated method stub
		imagedestroy($this->img);
	}

}
<?php

/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2015年12月23日
 * UTF-8
 */
class XbLib_SinaPay_Config
{

	/**
	 * 接口版本，新浪支付接口文档参数
	 */
	private $version = "1.0";

	/**
	 * 商户号，由新浪支付提供
	 */
	private $partner_id = "200004595271";

	/**
	 * 商户MD5KEY秘钥，由商户提供
	 */
	private $md5_key = "1234567890qwertyuiopasdfghjklzxc";

	/**
	 * 商户接口字符集，新浪支付接口文档参数
	 */
	private $input_charset = "utf-8";

	/**
	 * 商户签名私钥，由商户自己生成
	 * 签名私钥
	 */
	private $rsa_sign_private_key = "";

	/**
	 * 商户验证签名公钥，由新浪提供
	 * 验证签名公钥
	 */
	private $rsa_sign_public_key = "";

	/**
	 * 新浪支付特殊参数加密，公钥，由新浪支付提供
	 * 加密公钥
	 */
	private $rsa_public_key = "";

	/**
	 * 网关地址，接口文档参数
	 * 会员网关地址
	 */
	private $wpay_url = "https://testgate.pay.sina.com.cn/mgs/gateway.do";
	
	/**
	 * 托管/支付网关地址
	 * @var unknown
	 */
	private $opay_url = "https://testgate.pay.sina.com.cn/mas/gateway.do";
	
	//sftp配置
	private $sinapay_sftp_address = "222.73.39.37";
	
	private $sinapay_sftp_port = "50022";
	
	private $sinapay_sftp_Username = "200004595271";
	
	private $sinapay_sftp_private_key = "";
	
	private $sinapay_sftp_public_key = "";
	
	/**
	 * 操作支付密码返回地址
	 * @var unknown
	 */
	private $op_pay_return_url = "https://account.cinfax.com/profile/account";
	
	/**
	 * 充值returnURL
	 * @var unknown
	 */
	private $deposit_return_url = "https://account.cinfax.com/profile";
	
	/**
	 * 充值notifyURL
	 * @var unknown
	 */
	private $deposit_notify_url = "https://account.cinfax.com/notify/deposit";
	
	/**
	 * 提现return
	 * @var unknown
	 */
	private $withdraw_return_url = "https://account.cinfax.com/profile";
	
	/**
	 * 提现notifyURL
	 * 
	 * @var unknown
	 */
	private $withdraw_notify_url = "https://account.cinfax.com/notify/withdraw";
	
	/**
	 * 托管待收交易返回地址
	 * @var unknown
	 */
	private $hostingCollectTrade_return_url = "https://account.cinfax.com/profile/index";
	
	/**
	 * 托管待收交易通知地址
	 * @var unknown
	 */
	private $hostingCollectTrade_notify_url = "https://account.cinfax.com/notify/orderpay";
	
	/**
	 * 托管待收交易通知地址--企业还款
	 * @var unknown
	 */
	private $hostingCollectTrade_notify_payback_url= "https://account.cinfax.com/notify/payback";
	
	/**
	 * 托管代付本金/利息 交易通知地址
	 * @var unknown
	 */
	private $singleHostingPayTrade_notify_url = "https://account.cinfax.com/notify/payment";
	
	/**
	 * 托管代付本金/利息 交易通知地址--分红
	 * @var unknown
	 */
	private $singleHostingPayTrade_notify_bonusurl = "https://account.cinfax.com/notify/bonus";
	
	/**
	 * 托管退款 交易通知地址
	 * @var unknown
	 */
	private $hostingRefund_notify_url= "https://account.cinfax.com/notify/refund";
	
	/**
	 * 企业会员回执
	 * @var unknown
	 */
	private $auditMemberInfos_NotifyUrl = "https://account.cinfax.com/notify/auditmember";
	

	/**
	 * 返回码
	 * 
	 * @var unknown $response_code
	 */
	private $response_code = array(
		'APPLY_SUCCESS' => '提交成功，存在业务响应的以业务响应状态为准',
		'AUTHORIZE_FAIL' => '授权失败',
		'AUTH_INVALID_DATE' => '商户该接口授权已过期',
		'ADD_VERIFY_FAIL' => '添加认证信息失败',
		'ADVANCE_FAILED' => '支付或绑卡推进失败',
		'BANK_ACCOUNT_NOT_EXISTS' => '银行卡信息不存在',
		'BANK_ACCOUNT_TOO_MANY' => '绑定银行卡数量超限',
		'BANK_CARD_NOT_VERIFIED' => '银行卡未认证',
		'BANK_CODE_NOT_SUPPORT' => '暂不支持该银行',
		'BANK_CARD_NOT_EFFECT' => '银行卡未生效',
		'BANK_CARD_NOT_SIGN' => '银行卡未签约',
		'BANK_INFO_VERIFY_FAILED' => '银行卡信息校验失败',
		'BIND_CARD_FAILED' => '绑卡失败',
		'BIZ_PENDING' => '业务处理中，等待通知或查询',
		'BLANCE_NOT_ENOUGH' => '余额不足',
		'CARD_TYPE_NOT_SUPPORT' => '卡类型暂不支持',
		'CERT_NOT_EXIST' => '证件号不存在，请提前实名认证',
		'CERTNO_NOT_MATCHING' => '证件号不匹配',
		'DUPLICATE_IDENTITY_ID' => '用户标识信息重复',
		'DUPLICATE_OUT_FREEZE_NO' => '冻结订单号重复',
		'DUPLICATE_OUT_UNFREEZE_NO' => '解冻订单号重复',
		'DUPLICATE_REQUEST_NO' => '重复的请求号',
		'DUPLICATE_VERIFY' => '会员认证信息重复',
		'FREEZE_FUND_FAIL' => '冻结余额失败',
		'FREEZE_FUND_PROCESSING' => '冻结余额处理中，请联系管理员',
		'GET_VERIFY_FAIL' => '查询认证信息失败',
		'HOST_PAY_NOT_SUPPORT_REFUND' => '代付交易不允许退款',
		'ILLEGAL_ACCESS_SWITCH_SYSTEM' => '不允许访问该类型的接口',
		'ILLEGAL_ARGUMENT' => '参数校验未通过',
		'ILLEGAL_DECRYPT' => '解密失败，请检查加密字段',
		'ILLEGAL_INDETITY_PALTFORMTYPE' => '用户标识信息中不存在该平台标志',
		'ILLEGAL_IP_OR_DOMAIN' => '非法的商户IP或域名',
		'ILLEGAL_OUTER_TRADE_NO' => '交易订单号不存在',
		'ILLEGAL_SERVICE' => '服务接口不存在',
		'ILLEGAL_SIGN' => '验签未通过',
		'ILLEGAL_SIGN_TYPE' => '签名类型不正确',
		'INCORRECT_CARD_INFORMATION' => '用户卡信息有误',
		'INSUFFICIENT_FREEZE_BALANCE' => '超过可冻结金额',
		'INSUFFICIENT_UNFREEZE_BALANCE' => '超过可解冻金额',
		'MEMBER_ID_NOT_EXIST' => '用户不存在',
		'MEMBER_NOT_EXIST' => '用户标识信息不存在',
		'NO_BANK_CARD_INFO' => '无相关银行卡信息',
		'NO_BASIC_ACCOUNT' => '用户无基本账户信息或没有激活',
		'NO_FUND_ORIG_FREEEZE_TRADE' => '原冻结交易不存在',
		'NO_SUCH_MERCHANT' => '该商户信息不存在',
		'ORDER_NOT_EXIST' => '订单不存在',
		'OTHER_ERROR' => '其它错误',
		'PARAMETER_INVALID' => '请求参数不合法',
		'PARTNER_ID_NOT_EXIST' => '合作方Id不存在',
		'PAY_METHOD_NOT_SUPPORT' => '支付方式不支持',
		'PAYER_INCONSISTENT' => '订单批量支付付款人信息不一致',
		'PAYMENT_DUPLIDATE' => '重复支付',
		'PAY_FAILED' => '支付失败',
		'REALNAME_CONFIRM_FAILED' => '实名认证不通过',
		'REAL_NAME_NOT_MATCHING' => '实名不匹配',
		'REQUEST_METHOD_NOT_VALIDATE' => '请求方式不合法',
		'REQUEST_EXPIRED' => '请求过期',
		'SAVING_POT_ACCOUNT_OPEN_FAILED' => '存钱罐账户开户失败',
		'SYSTEM_ERROR' => '系统内部错误',
		'TRADE_AMOUNT_MODIFIED' => '交易金额修改不合法',
		'TRADE_CLOSED' => '交易关闭',
		'TRADE_FAILED' => '交易调用失败',
		'TRADE_NO_MATCH_ERROR' => '交易号信息有误',
		'USER_BANK_ACCOUNT_NOT_MATCH' => '用户银行卡信息不匹配',
		'VERIFY_NOT_EXIST' => '认证信息不存在',
		'VERIFY_BINDED_OVERRUN' => '认证信息绑定超限',
		'UNBINDING_SECURITY_CARD_FORBIDDING' => '安全卡当余额及存钱罐为0时才可解绑',
		'BIZ_CHECK_EXCEPTION' => '业务校验异常',
		'UPLOAD_FILE_FAIL' => '上传文件失败',
		'CHECK_FILE_DIGEST_FAIL' => '文件摘要验证失败',
		'ACCOUNT_NOT_EXIST' => '账户信息不存在',
		'AUTHORIZE_FAIL' => '授权失败',
		'MERCHANT_BUILD_FAIL' => '构建商户基本信息失败',
		'MERCHANT_SUBMIT_AUDIT_SUCCESS' => '商户审核请求成功',
		'MERCHANT_SUBMIT_AUDIT_FAIL' => '商户审核请求失败',
		'MERCHANT_AUDIT_REQ_IS_EMPTY' => '商户审核请求信息不合法',
		'FORBIDDEN_REPEAT_REQUEST' => '短时间内禁止重复请求',
		'AUDIT_PROCESSING' => '审核处理中，请不要重复提交',
		'AUDIT_SUCCESS' => '审核已通过，请不要重复提交',
		'AUDIT_REFUSED' => '审核驳回，请重新提交信息',
		'AUDIT_NOTHING' => '无任何审核信息',
		'BINDING_BANK_CARD_FAILD' => '绑银行卡失败',
		'FILE_NOT_FOUND' => '文件不存在',
		'MERCHANT_OPEN_ACCOUNT_FAIL' => '开户失败',
		'MERCHANT_OPEN_REQ_ERROR' => '开户参数不合法',
		'ILLEGAL_PARTY_INFO' => '参与方信息不合法',
		'INSPECT_FILTER_FAIL' => '鉴权未通过',
		'INSPECT_FILTER_SAFECARD_FAIL' => '鉴权安全卡未通过',
		'QUERY_IS_SAFECARD_SUPPORT_FAIL' => '查询是否安全卡支持错误',
		"PAYPWD_HAS_SET" => '支付密码已经设置过了',
	);

	/**
	 * 银行编码
	 * 
	 * @param unknown $config        	
	 */
	private $bank_code = array(
		'BOC' => array("name"=>'中国银行'),
		'CMB' => array("name"=>'招商银行'),
		'ICBC' => array("name"=>'工商银行'),
		'CCB' => array("name"=>'建设银行'),
		'COMM' => array("name"=>'交通银行'),
		'HXB' => array("name"=>'华夏银行'),
		'SPDB' => array("name"=>'浦东发展银行'),
		'ABC' => array("name"=>'农业银行'),
		'BOS' => array("name"=>'上海银行'),
		'CEB' => array("name"=>'光大银行'),
		'CIB' => array("name"=>'兴业银行'),
		'BCCB' => array("name"=>'北京银行'),
		'BJRCB' => array("name"=>'北京农商行'),
		'CITIC' => array("name"=>'中信银行'),
		'CMBC' => array("name"=>'民生银行'),
		'PSBC' => array("name"=>'中国邮储银行'),
		'GNXS' => array("name"=>'广州市农信社'),
		'GZCB' => array("name"=>'广州市商业银行'),
		'HCCB' => array("name"=>'杭州银行'),
		'HKBCHINA' => array("name"=>'汉口银行'),
		'HSBANK' => array("name"=>'徽商银行'),
		'CBHB' => array("name"=>'渤海银行'),
		'CCQTGB' => array("name"=>'重庆三峡银行'),
		'NBCB' => array("name"=>'宁波银行'),
		'NJCB' => array("name"=>'南京银行'),
		'SHRCB' => array("name"=>'上海农村商业银行'),
		'SNXS' => array("name"=>'深圳农村商业银行'),
		'SXJS' => array("name"=>'晋城市商业银行'),
		'CSCB' => array("name"=>'长沙银行'),
		'SZPAB' => array("name"=>'平安银行'),
		'CZB' => array("name"=>'浙商银行'),
		'UPOP' => array("name"=>'银联在线支付'),
		'CZCB' => array("name"=>'浙江稠州商业银行'),
		'WZCB' => array("name"=>'温州市商业银行'),
		'GDB' => array("name"=>'广东发展银行')
	);
	
	private $pay_method = array(
		'online_bank' => '网银支付',
		'balance' => '余额支付',
		'quick_pay' => '快捷支付',
		'binding_pay' => '绑定支付'
	);

	public function __construct($config = null)
	{
		if (! empty($config)) {
			if (! empty($config['version'])) {
				$this->version = $config['version'];
			}
			if (! empty($config['input_charset'])) {
				$this->input_charset = $config['input_charset'];
			}
			if (! empty($config['wpay_url'])) {
				$this->wpay_url = $config['wpay_url'];
			}
			$this->md5_key = $config['md5_key'];
			$this->partner_id = $config['partner_id'];
			$this->rsa_sign_private_key = $config['rsa_sign_private_key'];
			$this->rsa_sign_public_key = $config['rsa_sign_public_key'];
			$this->rsa_public_key = $config['rsa_public__key'];
		}
	}

	/**
	 * 获得接口版本
	 */
	public function getVersion()
	{
		return $this->version;
	}

	/**
	 * 获得商户号
	 */
	public function getPartnerId()
	{
		return $this->partner_id;
	}

	/**
	 * 获得MD5 KEY
	 */
	public function getMd5Key()
	{
		return $this->md5_key;
	}

	/**
	 * 获得文件编码
	 */
	public function getCharset()
	{
		return $this->input_charset;
	}

	/**
	 * 获得网关地址
	 */
	public function getWpayurl()
	{
		return $this->wpay_url;
	}
	
	public function getSftpAddress(){
		return $this->sinapay_sftp_address;
	}
	
	public function getSftpPort(){
		return $this->sinapay_sftp_port;
	}
	
	public function getSftpUserName(){
		return $this->sinapay_sftp_Username;
	}
	
	public function getSftpPrivateKey(){
		if (empty($this->sinapay_sftp_private_key)) {
			// 赋值默认
			$file_path = realpath(dirname(__File__)) . "/Key/id_rsa";
			$this->sinapay_sftp_private_key = file_get_contents($file_path);
		}
		return $file_path;
	}
	
	public function getSftpPublicKey(){
		if (empty($this->sinapay_sftp_public_key)) {
			// 赋值默认
			$file_path = realpath(dirname(__File__)) . "/Key/id_rsa.pub";
			$this->sinapay_sftp_public_key = file_get_contents($file_path);
		}
		return $file_path;
	}

	/**
	 * 获得签名私钥
	 */
	public function getRsaSignPrivateKey()
	{
		if (empty($this->rsa_sign_private_key)) {
			// 赋值默认
			$file_path = realpath(dirname(__File__)) . "/Key/rsa_sign_private.pem";
			$this->rsa_sign_private_key = file_get_contents($file_path);
		}
		return $this->rsa_sign_private_key;
	}

	/**
	 * 获得新浪签名公钥
	 */
	public function getRsaSignPublicKey()
	{
		if (empty($this->rsa_sign_public_key)) {
			// 赋值默认
			$file_path = realpath(dirname(__File__)) . "/Key/rsa_sign_public.pem";
			$this->rsa_sign_public_key = file_get_contents($file_path);
		}
		
		return $this->rsa_sign_public_key;
	}

	/**
	 * 获得新浪支付特殊参数加密公钥
	 */
	public function getRsaPublicKey()
	{
		if (empty($this->rsa_public_key)) {
			// 赋值默认
			$file_path = realpath(dirname(__File__)) . "/Key/rsa_public.pem";
			$this->rsa_public_key = file_get_contents($file_path);
		}
		return $this->rsa_public_key;
	}

	/**
	 * 获得加密类型
	 */
	public function getSignType()
	{
		return "MD5";
	}

	/**
	 * 根据返回码获得对应消息
	 * 
	 * @param unknown $response_code        	
	 */
	public function getResponseMsg($response_code)
	{
		if (isset($this->response_code[$response_code])) {
			return $this->response_code[$response_code];
		}
		return '';
	}
	
	/**
	 * 获得银行编码
	 * @return array
	 */
	public function getBankCode(){
		return $this->bank_code;
	}
	
	/**
	 * 获得支付密码操作回调地址
	 */
	public function getOpPayReturnUrl(){
		return $this->op_pay_return_url;
	}
	
	/**
	 * 获得支付方式数组
	 */
	public function getPayMethod(){
		return $this->pay_method;
	}
	
	/**
	 * 获得订单类网关地址
	 */
	public function getOpayUrl(){
		return $this->opay_url;
	}
	
	/**
	 * 获得充值返回地址
	 */
	public function getDepositReturnUrl(){
		return $this->deposit_return_url;
	}
	
	/**
	 * 获得充值通知地址
	 */
	public function getDepositNotifyUrl(){
		return $this->deposit_notify_url;
	}
	
	/**
	 * 提现返回地址
	 */
	public function getWithdrawReturnUrl(){
		return $this->withdraw_return_url;
	}
	
	/**
	 * 提现通知地址
	 */
	public function getWithdrawNotifyUrl(){
		return $this->withdraw_notify_url;
	}
	
	/**
	 * 托管代收返回地址
	 */
	public function getHostingCollectTradeReturnUrl(){
		return $this->hostingCollectTrade_return_url;
	}
	
	/**
	 * 托管代收通知地址
	 */
	public function getHostingCollectTradeNotifyUrl(){
		return $this->hostingCollectTrade_notify_url;
	}
	
	/**
	 * 托管代收通知地址--企业还款
	 */
	public function getHostingCollectTradeNotifyPayBackUrl(){
	    return $this->hostingCollectTrade_notify_payback_url;
	}
	
	/**
	 * 托管代付本金/利息通知地址
	 */
	public function getSingleHostingPayTrade_notify_url(){
		return $this->singleHostingPayTrade_notify_url;
	}
	
	/**
	 * 托管代付本金/利息通知地址--分红
	 */
	public function getSingleHostingPayTrade_notify_bonusurl(){
	    return $this->singleHostingPayTrade_notify_bonusurl;
	}
	
	/**
	 * 托管退款通知地址
	 */
	public function getHostingRefund_notify_url(){
	    return $this->hostingRefund_notify_url;
	}
	
	/**
	 * 企业会员通知地址
	 */
	public function getAuditMemberInfos_notify_url(){
		return $this->auditMemberInfos_NotifyUrl;
	}
	
}
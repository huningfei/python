<?php

/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2015年12月23日
 * UTF-8
 */
class XbLib_SinaPay_User
{

	private static $obj = null;

	/**
	 *
	 * @var XbLib_SinaPay_Config
	 */
	private $configObj = null;

	private $weiboTools = null;

	/**
	 * 封闭构造
	 *
	 * @param unknown $configObj        	
	 */
	private function __construct($configObj)
	{
		$this->configObj = $configObj;
		$this->weiboTools = new XbLib_SinaPay_Lib_Weibo($configObj);
	}

	/**
	 * 单例
	 *
	 * @param unknown $configObj        	
	 * @return XbLib_SinaPay_User
	 */
	public static function getInstance($configObj)
	{
		if (empty($configObj) || ! ($configObj instanceof XbLib_SinaPay_Config)) {
			return false;
		}
		if (is_null(self::$obj)) {
			self::$obj = new XbLib_SinaPay_User($configObj);
		}
		return self::$obj;
	}

	/**
	 * 创建会员
	 *
	 * @param unknown $uid        	
	 * @param unknown $member_type       1个人 2企业 	
	 * @param string $identity_type        	
	 * @return boolean
	 */
	public function createActivateMember($uid, $member_type)
	{
		$uid = intval($uid);
		if ($uid < 1) {
			return false;
		}
		if (! in_array($member_type, array(
			1,
			2
		), true)) {
			return false;
		}
		
		$data = array();
		$data['identity_id'] = $uid;
		// 用户类别UID
		$data['identity_type'] = "UID";
		$data['member_type'] = $member_type;
		$result = $this->processData("create_activate_member", $data);
		if ($result['response_code'] == "APPLY_SUCCESS") {
			return true;
		}
		
		return false;
	}

	/**
	 * 设置实名信息
	 *
	 * @param unknown $uid        	
	 * @param unknown $realname        	
	 * @param unknown $cert_no        	
	 * @param string $identity_type        	
	 * @param string $cert_type        	
	 * @return boolean true 认证成功
	 *         false 认证失败或者已经认证过了
	 */
	public function setRealName($uid, $realname, $cert_no, $cert_type = "IC")
	{
		$uid = intval($uid);
		$realname = trim($realname);
		$cert_no = trim($cert_no);
		$cert_type = trim($cert_type);
		if ($uid < 1) {
			return false;
		}
		if (empty($realname) || empty($cert_no)) {
			return false;
		}
		if (! in_array($cert_type, array(
			"IC",
			"PP",
			"HMP"
		), true)) {
			return false;
		}
		
		$cert_no_rsa = $this->weiboTools->Rsa_encrypt($cert_no, $this->configObj->getRsaPublicKey()); // 对身份证号进行rsa公钥加密
		$real_name_rsa = $this->weiboTools->Rsa_encrypt($realname, $this->configObj->getRsaPublicKey()); // 对用户姓名进行rsa公钥加密
		
		$service = "set_real_name";
		$data = array();
		$data['identity_id'] = $uid;
		$data['real_name'] = $real_name_rsa;
		$data['cert_type'] = $cert_type;
		$data['cert_no'] = $cert_no_rsa;
		$data['need_confirm'] = 'Y';
		// 用户类别UID
		$data['identity_type'] = "UID";
		$res = $this->processData($service, $data);
		if ($res['response_code'] == "APPLY_SUCCESS") {
			return true;
		}
		return false;
	}

	/**
	 * 设置 修改 找回 支付密码
	 *
	 * @param unknown $uid        	
	 * @param string $service        	
	 */
	public function opPayPassword($uid, $service = "set_pay_password")
	{
		$uid = intval($uid);
		if ($uid < 1) {
			return false;
		}
		if (! in_array($service, array(
			"set_pay_password",
			"modify_pay_password",
			"find_pay_password"
		), true)) {
			return false;
		}
		
		$data = array();
		$data['service'] = $service;
		$data['identity_id'] = $uid;
		// 用户类别UID
		$data['identity_type'] = "UID";
		$data['return_url'] = $this->configObj->getOpPayReturnUrl();
		
		$res = $this->processData($service, $data);
		if ($res['response_code'] == "APPLY_SUCCESS") {
			return $res['redirect_url'];
		}
		return false;
	}

	/**
	 * 查询是否设置过密码
	 *
	 * @param unknown $uid        	
	 */
	public function queryIsSetPayPassword($uid)
	{
		$uid = intval($uid);
		if ($uid < 1) {
			return false;
		}
		$data = array();
		$service = "query_is_set_pay_password";
		$data['identity_id'] = $uid;
		// 用户类别UID
		$data['identity_type'] = "UID";
		$result = $this->processData($service, $data);
		if (isset($result['is_set_paypass']) && $result['is_set_paypass'] == "Y") {
			return true;
		}
		return false;
	}

	/**
	 * 查询账户余额
	 *
	 * @param unknown $uid        	
	 * @param string $account_type        	
	 */
	public function queryBalance($uid, $account_type = "SAVING_POT")
	{
		$uid = intval($uid);
		if ($uid < 1) {
			return false;
		}
		if (! in_array($account_type, array(
			'BASIC',
			"ENSURE",
			'SAVING_POT'
		))) {
			return false;
		}
		
		$service = "query_balance";
		$data = array();
		$data['identity_id'] = $uid;
		$data['account_type'] = $account_type;
		// 用户类别UID
		$data['identity_type'] = "UID";
		$res = $this->processData($service, $data);
		if ($res['response_code'] == "APPLY_SUCCESS") {
			$balance = array(
				"balance" => $res['balance'],
				"available_balance" => $res['available_balance'],
				"bonus" => $res['bonus']
			);
			return $balance;
		}
		return false;
	}

	/**
	 * 绑定银行卡
	 *
	 * @param unknown $request_no
	 *        	绑定请求号
	 * @param unknown $uid
	 *        	绑定uid
	 * @param unknown $bank_code
	 *        	身份证
	 * @param unknown $cert_no
	 *        	银行代码
	 * @param unknown $bank_account_no
	 *        	银行卡号
	 * @param unknown $phone_no
	 *        	手机号码
	 * @param unknown $province
	 *        	省份
	 * @param unknown $city
	 *        	城市
	 * @param unknown $bank_branch
	 *        	支行
	 * @param string $card_attribute
	 *        	卡属性 C对私 B对公
	 */
	public function bindingBankCard($request_no, $uid, $cert_no, $bank_code, $bank_account_no, $phone_no, $province, $city, $bank_branch, $card_attribute = "C")
	{
		$request_no = trim($request_no);
		$uid = intval($uid);
		$bank_code = trim($bank_code);
		$bank_account_no = trim($bank_account_no);
		$phone_no = trim($phone_no);
		$province = trim($province);
		$city = trim($province);
		$bank_branch = trim($bank_branch);
		$card_attribute = trim($card_attribute);
		$cert_no = trim($cert_no);
		
		if (empty($request_no) || empty($uid) || empty($cert_no) || empty($bank_code) || empty($bank_account_no) || empty($phone_no) || empty($province) || empty($city) || empty($bank_branch) || empty($card_attribute)) {
			return false;
		}
		if ($uid < 1) {
			return false;
		}
		// 校验bankcode合法性
		$bank_codes = $this->configObj->getBankCode();
		if (! isset($bank_codes[$bank_code])) {
			return false;
		}
		
		if (! in_array($card_attribute, array(
			"C",
			"B"
		), true)) {
			return false;
		}
		$cert_no_rsa = $this->weiboTools->Rsa_encrypt($cert_no, $this->configObj->getRsaPublicKey());
		$bank_account_no_rsa = $this->weiboTools->Rsa_encrypt($bank_account_no, $this->configObj->getRsaPublicKey()); // 对用户姓名进行rsa公钥加密
		$phone_no_rsa = $this->weiboTools->Rsa_encrypt($phone_no, $this->configObj->getRsaPublicKey()); // 对用户手机号进行rsa公钥加密
		
		$service = "binding_bank_card";
		$data = array();
		$data['card_type'] = 'DEBIT'; // 借记卡
		$data['verify_mode'] = "SIGN"; // 认证绑卡
		$data['identity_id'] = $uid; // uid
		$data['cert_no'] = $cert_no_rsa; // 身份证号
		$data['request_no'] = $request_no; // 请求号
		$data['bank_code'] = $bank_code; // 银行编码
		$data['bank_account_no'] = $bank_account_no_rsa; // 银行卡号
		$data['phone_no'] = $phone_no_rsa; // 手机号
		$data['province'] = $province; // 省份
		$data['city'] = $city; // 城市
		$data['card_attribute'] = $card_attribute; // 卡类型
		                                           // 用户类别UID
		$data['identity_type'] = "UID";
		$res = $this->processData($service, $data);
		
		if ($res['response_code'] == "APPLY_SUCCESS") {
			$arr = array(
				"ticket" => $res['ticket']
			);
			return $arr;
		}
		return false;
	}
	
	/**
	 * 申请企业会员
	 * @param unknown $audit_order_no 流水号
	 * @param unknown $uid UID
	 * @param unknown $company_name 公司名称
	 * @param unknown $address 公司地址
	 * @param unknown $license_no 注册号
	 * @param unknown $license_address 注册地址
	 * @param unknown $license_expire_date 注册有效期
	 * @param unknown $business_scope 经营范围
	 * @param unknown $telephone 联系电话
	 * @param unknown $email email
	 * @param unknown $organization_no 组织机构编码
	 * @param unknown $summary 企业介绍
	 * @param unknown $legal_person 法人
	 * @param unknown $cert_no 法人身份证号
	 * @param unknown $legal_person_phone 法人电话
	 * @param unknown $bank_code 银行编码
	 * @param unknown $bank_account_no 银行卡号
	 * @param unknown $province 地区
	 * @param unknown $city 城市
	 * @param unknown $bank_branch 支行
	 * @param unknown $filefullpath 文件全路径
	 * @param unknown $fileName 文件名称
	 */
	public function auditMemberInfos($audit_order_no,$uid,$company_name,$address,$license_no,$license_address,$license_expire_date,$business_scope,$telephone,$email,$organization_no,$summary,$legal_person,$cert_no,$legal_person_phone,$bank_code,$bank_account_no,$province,$city,$bank_branch,$filefullpath,$fileName){
		$data = array();
		$data['audit_order_no'] = $audit_order_no;
		$data['identity_id'] = $uid;
		$data['identity_type'] = "UID";
		$data['member_type'] = '2';
		$data['company_name'] = $company_name;
		$data['address'] = $address;
		$data['license_no'] = $this->weiboTools->Rsa_encrypt($license_no, $this->configObj->getRsaPublicKey());
		$data['license_address'] = $license_address;
		$data['license_expire_date'] = date("Ymd",$license_expire_date);
		$data['business_scope'] = $business_scope;
		$data['telephone'] = $this->weiboTools->Rsa_encrypt($telephone, $this->configObj->getRsaPublicKey());
		$data['email'] = $this->weiboTools->Rsa_encrypt($email, $this->configObj->getRsaPublicKey());
		$data['organization_no'] = $this->weiboTools->Rsa_encrypt($organization_no, $this->configObj->getRsaPublicKey());
		$data['summary'] = $summary;
		$data['legal_person'] = $this->weiboTools->Rsa_encrypt($legal_person, $this->configObj->getRsaPublicKey());
		$data['cert_no'] = $this->weiboTools->Rsa_encrypt($cert_no, $this->configObj->getRsaPublicKey());
		$data['cert_type'] = "IC";
		$data['legal_person_phone'] = $this->weiboTools->Rsa_encrypt($legal_person_phone, $this->configObj->getRsaPublicKey());
		$data['bank_code'] = $bank_code;
		$data['bank_account_no'] = $this->weiboTools->Rsa_encrypt($bank_account_no, $this->configObj->getRsaPublicKey());
		$data['card_type'] = "DEBIT";
		$data['card_attribute'] = "B";
		$data['province'] = $province;
		$data['city'] = $city;
		$data['bank_branch'] = $bank_branch;
		$digest = $this->weiboTools->md5_file($filefullpath);
		$data['fileName'] = $fileName;
		$data['digest'] = $digest;
		$data['digestType'] = "MD5";
		$data['notify_url'] = $this->configObj->getAuditMemberInfos_notify_url();
		$res = $this->weiboTools->sftp_upload($filefullpath, $fileName);
		if(!$res){
			XbFunc_Log::write("SinaPay_auditMemberInfos", "sftp_upload_failed",$filefullpath);
			return false;
		}
// 		var_dump($res);exit;
		$service = "audit_member_infos";
		$res = $this->processData($service, $data);
		return $res;
	}
	
	/**
	 * 查询企业审核结果
	 * @param unknown $uid
	 */
	public function queryAuditResult($uid){
		$service = "query_audit_result";
		$data = array();
		$data['identity_id'] = $uid;
		$data['identity_type'] = "UID";
		$res = $this->processData($service, $data);
		return $res;
	}
	
	/**
	 * 增加经办人信息
	 * @param unknown $uid
	 * @param unknown $name
	 * @param unknown $cert_no
	 * @param unknown $mobile
	 */
	public function smtFundAgentBuy($uid,$name,$cert_no,$mobile){
		$service = "smt_fund_agent_buy";
		$data = array();
		$data['identity_id'] = $uid;
		$data['identity_type'] = 'UID';
		$data['agent_name'] = $this->weiboTools->Rsa_encrypt($name, $this->configObj->getRsaPublicKey());
		$data['license_no'] = $this->weiboTools->Rsa_encrypt($cert_no, $this->configObj->getRsaPublicKey());
		$data['license_type_code'] = "ID";
		$data['agent_mobile'] = $this->weiboTools->Rsa_encrypt($mobile, $this->configObj->getRsaPublicKey());
		$res = $this->processData($service, $data);
		if ($res['response_code'] == "APPLY_SUCCESS") {
			return true;
		}
		return false;
	}

	/**
	 * 银行卡绑定推进
	 *
	 * @param unknown $ticket        	
	 * @param unknown $valid_code        	
	 */
	public function bindingBankCardAdvance($ticket, $valid_code)
	{
		$ticket = trim($ticket);
		$valid_code = trim($valid_code);
		if (empty($ticket) || empty($valid_code)) {
			return false;
		}
		// var_dump($ticket,$valid_code);exit;
		$data = array();
		$data['ticket'] = $ticket;
		$data['valid_code'] = $valid_code;
		
		$res = $this->processData("binding_bank_card_advance", $data);
		if ($res['response_code'] == "APPLY_SUCCESS") {
			$arr = array(
				"card_id" => $res['card_id'],
				"is_verified" => $res['is_verified']
			);
			return $arr;
		}
		return false;
	}

	public function unbindingBankCard($uid, $card_id)
	{
		$uid = intval($uid);
		$card_id = trim($card_id);
		if ($uid < 1) {
			return false;
		}
		
		$service = "unbinding_bank_card";
		$data = array();
		// 用户类别UID
		$data['identity_type'] = "UID";
		$data['identity_id'] = $uid;
		$data['card_id'] = $card_id;
		$res = $this->processData($service, $data);
		if ($res['response_code'] == "APPLY_SUCCESS") {
			return true;
		}
		return false;
	}

	/**
	 * 查询银行卡
	 *
	 * @param unknown $uid        	
	 * @param unknown $card_id        	
	 */
	public function queryBankCard($uid, $card_id)
	{
		$uid = intval($uid);
		$card_id = trim($card_id);
		if ($uid < 1) {
			return false;
		}
		$service = "query_bank_card";
		$data = array();
		// 用户类别UID
		$data['identity_type'] = "UID";
		$data['identity_id'] = $uid;
		$data['card_id'] = $card_id;
		$res = $this->processData($service, $data);
		if ($res['response_code'] == "APPLY_SUCCESS") {
			if (! isset($res['card_list'])) {
				return false;
			}
			$arrList = explode("|", $res['card_list']);
			if (empty($arrList)) {
				return false;
			}
			$card_list = array();
			foreach ($arrList as $card) {
				$cardArr = explode("^", $card);
				if (empty($cardArr)) {
					continue;
				}
				$card_prop['card_id'] = $cardArr[0];
				$card_prop['bank_code'] = $cardArr[1];
				$card_prop['bank_account_no'] = $cardArr[2];
				$card_prop['realname'] = $cardArr[3];
				$card_prop['card_type'] = $cardArr[4];
				$card_prop['card_attribute'] = $cardArr[5];
				$card_prop['verify_mode'] = $cardArr[6];
				$card_prop['create_time'] = $cardArr[7];
				$card_prop['save_card'] = $cardArr[8];
				$card_list[] = $card_prop;
			}
			
			return $card_list;
		}
		return false;
	}



	/**
	 * 提交服务接口
	 *
	 * @param unknown $service        	
	 * @param unknown $mergeData        	
	 * @return boolean | array
	 */
	private function processData($service, $mergeData)
	{
		$now = time();
		$data = array();
		// 接口名称
		$data['service'] = $service;
		// 接口版本
		$data['version'] = $this->configObj->getVersion();
		// 请求时间
		$data['request_time'] = date("YmdHis", $now);
		// 商户id
		$data['partner_id'] = $this->configObj->getPartnerId();
		// 字符集
		$data['_input_charset'] = $this->configObj->getCharset();
		$data = array_merge($data, $mergeData);
		
		// 签名类型
		$data['sign_type'] = $this->configObj->getSignType();
		// 签名
		$data['sign'] = $this->weiboTools->getSignMsg($data, $this->configObj->getSignType());
		// 调用createcurl_data创建模拟表单需要的数据
		$curl_data = $this->weiboTools->createcurl_data($data);
		$response = $this->weiboTools->curlPost($this->configObj->getWpayurl(), $curl_data);
		$response = urldecode($response);
		$result = json_decode($response, true);
		if(!is_array($result)){
			return false;
		}
		$res = $this->weiboTools->checkSignMsg($result, $this->configObj->getSignType());
		if (! $res) {
			XbFunc_Log::write("SinaPay", "CheckResponseSignError", json_encode($response));
			return false;
		}
		if ($result['response_code'] != "APPLY_SUCCESS") {
			$uid = null;
			if (isset($data['identity_id'])) {
				$uid = $data['identity_id'];
			}
			XbFunc_Log::write("SinaPayUser_{$service}", "{$result['response_code']}[{$this->configObj->getResponseMsg($result['response_code'])}][{$result['response_message']}]UID[$uid]", "request->" . json_encode($data) . "||response->" . json_encode($result));
		}
		
		return $result;
	}
}
<?php
/**
 * @desc    易源-银行卡四要素验证
 * @author  yurong
 * @date    18.04.08
 */
class XbLib_CardBin
{
    private static $obj;
    private $data = NULL;
    private $url = 'http://route.showapi.com/1072-5';
    private $key = NULL;
    private $USER_ID = NULL;
    
    private static $_lastResult;

    private function __construct($data){
        $env = getenv('RUNTIME_ENVIROMENT') ? getenv('RUNTIME_ENVIROMENT') : (defined('SHELL_VARIABLE') ? SHELL_VARIABLE : '');
        $env = empty($env)?'local':$env;
        if($env == 'rls'){
            $this->key="862bc39447084e76962af5d31441b161";
            $this->appid='61291';
        }else{
            $this->key="862bc39447084e76962af5d31441b161";
            $this->appid='61291';
        }
        $this->data = $data;
    }
    private function __clone(){

    }

    /*
     * */
    public static function getInstance($data)
    {
        if (empty(self::$obj)) {
            self::$obj = new XbLib_CardBin($data);
        }
        return self::$obj;
    }

    public function cardBin(){
        self::$_lastResult = null;
        if(empty($this->data)) return false;
        $paramArr = array(
            'showapi_appid'=> $this->appid,
            'acct_pan'=> $this->data['bankcardNumber'],
            'acct_name'=> $this->data['realname'],
            'phone_num'=> $this->data['phone'],
            'cert_type'=> "01",
            'cert_id'=> $this->data['idcardNumber'],
            'needBelongArea'=> "true"
        );
        $param = self::createParam($paramArr,$this->key);
        $url = $this->url.'?'.$param;

        $this_header = array(
            "content-type: application/x-www-form-urlencoded;charset=UTF-8"
        );
        $res = XbLib_CurlHttp::getNew($url,$this_header);
        $checkRes = $this->checkError($res);
        
        self::$_lastResult = $res;
        
        return $checkRes && $checkRes['code']!=400 ? $checkRes:false;
    }
    
    /**
     * 获取最近一次校验的错误提示，校验成功返回空字符串
     * 
     * @return string
     */
    public static function getLastFailMsg() {
        $code = isset(self::$_lastResult['showapi_res_body']['code']) ? self::$_lastResult['showapi_res_body']['code'] : -999;
        
        if ($code < 0)
            $code = -1;
        
        switch ($code) {
            //参数错误
            case -1:
                $msg = '验证错误';
                break;
            case 0:
                $msg = '';
                break;
            default:
                $msg = empty(self::$_lastResult['showapi_res_body']['msg']) ? '验证错误' : self::$_lastResult['showapi_res_body']['msg'];
                break;
        }
        
        return $msg;
    }

    //创建参数(包括签名的处理)
    function createParam ($paramArr,$showapi_secret) {
        $paraStr = "";
        $signStr = "";
        ksort($paramArr);
        foreach ($paramArr as $key => $val) {
            if ($key != '' && $val != '') {
                $signStr .= $key.$val;
                $paraStr .= $key.'='.urlencode($val).'&';
            }
        }
        $signStr .= $showapi_secret;//排好序的参数加上secret,进行md5
        $sign = strtolower(md5($signStr));
        $paraStr .= 'showapi_sign='.$sign;//将md5后的值作为参数,便于服务器的效验
        return $paraStr;
    }

    public function checkError($data){
        $return = array(
            'code'=>400,
            'msg'=>''
        );
        if($data && $data['showapi_res_code']==0){
            $return['code'] = $data['showapi_res_body']['code'];
            $return['msg'] = $data['showapi_res_body']['msg'];
        }elseif($data && $data['showapi_res_code']==-1){
            $return['code'] = $data['showapi_res_code'];
            $return['msg'] = $data['showapi_res_error'];
        }else{
            XbFunc_Log::write('yiyuanError','数据返回错误：'.json_encode($data));
        }
        return $return;
    }


}
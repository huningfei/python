<?php

/**
 *
 * Author: abel
 * Date: 2017/12/6
 * Time: 17:31
 */
class XbLib_Verification_PhoneCode extends XbLib_Verification_Abstract {
    private $_phone;
    private $_len;
    private $_tag;
    private $_letters;
    private $_prefix = "phone";

    function set($tag, $phone, $len = 6, $letters = false) {
        $this->_tag = $tag;
        $this->_phone = $phone;
        $this->_len = $len;
        $this->_letters = $letters;
        return $this;
    }

    /**
     * 发送验证码
     * @param string $type
     * @return bool
     */
    function sendCode($type = 'reg') {
        // TODO: Implement sendCode() method.
        if (!XbLib_Verify::checkPhone($this->_phone)) {
            return new XbLib_WebError(4101);
        }
        //确认渠道发送
        $random = $this->_randomString($this->_len, $this->_letters);
        $res = $this->setCode("{$this->_prefix}_{$this->_tag}_{$this->_phone}", $random);
        if (!$res) {
            return false;
        }
        $ip = XbLib_Function::getInstance()->getip();
        //API发送手机验证码
        $res = XbLib_Msg_Main::getInstance()->sendMessage($ip, $this->_phone, $type, array("code" => $random));
        return $res;
    }
    /**
     * 发送提醒
     * */
    public function sendRemind($type,$array){
        if (!XbLib_Verify::checkPhone($this->_phone)) {
            return new XbLib_WebError(4101);
        }
        $ip = XbLib_Function::getInstance()->getip();
        //API发送手机验证码
        $res = XbLib_Msg_Main::getInstance()->sendMessage($ip, $this->_phone, $type,$array);
        return $res;
    }
    /**
     * 检查验证码
     * @param code
     * @return mixed
     */
    function checkCode($code) {
        // TODO: Implement checkCode() method.
        //检查验证码是否存在
        $vcode = $this->getCode("{$this->_prefix}_{$this->_tag}_{$this->_phone}");
        return $code == $vcode;
    }

    /**
     * @desc    检查类型
     * @param   string  $type   短信类型
     * @param   string  $phone  发送短信手机号
     * @return  boolen  $return 返回验证情况
     */
    public function checkType($type){
        if(!XbLib_Verify::checkPhone($this->_phone)) {
            return new XbLib_WebError(4101);
        }
        switch($type){
            case 'reg':
                $user = XbModule_Account_Users::getInstance()->getUserByPhone($this->_phone);
                if($user){
                    return new XbLib_WebError(4102);
                }
                break;
            case 'changePwd':
                $user = XbModule_Account_Users::getInstance()->getUserByPhone($this->_phone);
                if(!$user){
                    return new XbLib_WebError(4108);
                }
                break;
            case 'binding':
//                $user = XbModule_Account_Users::getInstance()->getUserByPhone($this->_phone);
//                if(!$user){
//                    return new XbLib_WebError(4108);
//                }
                break;
            case 'login':
            case 'awardRemind':
                $user = XbModule_Account_Users::getInstance()->getUserByPhone($this->_phone);
                if(!$user){
                    return new XbLib_WebError(4108);
                }
                break;
            case 'changePhone':
                $user = XbModule_Account_Users::getInstance()->getUserByPhone($this->_phone);
                if($user){
                    return new XbLib_WebError(4102);
                }
                break;
            default:
                break;
        }
        return true;
    }
}

<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2015-11-2
 * UTF-8
 */
class XbLib_WebEncrypt{
	private static $password_key = "d8j2jKjf3kK";
	
	//用户密码加密
	public static function encryptUserPassword($password,$dynamicCode){
		return md5($password.$dynamicCode.self::$password_key);
	}
	
	
	
}
<?php
/**
 * @desc 	调用安心付方法
 * @author  qien
 * @date    17.12.14
 */
class XbLib_Anxinfu{
    private $sign;   //加密字符串
    private $url;    //请求url 测试
    private $key;    //加密key 测试
    private $mch_id; //加密key 测试
    private $header = array('content-type: application/x-www-form-urlencoded');
    public static $interfaceAddr = array(
        'user_signup'  => '/api/v2/users/register',
        'user_login'   => '/api/v2/users/login',
        'user_update'  => '/api/v2/users/update',
        'user_data'    => '/api/v2/users/me',
        'user_request' => '/api/v2/verify/request',
        'credit_cards' => '/api/v2/credit_cards',
        'rates'        =>'/api/v2/rates',
        'order'        =>'/api/v2/orders',
        'profits'      =>'/api/v2/profits',
        'withdraws'    =>'/api/v2/withdraws',
        'levelUpdate'  =>'/api/v2/levels/update',
        'level'        =>'/api/v2/levels',
        'referrals'    =>'/api/v2/referrals',
    );
    private $data = '';
    public $env;

    //初始化data，sign
    function __construct($data){
        //获取环境
        $env = getenv('RUNTIME_ENVIROMENT') ? getenv('RUNTIME_ENVIROMENT') : (defined('SHELL_VARIABLE') ? SHELL_VARIABLE : '');
        $env = empty($env) ? 'local' : $env;
        $this->env = $env;
        if($env=="rls"){
            $this->url    = 'https://axf.ditiantaichina.com';
            $this->key    = 'aa0787d11e810255146f8ec25ebb88b4';
            $this->mch_id = '269953561287';
        }else{
            $this->url    = 'http://118.31.41.110';
            $this->key    = '2fb228d8c4f7f681030a5a518932b90a';
            $this->mch_id = '243627898686';
        }
        $this->init($data);
    }

    function init($data){
        $data['nonce']     = uniqid();
        $time              = time();
        $data['timestamp'] = strval($time);
        $data['mch_id']    = $this->mch_id;
        ksort($data);
        $this->signData($data);
        $this->data .= '&sign='.$this->sign;
    }

    /**
     * @desc    发送数据到服务器
     * @param   array   $url    请求url
     * @return  array   $return 返回请求数据
     */
    public function sendData($url){
        $url = $this->url.$url;
        $data = $this->data;
        //echo $data;
        $res = XbLib_CurlHttp::postNew($url, $data, $this->header);
        if($res['resp_code'] != '0000'){
            $this->errorLog($res, $url, $data);
        }
        return $res;
    }

    /**
     * @desc    发送数据到服务器
     * @param   string  $url    请求url
     * @return  array   $return 返回请求数据
     */
    public function getData($url){
        $url = $this->url.$url.'?'.$this->data;
        //var_dump($url);
        $res = XbLib_CurlHttp::getNew($url,$this->header);
        if($res['resp_code'] != '0000'){
            $this->errorLog($res, $url, 'get方法');
        }
        return $res;
    }

    /**
     * @desc    ping测试接口
     */
    public function test(){
        $this->url = 'http://118.31.41.110/api/v2/ping?'.http_build_query($this->data);
        var_dump($this->url,$this->data);
        return XbLib_CurlHttp::getNew($this->url,$this->header);
    }

    /**
     * @desc    加密sign
     * @param   array   $data   要加密的数据
     * @return  string  $return 返回要加密的字符串
     */
    public function signData($data){
        foreach($data as $k=>$v){
            if($v === '' || $v === null || $v === false){
                unset($data[$k]);
            }else{
                $data[$k] = $k.'='.$v;
            }
        }
        $this->data = implode('&', $data);
        $signStr = $this->data.'&key='.$this->key;
        $this->sign = strtoupper(md5($signStr));
    }

    public function checkSign($sign, $data){
        ksort($data);
        $this->signData($data);
        return $this->sign == $sign;
    }

    /**
     * @desc    安心付错误日志
     * @param   array   $axf_res    返回结果
     * @return  none
     */
    public function errorLog($axf_res, $url, $data){
        $logMsg = json_encode($axf_res);
        if($axf_res['resp_msg'] == '没有接口访问权限'){
            if($this->env=="rls"){
                //接口没有调用权限时，短信通知，万枫，勋韬，立君，启恩
                $phone = '17504130726,15101630800,15313380280,:17600712216';
                $zhizhen = new XbLib_Msg_Adapter_Zhizhen ();
                $zhizhen->work($phone, '【小白信用卡】安心付接口调用错误，没有接口访问权限,请查看具体原因');
            }
        }

        XbFunc_Log::write('anxinfuError',$url.':接口失败','传参:'.$data.',错误码：'.$axf_res['resp_code'].',错误信息：'.$axf_res['resp_msg'].'，接口返回：'.$logMsg);
    }
}
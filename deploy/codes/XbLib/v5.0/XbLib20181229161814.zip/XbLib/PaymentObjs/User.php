<?php
/**
 * 用户对象类
 */
class XbLib_PaymentObjs_User{
    private static $obj;

    public $uid = 0;
    public $info = array();
    public $level = array();
    public $card = array();
    public $channel_level = array();
    public $channel_code = array();

    /**
     * 封闭构造
     * XbLib_PaymentObjs_User constructor.
     */
    private function __construct(){
    }

    /**
     * 单例
     * @return null|XbLib_PaymentObjs_User
     */
    public static function getInstance(){
        if (empty(self::$obj)) {
            self::$obj = new XbLib_PaymentObjs_User();
        }
        return self::$obj;
    }

    /**
     * @desc    获取用户对象
     * @return null|XbLib_PaymentObjs_User
     */
    public function getUserObj($uid){
        if (empty($uid)){
            return false;
        }
        $this->uid = $uid;
        $this->getUserInfo();
        $this->getUserLevel();

        return $this;
    }

    /**
     * @desc    获取用户基础信息
     * @return  array  $return     返回用户基础信息
     */
    public function getUserInfo(){
        $user = XbModule_Account_Users::getInstance()->getUserById($this->uid);
        $profile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($this->uid);
        if (!$user || !$profile) {
            $this->info = false;
            return false;
        }
        foreach (['uid'=>'id', 'phone', 'mch_id'] as $k => $v) {
            if (is_string($k)) {
                $info[$k] = $user[$v];
            } else {
                $info[$v] = $user[$v];
            }
        }
        foreach (['realname', 'idcardNumber', 'idcardImage1', 'idcardImage2', 'bank', 'bankCode', 'bankcardNumber', 'bankcard_phone', 'status'] as $k => $v) {
            if (is_string($k)) {
                $info[$k] = $profile[$v];
            } else {
                $info[$v] = $profile[$v];
            }
        }
        $this->info = $info;
        return $info;
    }

    /**
     * @desc    获取用户等级
     * @return  array  $return     返回用户等级
     */
    public function getUserLevel(){
        $level = XbModule_Account_UsersLevel::getInstance()->getUserLevelByUid($this->uid);
        $this->level = $level;
        return $level;
    }

    /**
     * @desc    获取用户信用卡
     * @return  array  $return     返回用户信用卡
     */
    public function getUserCard($cid=0){
        if (!$cid) {
            return false;
        }
        $cards = XbModule_Account_CreditCard::getInstance()->getAllCreditCard($this->uid);
        $card = array_column($cards, null, 'id');
        $this->card = $card[$cid];
        return $card[$cid];
    }

    /**
     * @desc    获取通道等级费率
     * @param   int     $mch_id         身份
     * @param   int     $uid            uid
     * @param   int     $level          等级
     * @return  array  $return     获取通道等级费率
     */
    public function getUserChannel($channel_id){
        $channel_level = XbModule_Account_CommonChannelLevel::getInstance()->getChannelLevelByChannelId($channel_id, $this->level['level'], $this->info['mch_id']);
        $this->channel_level = $channel_level;
        $channel_code = XbModule_Account_UsersChannel::getInstance()->getUsersChannelCode($this->info['uid'], $channel_id);
        $this->channel_code = $channel_code;
        return array($channel_level, $channel_code);
    }
}
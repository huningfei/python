<?php
/**
 * 订单类
 */
class XbLib_PaymentObjs_Order{
    private static $obj;

    public $user = null;
    public $channel = null;
    public $order = null;
    public $param = array();

    /**
     * 封闭构造
     * XbLib_PaymentObjs_Order constructor.
     */
    private function __construct(){
    }

    /**
     * 单例
     * @return null|XbLib_PaymentObjs_Order
     */
    public static function getInstance(){
        if (empty(self::$obj)) {
            self::$obj = new XbLib_PaymentObjs_Order();
        }
        return self::$obj;
    }

    /**
     * @desc    获取支付通道
     * @return  object  $return     获取支付通道
     */
    public function getChannelGallery($channel_id){
        switch ($channel_id){
            case 5:
                $gallery = XbLib_Repayment_Channel::getChannelObj('YaKuKuBao');
                break;
            default:
                break;
        }
        return $gallery;
    }


    /**
     * @desc    用户进件
     * @return  array  $return     用户进件
     */
    public function userSignUp($channel_id, $uid){
        if (empty($channel_id) || empty($uid)){
            return new XbLib_WebError(400,'通道或用户信息错误');
        }
        $this->user = $user = XbLib_PaymentObjs_User::getInstance()->getUserObj($uid);
        $this->channel = $channel = XbLib_PaymentObjs_Channel::getInstance()->getChannelObj($channel_id);

        if (!$user->info) {
            return new XbLib_WebError(400,'用户身份信息错误');
        }

        if ($user->info['mch_id'] == 1){
            return new XbLib_WebError(400,'暂时不开放原小白用户注册雅酷通道');

        }

        $this->param['order_id']         = XbModule_Account_OrderCode::getInstance()->getOrderCode();
        $this->param['bind_order_id']    = XbModule_Account_OrderCode::getInstance()->getOrderCode();

        return $this;
    }

    /**
     * @desc    支付计算
     * @return  array  $return     支付计算
     */
    public function userCreateOrder($channel_id, $uid, $cid, $amount, $channel_level_id, $merchant_id, $card_info){
        $this->user = XbLib_PaymentObjs_User::getInstance()->getUserObj($uid);
        $this->channel = XbLib_PaymentObjs_Channel::getInstance()->getChannelObj($channel_id);

        //校验用户信息
        if (!$this->user->info || ($this->user->info['status'] != 3)) {
            return new XbLib_WebError(4207);
        }

        //校验通道信息
        if (empty($this->channel->info)){
            return new XbLib_WebError(4306);
        }

        //判断信用卡信息
        $this->user->getUserCard($cid);
        if(!$this->user->card){
            return new XbLib_WebError(4304);
        }
        if($this->user->card['uid'] != $this->user->uid){
            return new XbLib_WebError(4304);
        }

        //校验金额
        if(!XbLib_Verify::checkOrderMoney($amount)){
            return new XbLib_WebError(4302);
        }

        //校验时间
        $check_time  = XbLib_ChannelTools::checkChannelTime($this->channel->info['time'], $this->channel->info['week']);
        if(!$check_time){
            return new XbLib_WebError(4310);
        }

        //获取用户等级
        $this->user->getUserChannel($this->channel->channel_id);
        if (!$this->user->channel_level['rate']){
            return new XbLib_WebError(400,'用户等级信息错误');
        }
        if (!$this->user->channel_code['channel_code']){
            return new XbLib_WebError(400,'用户通道code错误');
        }
        if ($channel_level_id != $this->user->channel_level['id']){
            return new XbLib_WebError(400,'用户等级信息错误');
        }

        //选择商户
        if($channel_id == 9){
            //选择商户
            if(empty($merchant_id)){
                return new XbLib_WebError(400,'请选择商户');
            }
            $res_merchant = XbModule_Account_Merchant::getInstance()->selectMerchant(20, '', $merchant_id);
            if(empty($res_merchant['merchant_no'])){
                return new XbLib_WebError(400,'选择的商户不存在');
            }
            $this->param['merchant_no'] = $res_merchant['merchant_no'];

            //验证cvv与有效期
            if (empty($card_info['cvv']) || empty($card_info['validDate'])){
                return new XbLib_WebError(400,'信用卡cvv或有效期不能为空');
            }
            if (($card_info['cvv'] != $this->user->card['cvv'] || ($card_info['validDate'] != $this->user->card['validDate']))){
                $res_update_cvv = XbModule_Account_CreditCard::getInstance()->updateCardCvv($this->user->card['id'] ,$this->user->uid, $card_info['cvv'], $card_info['validDate']);
            }
        }


        $this->param['pay_amount'] = $amount;
        $this->param['cvv'] = $card_info['cvv'];
        $this->param['validDate'] = $card_info['validDate'];
        $this->param['rate']       = $this->user->channel_level['rate'];
        $this->param['order_id']   = XbModule_Account_OrderCode::getInstance()->getOrderCode();
        $this->param['time']       = time();

        return $this;
    }

    /**
     * @desc    支付回调计算
     * @return  array  $return     支付回调计算
     */
    public  function userCreatePayOrder($order_index){

        $this->user = XbLib_PaymentObjs_User::getInstance()->getUserObj($order_index['uid']);
        $this->order = XbModule_Account_Order::getInstance($order_index['order_table_num'])->getOrderById($order_index['order_table_id']);
        $this->channel = XbLib_PaymentObjs_Channel::getInstance()->getChannelObj($this->order['channel_id']);

        //校验储蓄卡信息
        if(empty($this->order['debitcard']) || ($this->order['debitcard'] != $this->user->info['bankcardNumber'])){
            return new XbLib_WebError(4304);
        }

        //获取用户等级
        $this->user->getUserChannel($this->channel->channel_id);

        $this->param['single_fee']    = $this->order['single_fee'];
        $this->param['fee']           = sprintf("%.2f", bcmul( $this->order['amount'],$this->order['rate'],4)) + $this->param['single_fee'];
        $this->param['custom_amount'] = $this->order['amount'] -  $this->param['fee'];
        $this->param['order_id']      = XbModule_Account_OrderCode::getInstance()->getOrderCode();
        $this->param['time']          = time();

        return $this;
    }

    /**
     * @desc    代付回调完成订单
     * @return  array  $return     代付回调完成订单
     */
    public  function userFinishOrder($status, $order_index, $order_play){
        $this->user = XbLib_PaymentObjs_User::getInstance()->getUserObj($order_index['uid']);
        $this->order = XbModule_Account_Order::getInstance($order_index['order_table_num'])->getOrderById($order_index['order_table_id']);
        $this->channel = XbLib_PaymentObjs_Channel::getInstance()->getChannelObj($this->order['channel_id']);

        //获取用户等级
        $this->user->getUserChannel($this->channel->channel_id);

        if ($status == 1){
            //代付成功
            $order_data['status'] = 1;
            $play_data['status'] = 3;
        } elseif ($status == 2){
            //代付失败
            $order_data['status'] = 2;
            $play_data['status'] = 4;
        }

        $this->param['order_data']      = $order_data;
        $this->param['play_data']       = $play_data;

        return $this;
    }
}
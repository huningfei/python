<?php
//通道策略类
class XbLib_PaymentObjs_Channel{
    private static $obj;

    public $channel_id = 0;
    public $info    = array();

    /**
     * 封闭构造
     * XbLib_PaymentObjs_Channel constructor.
     */
    private function __construct(){
    }

    /**
     * 单例
     * @return null|XbLib_PaymentObjs_Channel
     */
    public static function getInstance(){
        if (empty(self::$obj)) {
            self::$obj = new XbLib_PaymentObjs_Channel();
        }
        return self::$obj;
    }

    /**
     * @desc    获取通道对象
     * @return null|XbLib_PaymentObjs_Channel
     */
    public function getChannelObj($channel_id) {
        if (empty($channel_id)){
            return false;
        }
        $this->channel_id = $channel_id;
        $this->getChanneInfo();

        return $this;
    }

    /**
     * @desc    获取通道基本信息
     * @return  array  $return     返回通道基础信息
     */
    public function getChanneInfo(){
        $channel = XbModule_Account_Channel::getInstance()->getChannelByChannelid($this->channel_id);
        $this->info = $channel;
        return $channel;
    }
}

<?php
/**
 * 微信模版消息应用
 * Encodings: UTF-8
 * User: DPP
 * Date: 2018/4/12
 * Time: 上午11:21
 */

class XbLib_WechatTools_SendMsg extends XbLib_WechatTools_WxCommon {

    private static $obj = null;
    private static $templateId = array();

    // 消息模板通知内容配置
    private static $templateText = array(
        // 注册成功通知模版
//        'register' => array(
//            'first'     => array('value' => '欢迎来到小白用卡管家，您在这里可以轻松完成信用卡收款、还款，收款超低费率1秒到账，邀请其他用户更可坐享分润~','color' => '#173177'),
//            'remark'    => array('value' => '感谢您对小白用卡管家支持，快来收款吧~','color' => '#173177')
//        ),

//        // 实名认证成功
//        'realnamesuccess' => array(
//            'first'     => array('value' => '恭喜您实名认证成功','color' => '#173177'),
//            'remark'    => array('value' => '您提交的实名资料已成功通过审核，快来收款吧！','color' => '#173177'),
//        ),
//
//        // 实名认证失败
//        'realnamefail' => array(
//            'first'     => array('value' => '很遗憾您实名认证失败','color' => '#173177'),
//            'remark'    => array('value' => '您提交的实名认证资料未通过审核，点击重新认证','color' => '#173177'),
//        ),

        // 取现成功
//        'orderpayment' => array(
//            'first'     => array('value' => '您好，您的收款订单已成功到账','color' => '#173177'),
//            'keyword1'  => array('value' => '收款支付'),
//            'remark'    => array('value' => '点击查看详情','color'=>'#173177'),
//        ),

        // 一键还款成功
//        'onekeyrepaymentsuccess' => array(
//            'first'     => array('value' => '您好，您的一键还款订单支付成功','color' => '#173177'),
//            'keyword1'  => array('value' => '一键还款支付'),
//            'remark'    => array('value' => '点击查看详情','color' => '#173177'),
//        ),

        // 一键还款失败
//        'onekeyrepaymentfail' => array(
//            'first'     => array('value' => '您好，您的一键还款订单支付失败','color' => '#173177'),
//            'keyword1'  => array('value' => '一键还款支付'),
//            'remark'    => array('value' => '点击查看详情','color' => '#173177'),
//        ),

        // 智能还款计划制定成功
//        'intelligencerepaymentplansuccess' => array(
//            'first'     => array('value' => '您好，您的智能还款订单制定成功','color' => '#173177'),
//            'keyword1'  => array('value' => '智能还款'),
//            'remark'    => array('value' => '点击查看详情','color' => '#173177'),
//        ),

        // 智能还款成功
//        'intelligencerepaymentsuccess' => array(
//            'first'     => array('value'=>'您好，你的智能还款订单成功执行一笔','color'=>'#173177'),
//            'keyword1'  => array('value'=>'智能还款'),
//            'remark'    => array('value'=>'点击查看详情','color'=>'#173177'),
//        ),

        // 智能还款失败
//        'intelligencerepaymentfail' => array(
//            'first'     => array('value' => '您好，您的智能还款订单还款失败，还款计划已终止','color'=>'#173177'),
//            'keyword1'  => array('value' => '智能还款'),
//            'remark'    => array('value' => '点击查看详情','color' => '#173177'),
//        ),

        // 智能还款订单已完成
//        'intelligencerepaymentallsuccess' => array(
//            'first'     => array('value' => '您好，您的智能还款订单已完成','color' => '#173177'),
//            'keyword1'  => array('value' => '智能还款'),
//            'remark'    => array('value' => '点击查看详情','color' => '#173177'),
//        ),

        // 账单日提醒
//        'intelligencerepaymentbilldayremind' => array(
//            'first'     => array('value' => '您尾号cardNumber的cardBank信用卡的账单日已到','color' => '#173177'),
//            'remark'    => array('value' => '为避免逾期，请及时还款','color' => '#173177'),
//        ),

        // 还款日提醒
//        'intelligencerepaymentpaydayremind' => array(
//            'first'     => array('value' => '您尾号cardNumber的cardBank信用卡的还款日已到','color' => '#173177'),
//            'remark'    => array('value' => '为避免逾期，请及时还款','color' => '#173177'),
//        ),
        //红包过期提醒
//        'awardremind' => array(
//            'remark'  => array('value' => '点击查看详情','color' => '#173177'),
//        ),
        //红包到账提醒
//        'awardarrive' => array(
//            'remark'  => array('value' => '点击查看详情,立即领取到余额'),
//        )
    );

    public static function getInstance(){
        // 获取推送消息的templateid
        $env = XbLib_WechatTools_Conifg::get_run_enviment();
        self::$templateId = XbLib_WechatTools_Conifg::$_templateid[$env];

        if(is_null(self::$obj)){
            self::$obj = new XbLib_WechatTools_SendMsg();
        }
        return self::$obj;
    }

    /**
     * 发送消息
     * @param $touser 接收者
     * @param $template_id 模板编号
     * @param $data 数据
     * @param $url 链接地址
     * @return Ambigous|bool
     */
    public function send($touser, $template_id, $data, $url){
        $templateInfo = array(
            'touser'        => $touser,
            'template_id'   => self::$templateId[$template_id],
            'data'          => $data,
        );
        if($url) $templateInfo['url'] = $url;
        $templateInfo = json_encode($templateInfo);
        return $this->send_http('template_send', $templateInfo);
    }

    public function send_wx($touser, $data, $template_id, $url){
        $templateInfo = array(
            'touser'        => $touser,
            'template_id'   => self::$templateId[$template_id],
            'data'          => $data,
        );
        if($url) $templateInfo['url'] = $url;
        $templateInfo = json_encode($templateInfo);
        return $this->send_http('template_send', $templateInfo);
    }

/******************以下为模版消息对应格式***************************/

    /**
     * 注册成功通知模版
     * @param $mobile 手机
     * @param $regData 注册时间
     */
//    public function register($mobile, $regData){
//        // 使用模板内容文件设置消息内容
//        $data = self::$templateText['register'];
//        $data['keyword1']['value'] =  $mobile ? $mobile : '暂无手机号';
//        $data['keyword2']['value'] =  $regData;
//        ksort($data);
//        return $data;
////        return $this->send($touser, 'ZHU_CE_CHENG_GONG', $data, $url);
//    }

//    /**
//     * 实名成功
//     * @param $name     用户实名
//     * @param $mobile   用户手机号
//     */
//    public function realNameSuccess($nickname, $mobile){
//        // 使用模板内容文件设置消息内容
//        $data = self::$templateText['realnamesuccess'];
//        $data['keyword1']['value'] =  $nickname;
//        $data['keyword2']['value'] =  $mobile ? $mobile : '暂无手机号';
//        ksort($data);
//        return $data;
////        return $this->send($touser, 'SHI_MING', $data, $url);
//    }
//
//    /**
//     * 实名失败
//     * @param $name 姓名
//     * @param $mobile 手机号
//     */
//    public function realNameFail($nickname, $mobile){
//        // 使用模板内容文件设置消息内容
//        $data = self::$templateText['realnamefail'];
//        $data['keyword1']['value'] =  $nickname;
//        $data['keyword2']['value'] =  $mobile ? $mobile : '暂无手机号';
//        ksort($data);
//        return $data;
////        return $this->send($touser, 'SHI_MING', $data, $url);
//    }

    /**
     * 取现成功
     * @param $name 姓名
     * @param $orderAmount  订单金额
     * @param $date         时间
     * @param $orderNumber  订单编号
     */
//    public function getCashSuccess($name, $orderAmount, $date, $orderNumber){
//        // 使用模板内容文件设置消息内容
//        $data = self::$templateText['orderpayment'];
//        $data['keyword2']['value'] =  $name;
//        $data['keyword3'] =  array('value' => $orderAmount,'color'=>'#FF4040');
//        $data['keyword4']['value'] =  $date;
//        $data['keyword5']['value'] =  $orderNumber;
//        ksort($data);
//        return $data;
////        return $this->send($touser, 'ZHANG_DAN_CHENG_GONG', $data, $url);
//    }

    /**
     * 一键还款成功
     * @param $name 姓名
     * @param $orderAmount 订单金额
     * @param $date 时间
     * @param $orderNumber 订单编号
     */
//    public function onekeyRepaySuccess($name, $orderAmount, $date, $orderNumber){
//        // 使用模板内容文件设置消息内容
//        $data = self::$templateText['onekeyrepaymentsuccess'];
//        $data['keyword2']['value'] =  $name;
//        $data['keyword3'] =  array('value' => $orderAmount, 'color' => '#FF4040');
//        $data['keyword4']['value'] =  $date;
//        $data['keyword5']['value'] =  $orderNumber;
//        ksort($data);
//        return $data;
////        return $this->send($touser, 'ZHANG_DAN_CHENG_GONG', $data);
//    }
    /**
     * 一键还款失败
     * @param $date 时间
     */
//    public function onekeyRepayFail($name, $orderAmount, $date, $orderNumber){
//        // 使用模板内容文件设置消息内容
//        $data = self::$templateText['onekeyrepaymentfail'];
//        $data['keyword2']['value'] =  $name;
//        $data['keyword3'] =  array('value' => $orderAmount, 'color' => '#FF4040');
//        $data['keyword4']['value'] =  $date;
//        $data['keyword5']['value'] =  $orderNumber;
//        ksort($data);
//        return $data;
////        return $this->send($touser, 'ZHANG_DAN_SHI_BAI', $data, $url);
//    }
    /**
     * 智能还款计划制定成功
     * @param $orderAmount 金额
     * @param $date 日期
     */
//    public function intelligenceRepayPlanSuccess($name, $orderAmount, $date, $orderNumber){
//        // 使用模板内容文件设置消息内容
//        $data = self::$templateText['intelligencerepaymentplansuccess'];
//        $data['keyword2']['value'] =  $name;
//        $data['keyword3'] =  array('value' => $orderAmount, 'color' => '#FF4040');
//        $data['keyword4']['value'] =  $date;
//        $data['keyword5']['value'] =  $orderNumber;
//        ksort($data);
//        return $data;
////        return $this->send($touser, 'ZHI_NENG_ZHANG_DAN', $data, $url);
//    }
    /**
     * 智能还款成功
     * @param $name 姓名
     * @param $orderAmount 金额
     * @param $date 日期
     * @param $orderNumber 订单编号
     */
//    public function intelligenceRepaySuccess($name, $orderAmount, $date, $orderNumber){
//        // 使用模板内容文件设置消息内容
//        $data = self::$templateText['intelligencerepaymentsuccess'];
//        $data['keyword2']['value'] =  $name;
//        $data['keyword3']          =  array('value' => $orderAmount, 'color' => '#FF4040');
//        $data['keyword4']['value'] =  $date;
//        $data['keyword5']['value'] =  $orderNumber;
//        ksort($data);
//        return $data;
////        return $this->send($touser, 'ZHANG_DAN_CHENG_GONG', $data, $url);
//    }
    /**
     * 智能还款失败
     * @param $date 日期
     */
//    public function intelligenceRepayFail($name, $orderAmount, $date, $orderNumber){
//        // 使用模板内容文件设置消息内容
//        $data = self::$templateText['intelligencerepaymentfail'];
//        $data['keyword2']['value'] =  $name;
//        $data['keyword3']          =  array('value' => $orderAmount, 'color' => '#FF4040');
//        $data['keyword4']['value'] =  $date;
//        $data['keyword5']['value'] =  $orderNumber;
//        ksort($data);
//        return $data;
////        return $this->send($touser, 'ZHANG_DAN_SHI_BAI', $data);
//    }
    /**
     * 智能还款订单已完成
     * @param $name 姓名
     * @param $orderAmount 订单金额
     * @param $date 日期
     * @param $orderNumber 订单编号
     */
//    public function intelligenceRepayOrderFinish($name, $orderAmount, $date, $orderNumber){
//        // 使用模板内容文件设置消息内容
//        $data = self::$templateText['intelligencerepaymentallsuccess'];
//        $data['keyword2']['value'] =  $name;
//        $data['keyword3'] =  array('value' => $orderAmount,'color' => '#FF4040');
//        $data['keyword4']['value'] =  $date;
//        $data['keyword5']['value'] =  $orderNumber;
//        ksort($data);
//        return $data;
////        return $this->send($touser, 'ZHANG_DAN_CHENG_GONG', $data, $url);
//    }
    /**
     * 红包过期提醒
     * @param $name 姓名
     * @param $orderAmount 订单金额
     * @param $date 日期
     * @param $orderNumber 订单编号
     */
//    public function arardremind($date, $type, $status, $act,$detail){
//        // 使用模板内容文件设置消息内容
//        $data = self::$templateText['awardremind'];
//        $data['first'] =  array('value' => '您参加‘'.$act.'’活动的红包明天就失效啦','color'=>'#173177');
//        $data['keyword1']['value'] = $date;
//        $data['keyword2']['value'] =  $type;
//        $data['keyword3']['value'] =  $status;
//        $data['keyword4']['value'] =  $act;
//        $data['keyword5']['value'] =  $detail;
//        ksort($data);
//        return $data;
////        return $this->send($touser, 'ZHANG_DAN_CHENG_GONG', $data, $url);
//    }

    /*
     * 账单日还款提醒
     * @param $name 姓名
     * @param $orderAmount 订单金额
     * @param $date 日期
     * @param $orderNumber 订单编号
     */
//    public function intelligenceRepayBillDayRemind($cardNumber, $cardBank, $billDate, $payDate){
//        // 使用模板内容文件设置消息内容
//        $data = self::$templateText['intelligencerepaymentbilldayremind'];
//        $data['first']['value']    = str_replace(array('cardNumber', 'cardBank'), array($cardNumber, $cardBank), $data['first']['value']);
//        $data['keyword1']['value'] = $billDate;
//        $data['keyword2']['value'] = $payDate;
//        ksort($data);
//        return $data;
//    }
    /**
     * 还款日账单提醒
     * @param $name 姓名
     * @param $orderAmount 订单金额
     * @param $date 日期
     * @param $orderNumber 订单编号
     */
//    public function intelligenceRepayPayDayRemind($cardNumber, $cardBank, $billDate, $payDate){
//        // 使用模板内容文件设置消息内容
//        $data = self::$templateText['intelligencerepaymentpaydayremind'];
//        $data['first']['value']    = str_replace(array('cardNumber', 'cardBank'), array($cardNumber, $cardBank), $data['first']['value']);
//        $data['keyword1']['value'] = $billDate;
//        $data['keyword2']['value'] = $payDate;
//        ksort($data);
//        return $data;
////        return $this->send($touser, 'ZHANG_DAN_CHENG_GONG', $data, $url);
//    }


    /**
     * 红包到账提醒
     * @param $myname 发送方
     * @param $orderAmount 订单金额
     * @param $date 日期
     * @param $orderNumber 订单编号
     */
//    public function arardarrive($name, $myname, $money, $date, $type, $rest){
//        // 使用模板内容文件设置消息内容
//        $data = self::$templateText['awardarrive'];
//        $data['first'] =  array('value' => '您参加‘'.$name.'’活动的奖励到账了！','color'=>'#173177');
//        $data['keyword1']['value'] =  $myname;
//        $data['keyword2']['value'] =  $money;
//        $data['keyword3']['value'] =  $date;
//        $data['keyword4']['value'] =  $type;
//        $data['keyword5']['value'] =  $rest;
//        ksort($data);
//        return $data;
////        return $this->send($touser, 'ZHANG_DAN_CHENG_GONG', $data, $url);
//    }

    /**
     * 整合公共模板消息推送函数
     * @param $type 消息类型
     * @param $param 发送参数
     */
    public function publicWxTemplateMsgSendFunc($type, $param) {
        $type = (int)$type;
        $uid = (int)$param['uid'];
        if (!$uid) return;

        // 获取用户信息
        $userinfo = XbModule_Account_Users::getInstance()->getUserById($uid);
        // 获取用户openid
        if(!$userinfo && !$userinfo['wx_openid']) return;
        $touser = $userinfo['wx_openid'];
        $userProfile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);

        // 根据类型，分发具体详细发送信息
        $data = array();
        switch($type){
            // 注册成功
//            case 1:
//                $param['url'] = $this->host . '/wechat/getUserinfo';
//                $template_id = 'ZHU_CE_CHENG_GONG';
//                $data = $this->register($userinfo['phone'], $param['date']);
//                break;
            // 实名认证成功
//            case 2:
//                $param['url'] = $this->host . '/wechat/getUserinfo?type=7';
//                $template_id = 'SHI_MING';
//                $data = $this->realNameSuccess($userProfile['realname'], $userinfo['phone']);
//                break;
//            // 实名认证失败
//            case 3:
//                $param['url'] = $this->host . '/wechat/getUserinfo?type=8';
//                $template_id = 'SHI_MING';
//                $data = $this->realNameFail($userProfile['realname'], $userinfo['phone']);
//                break;
            // 取现成功
//            case 4:
//                $param['url'] = $this->host . '/wechat/getUserinfo?type=9';
//                $template_id = 'ZHANG_DAN_CHENG_GONG';
//                $data = $this->getCashSuccess($userProfile['realname'], $param['orderamount'], $param['date'], $param['ordernumber']);
//                break;
            // 一键还款成功
//            case 5:
//                $param['url'] = $this->host . '/wechat/getUserinfo?type=10';
//                $template_id = 'ZHANG_DAN_CHENG_GONG';
//                $data = $this->onekeyRepaySuccess($userProfile['realname'], $param['orderamount'], $param['date'], $param['ordernumber']);
//                break;
            // 一键还款失败
//            case 6:
//                $param['url'] = $this->host . '/wechat/getUserinfo?type=10';
//                $template_id = 'ZHANG_DAN_CHENG_GONG';
//                $data = $this->onekeyRepayFail($userProfile['realname'], $param['orderamount'], $param['date'], $param['ordernumber']);
//                break;
            // 智能还款计划制定成功
//            case 7:
//                $param['url'] = $this->host . '/wechat/getUserinfo?type=10';
//                $template_id = 'ZHANG_DAN_CHENG_GONG';
//                $data = $this->intelligenceRepayPlanSuccess($userProfile['realname'], $param['orderamount'], $param['date'], $param['ordernumber']);
//                break;
            // 智能单笔还款成功
//            case 8:
//                $param['url'] = $this->host . '/wechat/getUserinfo?type=10';
//                $template_id = 'ZHANG_DAN_CHENG_GONG';
//                $data = $this->intelligenceRepaySuccess($userProfile['realname'], $param['orderamount'], $param['date'], $param['ordernumber']);
//                break;
            // 智能还款失败
//            case 9:
//                $param['url'] = $this->host . '/wechat/getUserinfo?type=10';
//                $template_id = 'ZHANG_DAN_CHENG_GONG';
//                $data = $this->intelligenceRepayFail($userProfile['realname'], $param['orderamount'], $param['date'], $param['ordernumber']);
//                break;
            // 智能还款订单已完成
//            case 10:
//                $param['url'] = $this->host . '/wechat/getUserinfo?type=10';
//                $template_id = 'ZHANG_DAN_CHENG_GONG';
//                $data = $this->intelligenceRepayOrderFinish($userProfile['realname'], $param['orderamount'], $param['date'], $param['ordernumber']);
//                break;
            //账单日提醒
//            case 11:
//                $param['url'] = $this->host . '/wechat/getUserinfo?type=10';
//                $template_id = 'ZHI_NENG_TI_XING';
//                $data = $this->intelligenceRepayBillDayRemind($param['cardNumber'], $param['cardBank'], $param['billDate'], $param['payDate']);
//                break;
//            case 12:
//                $param['url'] = $this->host . '/wechat/getUserinfo?type=10';
//                $template_id = 'ZHI_NENG_TI_XING';
//                $data = $this->intelligenceRepayPayDayRemind($param['cardNumber'], $param['cardBank'], $param['billDate'], $param['payDate']);
//                break;
            //红包到期提醒
//            case 13:
//                $param['url'] = $this->host . '/wechat/getUserinfo?type=11';
//                $template_id = 'AWARD_REMIND';
//                $data = $this->arardremind($param['date'], $param['type'], $param['status'], $param['act'],$param['detail']);
//                break;
            //红包到账提醒
//            case 14:
//                $param['url'] = $this->host . '/wechat/getUserinfo?type=11';
//                $template_id = 'AWARD_ARRIVE';
//                $data = $this->arardarrive($param['name'], $param['myname'],$param['money'], $param['date'], $param['type'], $param['rest']);
//                break;
            default:
                break;
        }
        if(empty($data)) return false;
//        XbFunc_Log::write('sendmsg',json_encode($data,JSON_UNESCAPED_UNICODE),$param['url']);

        // 发送微信模板消息
        return $this->send($touser, $template_id, $data, $param['url']);
    }

}
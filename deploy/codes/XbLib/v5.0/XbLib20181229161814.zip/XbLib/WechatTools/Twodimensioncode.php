<?php
class XbLib_WechatTools_Twodimensioncode{
    private static $obj = null;
    
    private function __construct($options){
        $this->options = $options;
    }
    
    public static function getInstance($options){
        if(is_null(self::$obj)){
            self::$obj = new XbLib_WechatTools_Twodimensioncode($options);
        }
        return self::$obj;
    }
    
    /**
     * 获取二维码图片地址
     * @param number $id 
     * @param number $type 0 临时 1 永久
     */
    public function getImgUrl($id,$type){
        $result=array();
        //处理URL
        if(empty($id)){
            $result['code']=400;
            $result['message']= '参数有误';
        }else{
            $wechat = new XbLib_Wechat($this->options);
            $codearr= $wechat->getQRCode($id,$type);
            if(!empty($codearr)){
                $codeurl='https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.urlencode($codearr['ticket']);
                $result['code']=200;
                $result['codeurl']= $codeurl;
            }else{
                $result['code']=400;
                $result['message']= '生成二维码错误';
            }
        }
        return $result;
    }
	
    public function createDimensionCode($uid, $mobile, $type){
    	
    	$result_json = array(
    		'code'		=> '200',
    		'data'		=> array(),
    		'message'	=> ''
    	);
    	if(empty($uid) || empty($mobile) || empty($type)){
    		$result_json['code']='300';
    		$result_json['message']='参数错误';
    		return $result_json;
    	}
    	$id = XbModule_P2peye_Twoweicode::getInstance()->addActivityCode($uid, $mobile,$type);
    	if(empty($id)){
    		$result_json['message'] = '生成二维码数据错误';
    		$result_json['code'] = 401;
    		return $result_json;
    	}
    	$data = $this->getImgUrl($id, 0);
    	if(!empty($data) && $data['code']!=200 && empty($data['codeurl'])){
    		$result_json['code']=301;
    		$result_json['message']='生成二维码数据错误';
    		return $result_json;
    	}
    	$result_json['code'] = $data['code'];
    	$result_json['data']['id'] = $id;
    	$result_json['data']['codeurl'] = $data['codeurl'];
    	XbModule_P2peye_Twoweicode::getInstance()->updateTwodimensionCode($id,$data['codeurl']);
    	$result_json['data'] = $data;
    	return $result_json;
    }
    
}
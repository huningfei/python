<?php
/**
 * 微信模版消息公共函数类
 * Encodings: UTF-8
 * User: DPP
 * Date: 2018/4/12
 * Time: 上午11:21
 */

class XbLib_WechatTools_WxCommon {
    
    private $_access_token = null;
    private $_error_code = 200;
    protected $host = 'https://m.xiaobaijinfu.com';
    
    public function __construct(){
        //获取access_token
        $this->get_access_token();
        if($this->_error_code !== 200){
            return $this;
        }
    }

    /**
     * 获取错误信息
     * @return int
     */
    public function get_error_code(){
        return $this->_error_code;
    }

    /**
     * 接口请求统一入口
     * @param string $url_identification 配置文件中 接口地址KEY
     * @param array|string $parameter
     * @return boolean|Ambigous <boolean, mixed>
     */
    public function send_http($url_identification, $parameter = array(), $mode = 'post'){
        //获取请求初始地址
        if(!isset(XbLib_WechatTools_Conifg::$_interfaces['url'][$url_identification])){
            return false;
        }
        $url = XbLib_WechatTools_Conifg::$_interfaces['url'][$url_identification];
        //开始请求
        return $this->curl_http($url, $parameter, $mode);
    }

    /**
     * 获取access_token
     * @return boolean
     */
    private function get_access_token(){
        // 先使用统一的函数调用
        $options = XbLib_WechatTools_Conifg::$_xiaobai_share;
        $wechat = new XbLib_Wechat ( $options );
        $this->_access_token = $wechat->getAccess_token();
        return;
    }

    /**
     * 发送请求 (POST)
     * @param unknown $url
     * @param unknown $param
     * @return boolean
     */
    private function curl_http($url, $param, $mode){
        if(is_array($param) and !empty($param)){
            foreach($param as $key=>$val){
                $param[] = $key.'='.urlencode(trim($val));
            }
            $param = join('&', $param);
        }

        if($this->_access_token){
            $url .= stripos($url,'?') !== FALSE ? '&access_token=' : '?access_token=';
            $url .= $this->_access_token;
        }

        $curl_obj = curl_init();
        curl_setopt($curl_obj, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl_obj, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($curl_obj, CURLOPT_SSLVERSION, 1);
        curl_setopt($curl_obj, CURLOPT_URL, $url);
        curl_setopt($curl_obj, CURLOPT_RETURNTRANSFER, 1 );
        if($mode === 'post'){
            curl_setopt($curl_obj, CURLOPT_POST,TRUE);
            curl_setopt($curl_obj, CURLOPT_POSTFIELDS, $param);
        }
        $sContent = curl_exec($curl_obj);
        $aStatus = curl_getinfo($curl_obj);
        curl_close($curl_obj);

        if(intval($aStatus["http_code"]) != 200){
            XbFunc_Log::write('wechat_http_error', 'REQUEST_ERROR', $url . '?' . $param . '----STATUS---' .json_encode($aStatus). '----CONTENT----' .json_encode($sContent));
            return false;
        }
        return $sContent;
    }

    /**
     * 测试推送文本消息(仅供测试使用，随时可删除)
     * @return bool
     */
    public function textTextMsg() {
        $message = array('text' => urldecode('who are you!'));

        $arr = array(
            'touser'  	=> 'o_q951fa0LpMmfPI2krDYyLxX1og',
            'msgtype' 	=> 'text',
            'text'		=> array(
                'content'	=> urlencode($message['text'])
            )
        );

        $url = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=".$this->_access_token;
        $mstr = urldecode(json_encode($arr));
        $data = $mstr;

        $ch = curl_init();
        curl_setopt($ch,	CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, 	CURLOPT_URL, $url);
        curl_setopt($ch, 	CURLOPT_POST, 1);
        curl_setopt($ch, 	CURLOPT_HEADER, 0) ;
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $ret = curl_exec($ch);
        curl_close($ch);

        if (!$ret) return false;
        $ret = json_decode($ret, true);
        if ($ret['errcode'] == 0) return true;
        return false;
    }
}
<?php 
/**
 * 字符串处理公共类
 * @author fengshuang
 * 
 */
class XbLib_ImageUpload{
	private static $obj = null;
	/**
	 * URL
	 * @var unknown
	 */
	
	/**
	 * 获取单例对象
	 * @param string $hl
	 * @param number $timeout
	 * @return TyLib_SolrSearch
	 */
	public static function getInstance(){
		if(is_null(self::$obj)){
			self::$obj = new XbLib_ImageUpload();
		}
	
		return self::$obj;
	}
	
	/**
	 * 图片上传
	 * @param type $file
	 * @param type $key 加密字符 
	 * @return boolean|string
	 */
	public function setImage($file, $act_name,$path ="/uploads/act/"){
		if($file['size'] > 2000000){
			return '图片太大，请压缩后再上传！';
		}
		//组建图片名称
		$pic_image = md5($act_name) . '.' . preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$file['name']);
		//组建图片存放路径
		$date = date('Y-m-d', time());
		$path_image = $_SERVER["DOCUMENT_ROOT"] . $path . $date;
		if(!file_exists($path_image)){
			$this->mk_dir($path_image);
		}
		$is = move_uploaded_file($file['tmp_name'], $path_image . '/' . $pic_image);
		if($is){
			return $path . $date . '/' . $pic_image;
		}else{
			return false;
		}
	}
	
	/**
	 * 图片上传创建目录
	 * @param type $dir
	 * @param type $mode
	 * @return boolean
	 */
	public function mk_dir($dir, $mode = 0755){
		if (is_dir($dir) || @mkdir($dir,$mode)) return true;
		if (!$this->mk_dir(dirname($dir),$mode)) return false;
		return @mkdir($dir,$mode);
	}
	
	/**
	 * 图片等比缩放处理
	 * @param type $src_file
	 * @param type $max_w
	 * @param type $max_h
	 */
	public function ProcessingImages($src_file, $max_w ,$max_h){
		//得到原始的宽高
		$src_info = getimagesize($src_file);
		$src_w = $src_info[0];
		$src_h = $src_info[1];
	
		//计算 宽之比 和 高之比
		$scale_w = $src_w/$max_w;
		$scale_h = $src_h/$max_h;
	
		//比较 宽之比 和 高之比
		if($scale_w > $scale_h) {
			$dst_w = $max_w;
			$dst_h = $dst_w * ($src_h/$src_w);
		} else {
			$dst_h = $max_h;
			$dst_w = $dst_h * ($src_w/$src_h);
		}
		//创建原始和目标（缩略图）
		$src_img = imagecreatefromjpeg($src_file);
		$dst_img = imagecreatetruecolor($dst_w, $dst_h);
	
		//采样-拷贝-修改大小
		imagecopyresampled($dst_img, $src_img, 0, 0, 0, 0, $dst_w, $dst_h, $src_w, $src_h);
		return $dst_img;
	}
	
	/**
	 * 解析base64字符串为图片并保存到指定目录
	 * @param unknown $base64_str
	 * @param unknown $save_path(绝对路径)
	 * @return NULL
	 */
	public function getBase64Images($base64_str, $save_path){
		
		if(!$base64_str){
			return null;
		}
		$this->mk_dir($save_path);
		$images = base64_decode($base64_str);
		$save_path = $save_path . md5(time().'base64') . '.png';
		$result = file_put_contents($save_path, $images);
		return $save_path;
	}


}

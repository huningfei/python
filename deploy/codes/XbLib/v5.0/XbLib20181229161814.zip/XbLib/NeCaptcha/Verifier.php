<?php

/*
 * 调用网易云顿验证
 * 
 */

require_once dirname(__FILE__) . '/NECaptchaVerifier.class.php';
require_once dirname(__FILE__) . '/SecretPair.class.php';


class XbLib_NeCaptcha_Verifier {
    private static $_verifier;
    
    /**
     * 获取验证对象
     * 
     * @return NECaptchaVerifier
     */
    public static function getVerifier() {
        if (!self::$_verifier)
        {
            $env = getenv('RUNTIME_ENVIROMENT') ? getenv('RUNTIME_ENVIROMENT') : (defined('SHELL_VARIABLE') ? SHELL_VARIABLE : '');
            $env = empty($env) ? 'local' : ($env != 'rls' ? 'local' : $env);
            
            $config = require dirname(__FILE__) . '/Config.php';
            $config = $config[$env];
            
            self::$_verifier = new NECaptchaVerifier($config['YIDUN_CAPTCHA_ID'], new SecretPair($config['YIDUN_CAPTCHA_SECRET_ID'], $config['YIDUN_CAPTCHA_SECRET_KEY']));
        }
        
        return self::$_verifier;
    }
    
    /**
     * 校验验证结果
     * 
     * @param unknown $validate 提交二次校验的验证数据，即NECaptchaValidate值
     * @param string $user 用户信息，可用为空
     * @return boolean
     */
    public static function check($validate, $user = '') {
        $validate = stripcslashes($validate);
        return self::getVerifier()->verify($validate, $user);
    }
}
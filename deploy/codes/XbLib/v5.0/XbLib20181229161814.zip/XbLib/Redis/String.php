<?php
/**
 * Created by lobo.
 * User: lobo
 * Email: wu_poem@foxmail.com
 * Date: 15-3-18
 * Time: 上午11:09
 */

class XbLib_Redis_String extends XbLib_Redis_Base {
    private function __construct() {
    }

    /**
     * 将字符串值 $val 关联到 $key
     * @param unknown_type $key
     * @param unknown_type $val
     * @return boolean
     */
    public static function sSet($key,$val)
    {
        self::_init ();
        return self::$_redis->SET($key,$val);
    }
    /**
     * 返回 key 所关联的字符串值
     * @param unknown_type $key
     */
    public static function sGet($key)
    {
        self::_init ();
        return self::$_redis->GET($key);
    }
    /**
     * 删除 key 的值
     * @param unknown_type $key
     */
    public static function sDel($key)
    {
        self::_init ();
        return self::$_redis->DELETE($key);
    }
    /**
     * 将 key 中储存的数字值增一
     * @param unknown_type $key
     */
    public static function sIncr($key)
    {
        self::_init ();
        return self::$_redis->INCR($key);
    }
}
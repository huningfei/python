<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2014-9-29
 * UTF-8
 */
class XbLib_Redis_SortedSet extends XbLib_Redis_Base {
	function __construct() {
	}

	/**
	 * 向key中增加一个数据
	 * 如果该member存在 则更新该成员的分值
	 *
	 * @param unknown $key
	 * @param unknown $score
	 * @param unknown $member
	 */
	public static function zAdd($key, $score, $member) {
		self::_init ();
		return self::$_redis->zAdd ( $key, $score, $member );
	}

	/**
	 * 获得指定范围内的已经排序后的数据 升序
	 *
	 * @param unknown $key
	 * @param unknown $star
	 * @param unknown $end
	 * @param unknown $withscores
	 */
	public static function zRange($key, $star, $end, $withscores = false) {
		self::_init ();
		return self::$_redis->zRange ( $key, $star, $end, $withscores );
	}

	/**
	 * 获得指定范围内的已经排序后的数据 降序
	 *
	 * @param unknown $key
	 * @param unknown $star
	 * @param unknown $end
	 * @param unknown $withscores
	 */
	public static function zRevRange($key, $star, $end, $withscores = false) {
		self::_init ();
		return self::$_redis->zrevrange ( $key, $star, $end, $withscores );
	}

	/**
	 * 删除一个成员
	 *
	 * @param unknown $key
	 * @param unknown $member
	 */
	public static function zRem($key, $member) {
		self::_init ();
		return self::$_redis->zRem ( $key, $member );
	}

	/**
	 * 获得member在列表中排序后的索引
	 * 从小到大的排序索引
	 * @param unknown $key
	 * @param unknown $member
	 */
	public static function zRank($key, $member) {
		self::_init ();
		return self::$_redis->zRank ( $key, $member );
	}

	/**
	 * 获得member在列表中排序后的索引
	 * 从大到小排序的索引
	 * @param unknown $key
	 * @param unknown $member
	 */
	public static function zRevRank($key, $member) {
		self::_init ();
		return self::$_redis->zRevRank ( $key, $member );
	}

	/**
	 * 获得总数
	 *
	 * @param unknown $key
	 */
	public static function zCard($key) {
		self::_init ();
		return self::$_redis->zCard ($key);
	}

	/**
	 * 根据member 获得分数
	 *
	 * @param unknown $key
	 * @param unknown $member
	 */
	public static function zScore($key, $member) {
		self::_init ();
		return self::$_redis->zScore ( $key, $member );
	}

	/**
	 * 增量一个key member
	 * 已经存在则增量
	 * 不存在则新增
	 *
	 * @param unknown $key
	 * @param unknown $increment
	 *        	增量
	 * @param unknown $member
	 */
	public static function zIncrBy($key, $increment, $member) {
		self::_init ();
		return self::$_redis->zIncrBy ( $key, $increment, $member );
	}


	/**
	 * 获得分数在min max闭区间的所有元素 降序
	 * @param unknown $key
	 * @param unknown $min
	 * @param unknown $max
	 * @param string $withScore
	 * @param string $limit
	 * @return multitype:
	 */
	public static function zRangeByScore($key,$min,$max,$withScore=false,$limit=false){
		self::_init ();
		$where = array();
		if($withScore){
			$where['withscores'] = true;
		}
		if($limit){
			$where['limit'] = $limit;
		}
		$res = array();
		if(empty($where)){
			$res = self::$_redis->zRangeByScore ( $key, $min, $max );
		}else{
			$res = self::$_redis->zRangeByScore($key,$min,$max,$where);
		}
		return $res;
	}

	/**
	 * 获得分数在min max闭区间的所有元素 升序
	 * @param unknown $key
	 * @param unknown $min
	 * @param unknown $max
	 * @param string $withScore
	 * @param string $limit
	 * @return multitype:
	 */
	public static function zRevRangeByScore($key,$min,$max,$withScore=false,$limit=false){
		self::_init ();
		$where = array();
		if($withScore){
			$where['withscores'] = true;
		}
		if($limit){
			$where['limit'] = $limit;
		}
		$res = array();
		if(empty($where)){
			$res = self::$_redis->zRevRangeByScore ( $key, $min, $max );
		}else{
			$res = self::$_redis->zRevRangeByScore($key,$min,$max,$where);
		}
		return $res;
	}
}
<?php
/**
 *
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2014-9-29
 * UTF-8
 */
class XbLib_Redis_Base{

    /**
     * @var Redis
     */
	protected static $_redis = null;

	/**
	 * 初始化redis对象
	 */
	protected static function _init() {
		if (is_null ( self::$_redis ) || ! isset ( self::$_redis )) {
			$env = getenv('RUNTIME_ENVIROMENT') ? getenv('RUNTIME_ENVIROMENT') : (defined('SHELL_VARIABLE') ? SHELL_VARIABLE : '');
			$env = empty($env)?'local':$env;

			if(!file_exists(LIBRARY_DIR.'/Conf/'.$env.'/redis.php')){
				throw new Exception('can not found the redis_config file env:'.$env);
			}

			$config = require LIBRARY_DIR.'/Conf/'.$env.'/redis.php';

			if(!isset($config)){
				throw new Exception('can not found the redis_config env:'.$env);
			}
			$redisConfig = $config;
			try {
				self::$_redis = new Redis();
				self::$_redis->connect($redisConfig['host'], $redisConfig['port']);
				if(isset($redisConfig['auth'])&&!empty($redisConfig['auth'])){
					self::$_redis->auth($redisConfig['auth']);
				}
			} catch ( Exception $e ) {
				XbFunc_Log::write('systion_redis', 'connection',$e->getMessage());
			}
		}
	}

	/**
	 * key存活到一个unix时间戳时间
	 * @param  $key
	 * @param  $time
	 */
	public static function expireAt($key, $time) {
		self::_init();
		self::$_redis->expireAt($key, $time);
	}

	/**
	 * 设定一个key的活动时间（s）
	 * @param  $key
	 * @param  $expire
	 */
	public static function setTimeout($key, $expire) {
		self::_init();
		self::$_redis->setTimeout($key, $expire);
	}

    /**
     * 选择数据库
     * @param $num
     */
	public static function select($num){
	    self::_init();
	    self::$_redis->select($num);
    }

}
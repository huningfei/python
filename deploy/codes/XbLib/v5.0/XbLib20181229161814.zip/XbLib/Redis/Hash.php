<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2014-9-29
 * UTF-8
 */

class XbLib_Redis_Hash extends XbLib_Redis_Base {

	function __construct() {

	}

	/**
	 * 设置hash字段值
	 *
	 * @param unknown_type $key
	 * @param array $value        	$redis->hMset('user:1', array('name' => 'Joe', 'salary' => 2000));
	 */
	public static function hMSet($key, $value) {
		self::_init();
		return self::$_redis->HMSET ( $key, $value );
	}

	/**
	 * 读取hash的字段的值
	 *
	 * @param unknown_type $key
	 * @param array $value     $redis->hmGet('h', array('field1', 'field2'));
	 */
	public static function hMGet($key, $value) {
		self::_init();
		return self::$_redis->HMGET ( $key, $value );
	}

	/**
	 * 设置hash里面一个字段的值
	 *
	 * @param unknown_type $key
	 * @param unknown_type $field
	 * @param unknown_type $value
	 */
	public static function hSet($key, $field, $value) {
		self::_init();
		return self::$_redis->HSET ( $key, $field, $value );
	}

	/**
	 * 读取hash的字段的值
	 *
	 * @param unknown_type $key
	 */
	public static function hGetAll($key) {
		self::_init();
		return self::$_redis->HGETALL ( $key );
	}

	/**
	 * 获取hash里面指定字段的值
	 *
	 * @param unknown_type $key
	 * @param unknown_type $field
	 */
	public static function hGet($key, $field) {
		self::_init();
		return self::$_redis->HGET ( $key, $field );
	}

	/**
	 * 增加指定的哈希集中指定字段的数值
	 *
	 * @param unknown_type $key
	 * @param unknown_type $field
	 * @param unknown_type $step
	 */
	public static function hIncrby($key, $field, $step) {
		self::_init();
		return self::$_redis->HINCRBY ( $key, $field, $step );
	}

	/**
	 * 删除一个或多个hash集中的字段
	 *
	 * @param unknown_type $key
	 * @param unknown_type $field
	 */
	public static function hDel($key, $field) {
		self::_init();
		return self::$_redis->HDEL ( $key, $field );
	}

	/**
	 * 获取hash中字段的数量
	 *
	 * @param unknown_type $key
	 */
	public static function hLen($key) {
		self::_init();
		return self::$_redis->HLEN ( $key );
	}

	/**
	 * 返回字段是否是 key 指定的哈希集中存在的字段
	 * @param unknown_type $key
	 * @param unknown_type $field
	 */
	public static function hExists($key, $field) {
		self::_init();
		return self::$_redis->HEXISTS($key, $field);
	}

	/**
	 * 获得所有field
	 * @param unknown $key
	 */
	public static function hKeys($key){
		self::_init();
		return self::$_redis->hKeys($key);
	}
}
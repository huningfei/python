<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2015-11-10
 * UTF-8
 */
class XbLib_Msg_Adapter_Zhizhen extends XbLib_Msg_Abstract {
	
	/*
	 * (non-PHPdoc) @see XbLib_Msg_Abstract::work()
	 */
	public function work($mob, $msg) {
		// TODO Auto-generated method stub
		$this->channel = "ZhiZhen";
		
		$userName = "xbjf"; // 必选 string 帐号名称
		$userPass = "xb3574"; // 必选 string 密码
		$mobile = $mob; // 必选 string 多个手机号码之间用英文“,”分开，最大支持500个手机号码，同一请求中，最好不要出现相同的手机号码
		$subid = ""; // 选填 string 通道号码末尾添加的扩展号码
		$message = $msg; // 内容
		$url = 'http://115.28.112.245:8082/SendMT/SendMessage';
		
		$message = urlencode ( $message );
		
		$params = 'UserName=' . $userName . '&UserPass=' . $userPass . '&subid=' . $subid . '&Mobile=' . $mobile . '&Content=' . $message;
		$res = $this->curlGet ( $url, $params );
		$check_res = substr($res, 0,2);
		if($check_res != '03'){
			XbFunc_Log::write("SendMsg", "Error response.channel:{$this->channel}",$res);
			return false;
		}
		return true;
	}
	
	/**
	 * 
	 * @param unknown $url
	 * @param unknown $params
	 * @return mixed
	 */
	private function curlGet($url, $params) {
		$ch = curl_init ();
		curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
		curl_setopt ( $ch, CURLOPT_URL, $url );
		curl_setopt ( $ch, CURLOPT_POSTFIELDS, $params );
		curl_setopt ( $ch, CURLOPT_TIMEOUT, 3 );
		$data = curl_exec ( $ch );
		curl_close ( $ch );
		return $data;
	}
}
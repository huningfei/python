<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2015-11-10
 * UTF-8
 */
class XbLib_Msg_Main {
	private static $obj = null;
	/**
	 *
	 * @var unknown
	 */
	private $adapters = array ();
	private function __construct() {
		$zhizhen = new XbLib_Msg_Adapter_Zhizhen ();
		$this->adapters [] = $zhizhen;
	}
	
	/**
	 * 单例获取
	 * 
	 * @return XbLib_Msg_Main
	 */
	public static function getInstance() {
		if (is_null ( self::$obj )) {
			self::$obj = new XbLib_Msg_Main ();
		}
		return self::$obj;
	}

    /**
     * 发送消息
     * @param $userIp
     * @param $mobile
     * @param $type
     * @param $msgArr
     * @return bool
     */
	public function sendMessage($userIp, $mobile, $type, $msgArr) {
		$msg = XbLib_Msg_Config::getText($type);
		if(empty($msg)){
			return false;
		}
		
		$result = false;
		foreach ($msgArr as $key=>$value){
			$msg = str_replace($key, $value, $msg);
		}
		
		foreach ( $this->adapters as $adapter ) {
			$res = $adapter->sendMsg ( $userIp, $mobile, $msg );
			$result = $res;
			if ($res == false) {
				continue;
			} else {
				break;
			}
		}
		return $result;
	}
}
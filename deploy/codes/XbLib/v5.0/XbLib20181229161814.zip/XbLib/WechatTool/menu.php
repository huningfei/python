<?php
/**
 * 微信菜单栏应用
 * @author znz
 * 2017-09-05
 */
class XbLib_WechatTool_menu extends XbLib_WechatTool_main{
	
	private static $obj= null;
	public static function getInstance(){
		if(is_null(self::$obj)){
			self::$obj = new XbLib_WechatTool_menu();
		}
		return self::$obj;
	}
	/**
	 * 查询菜单
	 * @return Ambigous <string, mixed>
	 */
	public function select(){
		$menu_list = $this->send_http('menu_select', array());
		return json_decode($menu_list, true);
	}
	/**
	 * 创建&更新菜单
	 * @param unknown $menu_list
	 */
	public function create($menu_list){
		$result = $this->send_http('menu_create', $menu_list);
		return $result;
	}
	
}
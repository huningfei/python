<?php
/**
 * @desc    通道推荐模块
 * @author  qien
 * @date    18.03.26
 */
class XbLib_ChannelRecommend{
    private static $obj;
    private $limitChannel = array();
    private $Channel = array();
    private $integralChannel   = array();
    private $unintegralChannel = array();
    private $integralReason    = '';
    private $unintegralReason  = '';
    private $integralStatus    = true;
    private $Status    = true;
    private $unintegralStatus  = true;
    private $num               = 0;
    private $check_num         = 0;
    private $unintegralCount   = 0;
    private $Count             = 0;
    private $banks             =array();
    private $unbank              = array();
    private $inbank              = array();
    private $reason            = array(
        'checkTime'          => '当前时间暂不支持该信用卡，请选择下列方式完成收款',
        'checkAmount'        => '当前金额不在本通道限额内',
        'checkChannelAmount' => '本通道今日额度已经用完',
        'checkAllAmount'     => '本信用卡在所有此类型通道今日额度已使用完',
        'checkChannelBank'   => '暂不支持当前信用卡，请选择下列方式完成收款',
        'checkDayAmount'     => '当前信用卡本日收款额度剩余：',
        'checkMonAmount'     => '当前信用卡本月收款额度剩余：',
    );
    protected $_url  = 'https://api.xiaobaijinfu.com';

    /**
     * 单例
     * @return null|XbLib_ChannelRecommend
     */
    public static function getInstance() {
        if (empty(self::$obj)) {
            self::$obj = new XbLib_ChannelRecommend();
        }
        return self::$obj;
    }

    /**
     * @desc    推荐用户通道
     * @param   int     $uid        用户id
     * @param   int     $amount     刷卡金额
     * @return  array   $return     返回通道
     */
    public function getRecommendChannel($uid, $amount, $mch_id, $creditCard){
        //首先判断现有自己通道
        $return = array();
        $userLevelInfo = XbModule_Account_UsersLevel::getInstance()->getUserLevelByUid($uid);
        $userChannelCode = XbModule_Account_UsersChannel::getInstance()->getAllUserChannelByUid($uid, '2,3');
        XbFunc_Log::write('aaaa','channelcodes',json_encode($userChannelCode,JSON_UNESCAPED_UNICODE));
        if($userChannelCode){
            if(phpversion() < '5.5'){
                foreach($userChannelCode as $k=>$v){
                    $userChannelIdStr[] = $v['channel_id'];
                }
                $userChannelId = implode(',', $userChannelIdStr);
            }else{
                $userChannelId = implode(',', array_column($userChannelCode, 'channel_id'));
            }
            XbFunc_Log::write('aaaa','channelcode_ids',$userChannelId);

            //获取用户注册通道中相关等级通道信息
            $levelChannel = XbModule_Account_Channel::getInstance()->getChannelInfoByLevel($userLevelInfo['level'], 1, $userChannelId);
            if($levelChannel){
                foreach($levelChannel as $k=>$v){
                    $levelChannel[$k]['num'] = 0;
                    $levelChannel[$k]['channel_type'] = 1;
                    if($v['ccltype'] == 1 && $v['with_integral'] == 2){
                        unset($levelChannel[$k]);
                    }elseif($v['ccltype'] == 2 && $v['without_integral'] == 2){
                        unset($levelChannel[$k]);
                    }
                }
                $this->limitChannel = $levelChannel;
                XbFunc_Log::write('aaaa','channelcodes',json_encode($levelChannel,JSON_UNESCAPED_UNICODE));

                //校验是否支持信用卡
                $bank_res = $this->checkChannelBank($creditCard, 1);
                if($bank_res) return $bank_res;
                $time_res = $this->checkChannelTime($creditCard);
                if($time_res) return $time_res;
                $day_res = $this->checkDayAmounts($uid, $mch_id, $creditCard, $amount);
                if($day_res) return $day_res;
                $mon_res = $this->checkMonthamount($uid, $mch_id, $creditCard, $amount);
                if($mon_res) return $mon_res;
                $amount_res =$this->checkAmount($amount,$creditCard);
                if($amount_res) return $amount_res;
                $this->checkChannel($uid,$mch_id);

                if(count($this->Channel)>0){
                    $channel = $this->Channel;
                    $integralAmount  = XbLib_ChannelTools::computeFee($amount, $channel['rate'], $channel['fee']);

                    $return = array(
                        'type' => 1,
                        'channel_id'     =>$channel['cclid'],
                        'channel_name'   =>$channel['channel_name'],
                        'channel_type'   =>$channel['channel_type'],
                        'channel_tag'    =>$channel['desc'],
                        'time_lines'     =>$channel['timelines'],
                        'fee_amount'     => $amount.'*'.($channel['rate']*100).'%+'.$channel['fee'].'='.$integralAmount.'元',
                        'note'           => '当前费率根据模拟算法得出，请以银行真实扣款为准！',
                        'rate'           => $channel['rate'],
                        'fee'            => $channel['fee'],
                        'mininum_charge' => $channel['mininum_charge'],
                        'maxnum_charge'  => $channel['maxnum_charge'],
                        'reason'         => '',
                        'common_channel_id'     => $channel['channel_id']
                    );
                }
                return $return ? $return: new XbLib_WebError(5200);
            }else{
                return new XbLib_WebError(5200);
            }
        }else{
            return new XbLib_WebError(5200);
        }
    }

    public function restore($data,$reason){
        if($this->Count != 0){
            if(($this->inbank && count($this->inbank)>=2) ||$this->num>1){
                return (array('code'=>5203,'data'=>array('unbank'=>$this->unbank,'inbank'=>$this->inbank,'reason'=>$reason)));
            }else{
                $this->Channel = array();
                $this->Count   = 0;
            }
        }else{
            $this->Channel = array();
            $this->Count   = 0;
            if(count($this->banks)>0 && ($this->inbank || $this->unbank)){
                return (array('code'=>5203,'data'=>array('unbank'=>$this->unbank,'inbank'=>$this->inbank,'reason'=>$reason)));
            }
            if($data){
                return (array('code'=>5204,'data'=>$data));
            }
        }
        return;
    }


    /*
     * @desc    检查刷卡金额是否符合通道金额
     */
    public function checkAmount($amount,$creditCard){
        $data = [];
        if(count($this->limitChannel) > 0) {

            $res = XbModule_Account_CreditCard::getInstance()->getInfoByCardNumber($creditCard);
            if ($res && !empty($res['bankCode'])) {
                foreach ($this->limitChannel as $k => $v) {
                    $check = XbLib_ChannelTools::getInstance()->checkChannelBank($v['cclid'], $res['bankCode'], 1);
                    if ($amount >= $check['mininum_charge'] && $amount <= $check['maxnum_charge']) {
                        $this->Count += 1;
                    } else {
                        $min = $check['mininum_charge'];
                        $max = $check['maxnum_charge'];
                        unset($this->limitChannel[$k]);
                    }
                    $this->Channel[] = $v;
                }
                if($this->Count == 0){
                    $data['min'] = $min;
                    $data['max'] = $max;
                }
            }
        }

       return $this->restore($data,'');
    }

    public function checkMaxFee($amount){
        $integralIncome   = array();
        foreach($this->limitChannel as $k=>$v){
                $integralIncome[$k] = XbLib_ChannelTools::countIncome($amount, $v['rate'], $v['rate_cost'], $v['fee'], $v['service_cost']);
                $integralChannel[$k] = $v;
        }

        if($this->Status){
            $integralMax = max($integralIncome);
            $integralKey = array_search($integralMax, $integralIncome);
            $this->Channel = array($integralChannel[$integralKey]);
        }

        return;
    }
    public function checkDayAmounts($uid, $mch_id, $creditCard, $amount)
    {
        //获取用户信用卡code码
        $reamin_amount = array();
        if (count($this->limitChannel) > 0) {
            $new_channelAmount = 0;
            $count = null;
            $startTime = mktime(0, 0, 0, date("m"), date("d"), date("Y"));
            $endTime   = mktime(23, 59, 59, date("m"), date("d"), date("Y"));
            $res = XbModule_Account_CreditCard::getInstance()->getInfoByCardNumber($creditCard);
            if ($res && !empty($res['bankCode'])) {
                foreach ($this->limitChannel as $k => $v) {
                    $check = XbLib_ChannelTools::getInstance()->checkChannelBank($v['cclid'], $res['bankCode'],1);
                    $channelAmount = XbModule_Account_Order::getInstance($mch_id)->getAllAmountByUid($uid, 1, $v['cclid'], $v['channel_type'], $creditCard, $startTime, $endTime);
                    $new_channelAmount += $amount;
                    $new_channelAmount += $channelAmount;
                    if ($check['card_day_max_charge'] >= $new_channelAmount) {
                       $this->Count += 1;
                        $this->Channel[] = $v;
                    } else {
                        if($check['card_day_max_charge']-$channelAmount < 0){
                            $reamin_amount[] = 0;
                        }else{
                            $reamin_amount[] = $check['card_day_max_charge']-$channelAmount;
                        }
                    }

                }
                arsort($reamin_amount);

                if($this->Count == 0){
                    $count = $this->Count;

                    $this->banks[] = $creditCard;
                    $bank_res = $this->getUserBanks($res['uid']);
                    if($bank_res){
                        foreach($bank_res as $key => $val){
                            if(in_array($val['cardNumber'],$this->banks)){
                                unset($bank_res[$key]);
                            }
                        }
                        foreach($bank_res as $key => $val){
                            $this->checkChannelBank($val['cardNumber']);
                        }
                    }
                    $bank['cid'] = $res['id'];
                    $bank['status'] = 'false';
                    $bank['cardNumber'] = substr($creditCard, -0, 4);
                    $bank['img'] = $this->_url . '/static/img/bank/' . $res['bankCode'] . '.png';;
                    $bank['bankCode'] = $res['bankCode'];
                    $bank['bank'] = $res['bank'];
                    $bank['reason'] = $this->reason['checkDayAmount'].$reamin_amount[0];
                    $check_bank[$res['bankCode']] = $bank;
                    $this->unbank[] = $bank;
                    if($this->inbank && $this->unbank){
                        foreach($this->inbank as $key => $val){
                            foreach($check_bank as $kk =>$vv){
                                if($key == $kk){
                                    unset($this->inbank[$kk]);
                                }
                            }
                        }
                    }
                }
                else{
                    $this->limitChannel = $this->Channel;
                }
                if($count===0){
                    $this->Count = $count;
                }
            }
        }
        $res = $this->restore('',$this->reason['checkDayAmount'].$reamin_amount[0]);
        return $res;
    }
    public function checkMonthamount($uid, $mch_id, $creditCard, $amount)
    {
        //获取用户信用卡code码
        $reamin_amount = array();
        if (count($this->limitChannel) > 0) {
            $count = null;
            $startTime = mktime(0, 0, 0, date("m"), date("d"), date("Y"));
            $endTime   = mktime(23, 59, 59, date("m"), date("d"), date("Y"));
            $res = XbModule_Account_CreditCard::getInstance()->getInfoByCardNumber($creditCard);
            if ($res && !empty($res['bankCode'])) {
                foreach ($this->limitChannel as $k => $v) {
                    $check = XbLib_ChannelTools::getInstance()->checkChannelBank($v['cclid'], $res['bankCode'],1);
                    $channelAmount = XbModule_Account_Order::getInstance($mch_id)->getAllAmountByUid($uid, 1, $v['cclid'], $v['channel_type'], $creditCard, $startTime, $endTime);
                    $channelAmount += $amount;
                    if ($check['card_month_max_charge'] >= $channelAmount) {
                       $this->Count += 1;
                        $this->Channel[] = $v;
                    } else {
                        if($check['card_day_max_charge']-$channelAmount < 0){
                            $reamin_amount[] = 0;
                        }else{
                            $reamin_amount[] = $check['card_day_max_charge']-$channelAmount;
                        }                    }
                }
                arsort($reamin_amount);

                if($this->Count == 0){
                    $this->banks[] = $creditCard;
                    $bank_res = $this->getUserBanks($res['uid']);
                    if($bank_res){
                        foreach($bank_res as $key => $val){
                            if(in_array($val['cardNumber'],$this->banks)){
                                unset($bank_res[$key]);
                            }
                        }
                        foreach($bank_res as $key => $val){
                            $this->checkChannelBank($val['cardNumber']);
                        }
                    }
                    $bank['cid'] = $res['id'];
                    $bank['status'] = 'false';
                    $bank['cardNumber'] = substr($creditCard, -0, 4);
                    $bank['img'] = $this->_url . '/static/img/bank/' . $res['bankCode'] . '.png';;
                    $bank['bankCode'] = $res['bankCode'];
                    $bank['bank'] = $res['bank'];
                    $bank['reason'] = $this->reason['checkDayAmount'].$reamin_amount[0];
                    $check_bank[$res['bankCode']] = $bank;
                    $this->unbank[] = $bank;
                    if($this->inbank && $this->unbank){
                        foreach($this->inbank as $key => $val){
                            foreach($check_bank as $kk =>$vv){
                                if($key == $kk){
                                    unset($this->inbank[$kk]);
                                }
                            }
                        }
                    }                }else{
                    $this->limitChannel = $this->Channel;
                }
            }
            if($count===0){
                $this->Count = $count;
            }

        }
        $res = $this->restore('',$this->reason['checkMonAmount'].$reamin_amount[0]);
        return $res;
    }
    public function checkChannelBank($creditCard, $is_users = 0){
        //获取用户信用卡code码
        if(count($this->limitChannel) > 0){
            $res = XbModule_Account_CreditCard::getInstance()->getInfoByCardNumber($creditCard);
            if($res && !empty($res['bankCode'])){
                foreach($this->limitChannel as $k=>$v){
                    $check=  XbLib_ChannelTools::getInstance()->checkChannelBank($v['cclid'],$res['bankCode'],1);
                    if($check) {
                        $this->Count += 1;
                        $check_time = XbLib_ChannelTools::checkChannelTime($v['time'], $v['week']);
                        if (!$check_time) {
                            $bank['cid'] = $res['id'];
                            $bank['status'] = 'false';
                            $bank['cardNumber'] = substr($creditCard, -4, 4);
                            $bank['img'] = $this->_url . '/static/img/bank/' . $res['bankCode'] . '.png';;
                            $bank['bankCode'] = $res['bankCode'];
                            $bank['bank'] = $res['bank'];
                            $bank['reason'] = '该卡片交易时间为：' . $v['time'];
                            $this->unbank[] = $bank;
                            $this->num = $this->num+1;
                        } else {
                            $bank['cid'] = $res['id'];
                            $bank['status'] = 'true';
                            $bank['cardNumber'] = substr($creditCard, -4, 4);
                            $bank['img'] = $this->_url . '/static/img/bank/' . $res['bankCode'] . '.png';;
                            $bank['bankCode'] = $res['bankCode'];
                            $bank['bank'] = $res['bank'];
                            $bank['reason'] = '该卡片交易时间为：' . $v['time'];
                            $this->inbank[] = $bank;
                        }
                        $this->Channel[] = $v;

                        if ($this->inbank) {
                            $inbank = [];
                            foreach ($this->inbank as $kk => $vv) {
                                $inbank[$vv['bankCode']] = $vv;
                            }
                            $this->inbank = $inbank;
                        }
                        if ($this->unbank) {
                            $unbank = [];
                            foreach ($this->unbank as $kk => $vv) {
                                $unbank[$vv['bankCode']] = $vv;
                            }
                            $this->unbank = $unbank;
                        }
                    }else{
                        $bank['cid']    = $res['id'];
                        $bank['cardNumber'] = substr($creditCard,-4,4);
                        $bank['img'] = $this->_url.'/static/img/bank/'.$res['bankCode'].'.png';;
                        $bank['bankCode'] = $res['bankCode'];
                        $bank['bank']     = $res['bank'];
                        $bank['status']   = 'false';
                        $bank['reason']   = '暂不支持该卡片';
                        $this->unbank[]=$bank;
                        $this->num = $this->num+1;
                        if($this->unbank){
                            $unbank = [];
                            foreach($this->unbank as $kk =>$vv){
                                $unbank[$vv['bankCode']] = $vv;
                            }
                            $this->unbank = $unbank;
                        }
                    }
                }
                if(count($this->inbank)>0){
                    $this->limitChannel = $this->Channel;
                }
                if($this->Count == 0){
                    $this->banks[] = $creditCard;
                    $bank_res = $this->getUserBanks($res['uid']);
                    if($bank_res){
                        foreach($bank_res as $key => $val){
                            if(in_array($val['cardNumber'],$this->banks)){
                                unset($bank_res[$key]);
                            }
                        }
                        foreach($bank_res as $key => $val){
                            $this->checkChannelBank($val['cardNumber']);
                        }
                    }
                }else{
                    if($this->inbank && $this->unbank){
                        foreach($this->inbank as $key => $val){
                            foreach($this->unbank as $kk =>$vv){
                                if($key == $kk){
                                    unset($this->unbank[$kk]);
                                }
                            }
                        }
                    }
                    if ($is_users == 1 && !empty($this->inbank[$res['bankCode']])) {
                        $this->num=0;
                        return;
                    }
                }

            }
        }
       return $this->restore('',$this->reason['checkChannelBank']);
    }
    /*
     * @desc    检查通道时间
     */
    public function checkChannelTime($creditCard){
        if(count($this->limitChannel) > 0){
            $res = XbModule_Account_CreditCard::getInstance()->getInfoByCardNumber($creditCard);
            foreach($this->limitChannel as $k=>$v){
                $check = XbLib_ChannelTools::checkChannelTime($v['time'], $v['week']);
                if(!$check){
                    $time = $v['time'];
                }else{
                    $this->Count += 1;
                    $this->Channel[]   = $v;
                }

            }
            if($this->Count == 0){
                $this->banks[] = $creditCard;
                $bank_res = $this->getUserBanks($res['uid']);
                if($bank_res){
                    foreach($bank_res as $key => $val){
                        if(in_array($val['cardNumber'],$this->banks)){
                            unset($bank_res[$key]);
                        }
                    }
                    foreach($bank_res as $key => $val){
                        $this->checkChannelBank($val['cardNumber']);
                    }
                }
            }else{
                $this->limitChannel = $this->Channel;
            }
        }
        return $this->restore('',$this->reason['checkTime']);
    }
    /**
     * @desc 查询用户的信用卡
     */
    public function getUserBanks($uid){
        $banks = XbModule_Account_CreditCard::getInstance()->getAllCreditCard($uid);
        if($banks){
            if(count($banks) >=2){
                return $banks;
            }else{
                return false;
            }
        }else{
            return false;
        }
    }
    /**
     * @desc 通道权重
     */
    public function checkChannel($uid,$mch_id){
        if(count($this->limitChannel) > 0) {

            foreach($this->limitChannel as $k=>$v){
                //获取当前用户是否有过订单
                $order_count = XbModule_Account_Order::getInstance($mch_id)->countOrderByUid($uid,array('channel_id'=>$v['channel']));
                if(!$order_count){
                    $this->limitChannel[$k]['num'] += 3;
                }
                //获取用户最后一条收款成功的订单
                $lastOrder = XbModule_Account_Order::getInstance($mch_id)->getUserLastOrder($uid,1);
                if($lastOrder['channel_id'] != $v['channel']){
                    $this->limitChannel[$k]['num'] += 2;
                }
                $rate[$k] = $v['rate'];
                $channel[$k]=$v['id'];
            }
            asort($rate);
            arsort($channel);

            foreach($this->limitChannel as $k => $v){
                if($v['rate'] == current($rate)){
                    $this->limitChannel[$k]['num'] += 1;
                }
                $num[$k] =$this->limitChannel[$k]['num'];
            }

            $channel_id_arr = array_column($this->limitChannel, 'channel_id');
            if (in_array(9, $channel_id_arr)){
                $channel_key = array_search(9,$channel_id_arr);
                $this->Channel = $this->limitChannel[$channel_key];
            }

            arsort($num);
            if(current($num) == next($num)){
               $this->Channel = $this->limitChannel[current(array_keys($channel))];
            }else{
                $this->Channel = $this->limitChannel[current(array_keys($num))];
            }
        }
        return ;
    }
}
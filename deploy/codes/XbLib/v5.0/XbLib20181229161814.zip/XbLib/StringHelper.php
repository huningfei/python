<?php 
/**
 * 字符串处理公共类
 * @author fengshuang
 * 
 */
class XbLib_StringHelper{
	
	//获取 指定长度的字符串
	public static function getRandomString($length = 6){
		$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		$str = "";
		for ($i = 0; $i < $length; $i++) {
			$str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
		}
		return $str;
	}
	
	public static function getRandomPassword($length = 8 ){
		$chars = "0123456789abcdefghijklmnopqrstuvwxyz";
		$str = "";
		for ($i = 0; $i < $length; $i++) {
			$str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
		}
		return $str;
	} 
	
	
	public static function getNumberCode($length = 10){
		
		$chars = "0123456789";
		$str = "";
		for ($i = 0; $i < $length; $i++) {
			$str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
		}
		return $str;
	}
	
	//对称加密
	public static function encrypt($string,$key="password"){
	$crypttext = base64_encode(
			mcrypt_encrypt(
					MCRYPT_RIJNDAEL_256, 
					md5($key), $string, 
					MCRYPT_MODE_CBC, 
					md5(md5($key))
					)
			);

		$encrypted =trim(self::safe_b64encode($crypttext));//对特殊字符进行处理
		return $encrypted;
	}
	
	//对称解码
	public static function decrypt($encrypted,$key="password"){
		$crypttexttb=self::safe_b64decode($encrypted);//对特殊字符解析
		$decryptedtb = rtrim(
				mcrypt_decrypt(
						MCRYPT_RIJNDAEL_256, 
						md5($key),
						base64_decode($crypttexttb),
						MCRYPT_MODE_CBC, 
						md5(md5($key))), 
				"\0");//解密函数
		return $decryptedtb;
	}

	
	function safe_b64encode($string) {
	
		$data = base64_encode($string);
	
		$data = str_replace(array('+','/','='),array('-','_',''),$data);
	
		return $data;
	
	}
	
	
	//解析特殊字符
	
	function safe_b64decode($string) {
	
		$data = str_replace(array('-','_'),array('+','/'),$string);
	
		$mod4 = strlen($data) % 4;
	
		if ($mod4) {
			$data .= substr('====', $mod4);
		}
	
		return base64_decode($data);
	
	}	
	
	
}
?>
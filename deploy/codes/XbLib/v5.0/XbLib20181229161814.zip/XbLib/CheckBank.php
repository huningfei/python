<?php
/**
 * @desc    四要素验证
 * @author  yurong
 * @date    18.03.28
 */
class XbLib_CheckBank
{
    private static $obj;
    private $data = NULL;
    private $url = NULL;
    private $key = NULL;
    private $USER_ID = NULL;

    private function __construct($data){
        $env = getenv('RUNTIME_ENVIROMENT') ? getenv('RUNTIME_ENVIROMENT') : (defined('SHELL_VARIABLE') ? SHELL_VARIABLE : '');
        $env = empty($env)?'local':$env;
        if($env == 'rls'){
            $this->url='http://222.76.210.177:9001/MyLandQuickPay/controller/pay';
            $this->key='F3D6E4BFFA355AA13843AE7A143630EF';
            $this->USER_ID='990100000011009';
        }else{
            $this->url="http://220.160.118.218:8281/MyLandQuickPay/controller/pay";
            $this->key="0984234A4145ABDF43535ABCD1234988";
            $this->USER_ID='990581000011021';
        }
        $this->data = $data;
    }
    private function __clone(){

    }

    /*
     * */
    public static function getInstance($data)
    {
        if (empty(self::$obj)) {
            self::$obj = new XbLib_CheckBank($data);
        }
        return self::$obj;
    }

    public function checkBank(){
        if(empty($this->data)) return false;
        $sign_param = array(
            'ORDER_ID'   => $this->data['order_id'],
            'USER_TYPE'  => '02',
            'USER_ID'    => $this->USER_ID,
            'BUS_CODE'   => '1013',
            'CHECK_TYPE' => '01',
            'ACCT_NO'    => $this->data['bankcardNumber'],
            'PHONE_NO'   => $this->data['phone'],
        );
        $param = $sign_param;
        $param['SIGN_TYPE'] = '03';
        $param['ID_NO']     = $this->data['idcardNumber'];
        $param['NAME']      = $this->data['realname'];
        $param['CARD_TYPE'] = $this->data['type'];
        $param['SIGN']       = $this->getSign($sign_param);
        //校验前存库

        $this_header = array(
            "content-type: application/x-www-form-urlencoded;charset=UTF-8"
        );
        $res = XbLib_CurlHttp::postNew($this->url,$param,$this_header,true);
        $checkRes = $this->checkError($res);
        return $checkRes && $checkRes['code']!=400 ? $checkRes:false;
    }

    public  function getSign($data){
        $key = $this->key;
        $str = implode('',array_values($data));
        $sign_1 = strtoupper(md5($str));
        $sign_2 = strtoupper(md5($sign_1.$key));
        $sign = substr($sign_2,8,16);
        return $sign;
    }
    public function checkError($data){
        $return = array(
            'code'=>400,
            'msg'=>''
        );
        if($data && $data['RESP_CODE']){
            $return['code'] = $data['RESP_CODE'];
            $return['msg'] = $data['RESP_DESC'];
        }
        return $return;
    }
}
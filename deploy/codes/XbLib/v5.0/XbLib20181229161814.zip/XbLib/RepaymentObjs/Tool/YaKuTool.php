<?php
class XbLib_RepaymentObjs_Tool_YaKuTool {
    public $config = '';

    function __construct($config){
        $this->config = $config;
    }

    /**
     * getSignMsg 计算签名
     * @param array $pay_params
     *        	计算签名数据
     * @param string $sign_type
     *        	签名类型
     * @return string $signMsg 返回密文
     */
    function getSignMsg($pay_params = array(), $sign_type='', $_input_charset='') {
        $sign_type = $sign_type ? $sign_type : $this->config['sign_type'];
        $_input_charset = $_input_charset ? $_input_charset : $this->config['_input_charset'];
        $params_str = "";
        $signMsg = "";

        foreach ( $pay_params as $key => $val ) {
            if ($key != "sign" && $key != "sign_type" && $key != "sign_version" && isset ( $val ) && @$val != "") {
                $params_str .= $key . "=" . $val . "&";
            }
        }
        $params_str = substr ( $params_str, 0, - 1 );
        $params_str=mb_convert_encoding($params_str,$_input_charset);
        switch (@$sign_type) {
            case 'RSA' :
                self::write_log("RSA参与签名运算数据".$params_str);
                $priv_key = $this->config['rsa_sign_private_key'];
                $pkeyid = openssl_pkey_get_private ( $priv_key );
                self::write_log("RSApkeyid:".$pkeyid);
                openssl_sign ( $params_str, $signMsg, $pkeyid, OPENSSL_ALGO_SHA1 );
                openssl_free_key ( $pkeyid );
                $signMsg = base64_encode ( $signMsg );
                self::write_log("RSA计算得出签名值：".$signMsg);
                break;
            case 'MD5' :
            default :
//				$params_str = $params_str . @rpymt_md5_key;
//				self::write_log("MD5参与签名运算数据".$params_str);
//				$signMsg = strtolower ( md5 ( $params_str ) );
//				self::write_log("MD5计算得出签名值：".$signMsg);
                break;
        }
        return $signMsg;
    }
    /**
     * 通过公钥进行rsa加密
     *
     * @param type $name
     *        	Descriptiondata
     *        	$data 进行rsa公钥加密的数必传
     *        	$pu_key 加密用的公钥 必传
     *          $_input_charset 字符集编码
     * @return 加密好的密文
     */
    function Rsa_encrypt($data, $_input_charset='') {
        $_input_charset = $_input_charset ? $_input_charset : $this->config['_input_charset'];
        $encrypted = "";
        $data=mb_convert_encoding($data,$_input_charset);
        $cert = $this->config['rsa_public_key'];
        $pu_key = openssl_pkey_get_public ( $cert ); // 这个函数可用来判断公钥是否是可用
        openssl_public_encrypt ( $data, $encrypted, $pu_key ); // 公钥加密
        $encrypted = base64_encode ( $encrypted ); // 进行编码
        return $encrypted;
    }
    /**
     * [createcurl_data 拼接模拟提交数据]
     *
     * @param array $pay_params
     * @return string url格式字符
     */
    function createcurl_data($pay_params = array()) {
        $params_str = "";
        foreach ( $pay_params as $key => $val ) {
            if (isset ( $val ) && ! is_null ( $val ) && @$val != "") {
                $params_str .= "&" . $key . "=" . urlencode ( urlencode ( trim ( $val ) ) );
            }
        }
        if ($params_str) {
            $params_str = substr ( $params_str, 1 );
        }
        return $params_str;
    }
    /**
     * checkSignMsg 回调签名验证
     *
     * @param array $pay_params 参与签名验证的数据
     * @param string $sign_type  签名类型
     * @param $_input_charset   签名字符集编码
     * @return boolean  签名结果
     */
    function checkSignMsg($pay_params = array(), $sign_type='',$_input_charset='') {
        $sign_type = $sign_type ? $sign_type : $this->config['sign_type'];
        $_input_charset = $_input_charset ? $_input_charset : $this->config['_input_charset'];
        $params_str = "";
        $signMsg = "";
        $return = false;
        foreach ( $pay_params as $key => $val ) {
            if ($key != "sign" && $key != "sign_type" && $key != "sign_version" && ! is_null ( $val ) && @$val != "") {
                $params_str .= "&" . $key . "=" . $val;
            }
        }
        if ($params_str) {
            $params_str = substr ( $params_str, 1 );
        }
        //验证签名demo需要支持多字符集所以此处对字符编码进行转码处理,正常商户不存在多字符集问题
        $params_str=mb_convert_encoding($params_str,$_input_charset,"UTF-8");
        $this->write_log("本地验证签名数据".$params_str);
        $this->write_log("本地获取签名".$pay_params ['sign']);
        switch (@$sign_type) {
            case 'RSA' :
                $cert = $this->config['rsa_sign_public_key'];
                $pubkeyid = openssl_pkey_get_public ( $cert );
                $ok = openssl_verify ( $params_str, base64_decode ($pay_params ['sign']), $cert, OPENSSL_ALGO_SHA1 );
                $return = $ok == 1 ? true : false;
                openssl_free_key ( $pubkeyid );
                break;
            default :
                break;
        }
        return $return;
    }
    /**
     * 文件摘要算法
     */
    function md5_file($filename) {
        return md5_file ( $filename );
    }
    /**
     * sftp上传企业资质
     * sftp upload
     * @param $file 上传文件路径
     * @return false 失败   true 成功
     */
    function sftp_upload($file,$filename) {
        $strServer = sftp_address;
        $strServerPort = sftp_port;
        $strServerUsername = sftp_Username;
        $strServerprivatekey = sftp_privatekey;
        $strServerpublickey = sftp_publickey;
        $resConnection = ssh2_connect ( $strServer, $strServerPort );
        if (ssh2_auth_pubkey_file ( $resConnection, $strServerUsername, $strServerpublickey, $strServerprivatekey ))
        {
            $resSFTP = ssh2_sftp ( $resConnection );
            file_put_contents ( "ssh2.sftp://{$resSFTP}/upload/".$filename, $file);
            if (! copy ( $file, "ssh2.sftp://{$resSFTP}/upload/$filename" )) {
                return false;
            }
            return true;
        }
        return false;
    }
    /**
     * [curlPost 模拟表单提交]
     *
     * @param string $url  请求网关地址
     * @param string $data  请求数据key=value格式
     * @param $_input_charset 字符集编码
     * @return string $data
     */
    function curlPost($url, $data,$_input_charset='') {
        $_input_charset = $_input_charset ? $_input_charset : $this->config['_input_charset'];
        self::write_log("请求网关地址".$url);
        self::write_log("请求网关数据".$data);
        $ch = curl_init ();
        curl_setopt ( $ch, CURLOPT_URL, $url );
        curl_setopt ( $ch, CURLOPT_POST, 1 );
        curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
        curl_setopt ( $ch, CURLOPT_POSTFIELDS, $data );
        curl_setopt ( $ch, CURLOPT_SSL_VERIFYHOST, 0 );
        curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, 0 );
        $data = curl_exec ( $ch );
        curl_close ( $ch );
        self::write_log("请求网关返回内容:".mb_convert_encoding(urldecode($data),"UTF-8"));
        //由于json转数组使用了json_decode所以需要将非UTF-8的内容强转为UTF-8字符集
        //return mb_convert_encoding(urldecode($data),"UTF-8");
        $data = urldecode($data);
        return $data;
    }
    /**
     * 日志记录
     *
     * @param unknown $msg
     * @return boolean
     */
    function write_log($msg) {
        date_default_timezone_set("PRC");
        if($this->config['debug_status']){
            $result=error_log( date ( "[YmdHis]" ) ."\t" . $msg . "\r\n", 3, '/tmp'. date ( "Ymd" ) . '.log' );
            return $result;
        }else
        {
            return false;
        }

    }

    /**
     * 获取IP范例，具体以实现代码已自身网络架构来进行编写
     * @return string
     */
    function get_ip(){
        if (isset($_SERVER['HTTP_CLIENT_IP']) && strcasecmp($_SERVER['HTTP_CLIENT_IP'], "unknown"))
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        else if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && strcasecmp($_SERVER['HTTP_X_FORWARDED_FOR'], "unknown"))
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        else if (isset($_SERVER['REMOTE_ADDR']) && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
            $ip = $_SERVER['REMOTE_ADDR'];
        else if (isset($_SERVER['REMOTE_ADDR']) && isset($_SERVER['REMOTE_ADDR']) && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
            $ip = $_SERVER['REMOTE_ADDR'];
        else $ip = "47.104.152.197";
        return ($ip);
    }

    function get_base64($imgurl){
        try{
            $upload_path = '/home/yx/sites/xb_img/upload';
            $img_path = parse_url($imgurl)['path'];

            if (file_exists($upload_path.$img_path)){
                //文件存在
                $img_pathinfo = pathinfo($upload_path.$img_path);

                $new_image = XbLib_ImageUpload::getInstance()->ProcessingImages($upload_path.$img_path, 500, 500);

                if ($img_pathinfo['extension']) {
                    $tmp_path = $upload_path . '/tmp/';
                    $res_mkdir = XbLib_ImageUpload::getInstance()->mk_dir($tmp_path);
                    $tmp_img = $tmp_path . $img_pathinfo['basename'];

                    switch ($img_pathinfo['extension']) {
                        case 'jpg' :
                        case 'jpeg' :
                        case 'pjpeg' :
                            $res = imagejpeg ($new_image, $tmp_img);
                            break;
                        case 'png' :
                            $res = imagepng ($new_image, $tmp_img);
                            break;
                    }
                    $image_info = getimagesize($tmp_img);
                    $image_data = fread(fopen($tmp_img, 'r'), filesize($tmp_img));
                    $base64_image = 'data:' . $image_info['mime'] . ';base64,' . chunk_split(base64_encode($image_data));
                }
            }
        }catch (Exception $e){
            XbFunc_Log::write('yakukubaoSignUp','雅酷入网身份证图片转base64失败', $imgurl);
        }

        return urlencode($base64_image);
    }

    function get_shno(){
        $bj = array(
            '507489840143',
            '507491685199',
            '507492358200',
            '507493910951',
            '507495510302',
            '507496163298',
            '507498280595',
            '507499514204',
            '507501990366',
            '507502233993',
            '507503912974',
            '507504994840',
            '507505411489',
            '507506322236',
            '507507144002',
            '507508601874',
            '507509860440',
            '507510968102',
            '507511259399',
            '507512758650',
            '507513143890',
            '507515414989',
            '507516604515',
            '507517549336',
            '507519335586',
            '507520855452',
            '507522113084',
            '507523432259',
            '507525687997',
            '507526585242',
            '507527833490',
            '507529187893',
            '507530983728',
            '507532977740',
            '507533857267',
            '507535586486',
            '507536153208',
            '507537620561',
            '507490899276',
            '507494682043',
            '507497322750',
            '507500766280',
            '507514867745',
            '507518502000',
            '507521920315',
            '507524834370',
            '507528158456',
            '507531744189',
            '507534802384',
            '507538788519',
        );
        $no = $bj[array_rand($bj)];
        if (empty($bj[array_rand($bj)])){
            $no = '507489840143';
        }
        return $no;
    }

    function get_bank_code($code){
        $code_arr = array(
            'BJBANK'     => 'BCCB',
            'SHBANK'     => 'BOS',
            'BOHAIB'     => 'CBHB',
            'HZCB'       => 'HCCB',
            'HXBANK'     => 'HXB',
            'NBBANK'     => 'NBCB',
            'CZBANK'     => 'CZB',
            'SPABANK'    => 'SZPAB',
            'SRCB'       => 'SNXS',
        );

        $yaku_code = $code_arr[$code];
        if (!empty($yaku_code)){
            return $yaku_code;
        }
        return $code;
    }
}
?>
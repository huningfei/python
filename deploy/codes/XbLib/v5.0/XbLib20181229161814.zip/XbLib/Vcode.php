<?php

//验证码相关的所有操作
class XbLib_Vcode {

    private  $charset_arithmetic = array('+'=> '+','x'=> '*');   //随机因子
      private  $charset_text = "一乙二十丁厂七卜人入八九几儿了力乃刀又三于干亏士工土才寸下大丈与万上小口巾山千乞川亿个勺久凡及夕丸么广亡门义之尸弓己已子卫也女飞刃习叉马乡丰王井开夫天无元专云扎艺木五支厅不太犬区历尤友匹车巨牙屯比互切瓦止少日中冈贝内水见午牛手毛气升长仁什片仆化仇币仍仅斤爪反介父从今凶分乏公仓月氏勿欠风丹匀乌凤勾文六方火为斗忆订计户认心尺引丑巴孔队办以允予劝双书幻玉刊示末未击打巧正扑扒功扔去甘世古节本术可丙左厉右石布龙平灭轧东卡北占业旧帅归且旦目叶甲申叮电号田由史只央兄叼叫另叨叹四生失禾丘付仗代仙们仪白仔他斥瓜乎丛令用甩印乐句匆册犯外处冬鸟务包饥主市立闪兰半汁汇头汉宁穴它讨写让礼训必议讯记永司尼民出辽奶奴加召皮边发孕圣对台矛纠母幼丝式刑动扛寺吉扣考托老执巩圾扩扫地扬场耳共芒亚芝朽朴机权过臣再协西压厌在有百存而页匠夸夺灰达列死成夹轨邪划迈毕至此贞师尘尖劣光当早吐吓虫曲团同吊吃因吸吗屿帆岁回岂刚则肉网年朱先丢舌竹迁乔伟传乒乓休伍伏优伐延件任伤价份华仰仿伙伪自血向似后行舟全会杀合兆企众爷伞创肌朵杂危旬旨负各名多争色壮冲冰庄庆亦刘齐交次衣产决充妄闭问闯羊并关米灯州汗污江池汤忙兴宇守宅字安讲军许论农讽设访寻那迅尽导异孙阵阳收阶阴防奸如妇好她妈戏羽观欢买红纤级约纪驰巡寿弄麦形进戒吞远违运扶抚坛技坏扰拒找批扯址走抄坝贡攻赤折抓扮抢孝均抛投坟抗坑坊抖护壳志扭块声把报却劫芽花芹芬苍芳严芦劳克苏杆杠杜材村杏极李杨求更束豆两丽医辰励否还歼来连步坚旱盯呈时吴助县里呆园旷围呀吨足邮男困吵串员听吩吹呜吧吼别岗帐财针钉告我乱利秃秀私每兵估体何但伸作伯伶佣低你住位伴身皂佛近彻役返余希坐谷妥含邻岔肝肚肠龟免狂犹角删条卵岛迎饭饮系言冻状亩况床库疗应冷这序辛弃冶忘闲间闷判灶灿弟汪沙汽沃泛沟没沈沉怀忧快完宋宏牢究穷灾良证启评补初社识诉诊词译君灵即层尿尾迟局改张忌际陆阿陈阻附妙妖妨努忍劲鸡驱纯纱纳纲驳纵纷纸纹纺驴纽奉玩环武青责现表规抹拢拔拣担坦押抽拐拖拍者顶拆拥抵拘势抱垃拉拦拌幸招坡披拨择抬其取苦若茂苹苗英范直茄茎茅林枝杯柜析板松枪构杰述枕丧或画卧事刺枣雨卖矿码厕奔奇奋态欧垄妻轰顷转斩轮软到非叔肯齿些虎虏肾贤尚旺具果味昆国昌畅明易昂典固忠咐呼鸣咏呢岸岩帖罗帜岭凯败贩购图钓制知垂牧物乖刮秆和季委佳侍供使例版侄侦侧凭侨佩货依的迫质欣征往爬彼径所舍金命斧爸采受乳贪念贫肤肺肢肿胀朋股肥服胁周昏鱼兔狐忽狗备饰饱饲变京享店夜庙府底剂郊废净盲放刻育闸闹郑券卷单炒炊炕炎炉沫浅法泄河沾泪油泊沿泡注泻泳泥沸波泼泽治怖性怕怜怪学宝宗定宜审宙官空帘实试郎诗肩房诚衬衫视话诞询该详建肃录隶居届刷屈弦承孟孤陕降限妹姑姐姓始驾参艰线练组细驶织终驻驼绍经贯奏春帮珍玻毒型挂封持项垮挎城挠政赴赵挡挺括拴拾挑指垫挣挤拼挖按挥挪某甚革荐巷带草茧茶荒茫荡荣故胡南药标枯柄栋相查柏柳柱柿栏树要咸威歪研砖厘厚砌砍面耐耍牵残殃轻鸦皆背战点临览竖省削尝是盼眨哄显哑冒映星昨畏趴胃贵界虹虾蚁思蚂虽品咽骂哗咱响哈咬咳哪炭峡罚贱贴骨钞钟钢钥钩卸缸拜看矩怎牲选适秒香种秋科重复竿段便俩贷顺修保促侮俭俗俘信皇泉鬼侵追俊盾待律很须叙剑逃食盆胆胜胞胖脉勉狭狮独狡狱狠贸怨急饶蚀饺饼弯将奖哀亭亮度迹庭疮疯疫疤姿亲音帝施闻阀阁差养美姜叛送类迷前首逆总炼炸炮烂剃洁洪洒浇浊洞测洗活派洽染济洋洲浑浓津恒恢恰恼恨举觉宣室宫宪突穿窃客冠语扁袄祖神祝误诱说诵垦退既屋昼费陡眉孩除险院娃姥姨姻娇怒架贺盈勇怠柔垒绑绒结绕骄绘给络骆绝绞统耕耗艳泰珠班素蚕顽盏匪捞栽捕振载赶起盐捎捏埋捉";   //随机因子
      private  $charset = "abcdefghzkmnpqrstuvwxyABCDEFGHZKMNPQRSTUVWXY23456789"; //随机因子
      private  $code;     //验证码文字
      private  $codelen=4;    //验证码显示几个文字
      private  $width=115;   //验证码宽度
      private  $height=35;   //验证码高度
      private  $img;       //验证码资源句柄
      private  $font;     //指定的字体
      private  $fontsize=25;  //指定的字体大小
      private  $fontcolor;     //字体颜色  随机
      private  $line_num=10; //图像中的干扰线
      private  $snow_num=20; //干扰雪花数
      private  $font_text = false;
      private  $arithmetic = false;
      private  $arithmetic_result = null;
      //构造类  编写字体
      
      public  function __construct(){
         $this->font= LIBRARY_DIR .'/XbLib/Font/elephant.ttf';
      }
      /**
       * 使用文字验证码
       */
      public function setCodeText(){
          $this->font_text = true;
          $this->codelen = 2;
          $this->fontsize = 15;
          $this->line_num = 12;
          $this->font= LIBRARY_DIR .'/XbLib/Font/wqy-zenhei.ttc';
      }
      /**
       * 使用算术验证码
       */
      public function setArithmetic(){
          $this->arithmetic = true;
          $this->codelen = 3;
          $this->line_num = 10;
      }
      
      //创建4个英文随机码
      private function createCode(){
         $_leng=strlen($this->charset)-1;
         for($i=1;$i<=$this->codelen;$i++){
            $this->code.=$this->charset[mt_rand(0,$_leng)];
         }
         return $this->code;
      }
      //创建两个中文随机码
      private function createCodeText(){
         $str = preg_split('/(?<!^)(?!$)/u', $this->charset_text);
         shuffle($str);
         $str = array_slice($str, 0,2);
         $this->code = implode('', $str);
         return $this->code;
      }
      //创建一道算术题
      private function createArithmetic(){

         //随机一个左运算数
         $left_number = rand(1, 10);
         //随机一个右运算数
         $right_number = rand(1, 10);
         //随机一个运算符
         $key = array_rand($this->charset_arithmetic);
         $operator = $this->charset_arithmetic[$key];
         $this->code[] = $left_number;
         $this->code[] = $key;
         $this->code[] = $right_number;
         $this->arithmetic_result = $left_number . $operator . $right_number;
         $this->arithmetic_result = eval("return $this->arithmetic_result;");
         return $this->code;
      }
      //创建背景
      private function createBg(){
         //创建画布 给一个资源jubing
         $this->img=imagecreatetruecolor($this->width,$this->height);
         //背景颜色
         //$color=imagecolorallocate($this->img,mt_rand(200,255),mt_rand(200,255),mt_rand(200,255));
         $color=imagecolorallocate($this->img,221,221,221);
         //画出一个矩形
         imagefilledrectangle($this->img,0,$this->height,$this->width,0,$color);
      }
    
      //创建字体
      private  function createFont(){
         $_x=(($this->width-30) / $this->codelen);   //字体长度
         if($this->font_text === true){
          $this->code = preg_split('/(?<!^)(?!$)/u', $this->code);
         }
         for ($i=0;$i<$this->codelen;$i++){
            //文字颜色
            $color=imagecolorallocate($this->img,40,80,160);
            //资源句柄 字体大小 倾斜度 字体长度  字体高度  字体颜色  字体  具体文本
            imagettftext($this->img,$this->fontsize,0,$_x*$i+15,$this->height/1.4,$color,$this->font,$this->code[$i]);
         }
       }
       
      //随机线条
      private function createLine(){
         //随机线条
         for ($i=0;$i<$this->line_num;$i++){
            $color = imagecolorallocate($this->img,mt_rand(0,156),mt_rand(0,156),mt_rand(0,156));
            imageline($this->img,mt_rand(0,$this->width),mt_rand(0,$this->height),mt_rand(0,$this->width),mt_rand(0,$this->height),$color);

         }
         //随机雪花
         for ($i=0;$i<$this->snow_num;$i++){
           $color = imagecolorallocate($this->img,mt_rand(220,255),mt_rand(220,255),mt_rand(220,255));
           imagestring($this->img,mt_rand(1,5),mt_rand(0,$this->width),mt_rand(0,$this->height),'*',$color);
         }
      }
      
      //输出背景
      public  function outputImg(){
         //生成标头
         header('Content-Type:image/png');
         //输出图片
         imagepng($this->img);
         //销毁结果集
         imagedestroy($this->img);
      }
      
      //对外输出
      public  function createImg(){
         //加载背景
         $this->createBg();
         //加载文件
         if($this->font_text === true){
          $this->createCodeText();
         }else if($this->arithmetic === true){
          $this->createArithmetic();
         }else{
          $this->createCode();
         }
         //加载线条
         $this->createLine();
         //加载字体
         $this->createFont();
      }
      
      public function getBase64Image() {
          ob_start();
          imagepng($this->img);
          $imageData = ob_get_clean();
          return 'data:image/png;base64,' . base64_encode($imageData);
      }
     
      //获取验证码
      public  function getCode(){
        if($this->font_text === true){
          return implode('', $this->code);
        }
        if($this->arithmetic === true){
          return $this->arithmetic_result;
        }
         return strtolower($this->code);
      }
/*****************************************新的使用方法*************************************************/
    /**
     *  获取图片验证码
     * @return string
     */
    public function outputBase64($mobile){
        ob_start();
        imagepng ($this->img);
        $imageData = ob_get_contents ();
        ob_end_clean ();
        $code = $this->getCode();
        $key = md5($code . $mobile);
        TyFunc_Cachefunc::getInstance()->set($key, $code, 120);
        return array(
            'key'   => $key,
            'img'   => 'data:image/png;base64,' . base64_encode ($imageData)
        );
    }



}


<?php

abstract class AbstractEvent
{
    private $_name;
    
    private $_caller;
    
    private $_data = array();
    
    public function __construct($sName, $oCaller, array $aData = array())
    {
        $this->_name = $sName;
        $this->_caller = $oCaller;
        $this->_data = $aData;
    }
    
    public function getName()
    {
        return $this->_name;
    }
    
    public function getCaller()
    {
        return $this->_caller;
    }
    
    public function set($sKey, $mVal)
    {
        $this->_data[$sKey] = $mVal;
    }
    
    public function get($sKey, $sDefault = null)
    {
        if (array_key_exists($sKey, $this->_data))
            return $this->_data[$sKey];
        else
            return $sDefault;
    }
    
    /**
     * 验证数据等初始化操作，如返回false，则此事件不会被处理
     * 
     * @return boolean
     */
    public function init()
    {
        //验证数据等
        return true;
    }
}
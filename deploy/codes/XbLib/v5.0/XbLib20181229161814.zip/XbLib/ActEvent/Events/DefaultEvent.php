<?php

class DefaultEvent extends AbstractEvent
{
    
}
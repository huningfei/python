<?php

class AbstractListener
{
    protected function callApi($cmd, $data) {
        $url = 'http://127.0.0.1:9501';
        $params = [
            'cmd' => $cmd,
            'data' => $data
        ];
        
        $res = XbLib_Function::getInstance()->dfopen($url, 0, http_build_query($params), '', FALSE, '', 3);
        
        return $res;
    }
}
<?php

return [
    //比较类型
    'op' => [
        'gt' => '大于',
        'egt' => '大于等于',
        'lt' => '小于',
        'elt' => '小于等于',
        'eq' => '等于',
        'range' => '介于',
        'in' => '包括',
    ],
    
    //数据类型
    'type' => [
        'datetime', 'string', 'int', 'float'
    ],
    
    
    
    //事件监测规则（可增加，尽量不要删除或修改）
    //！！在每个 option_list 下 target 和 target_attr 是联合唯一！！
    'event_check_rule' => [
        1 => [
            'id' => 1,
            'name' => '收款业务',
            //触发事件token
            'event_token' => 'after_withdraw',
            //可支持的规则
            'option_list' => [
                //首次收款时间限制
                [
                    //规则对象
                    'target' => 'user',
                    //参与比较的属性
                    'target_attr' => 'first_withdraw_date',
                    //参与比较的属性名称
                    'target_attr_name' => '首次收款时间',
                    //数据类型
                    'target_type' => 'datetime',
                    //比较选项
                    'op' => 'gt|egt|lt|elt|eq|range'
                ],
                //累计参与活动次数限制
                [
                    //规则对象
                    'target' => 'user',
                    //参与比较的属性
                    'target_attr' => 'activity_join_times',
                    //参与比较的属性名称
                    'target_attr_name' => '累计收款次数',
                    //数据类型
                    'target_type' => 'int',
                    //比较选项
                    'op' => 'elt'
                ],
                //单笔免手续费的最大金额
                [
                    //规则对象
                    'target' => 'order',
                    //参与比较的属性
                    'target_attr' => 'max_free_for_withdraw',
                    //参与比较的属性名称（最多减免的金额）
                    'target_attr_name' => '免费收款金额限制',
                    //数据类型
                    'target_type' => 'int',
                    //比较选项
                    'op' => 'elt'
                ],
            ]
        ],
        2 => [
            'id' => 2,
            'name' => '申请信用卡业务',
            'event_token' => 'after_upload_creditcard_apply',
            'option_list' => [
                //申请时间
                [
                    //规则对象
                    'target' => 'users_apply_bank',
                    //参与比较的属性
                    'target_attr' => 'apply_time',
                    //参与比较的属性名称
                    'target_attr_name' => '申请信用卡时间',
                    //数据类型
                    'target_type' => 'datetime',
                    //比较选项
                    'op' => 'gt|egt|lt|elt|eq|range'
                ],
                //申请信用卡状态
                [
                    //规则对象
                    'target' => 'users_apply_bank',
                    //参与比较的属性
                    'target_attr' => 'status',
                    //参与比较的属性名称
                    'target_attr_name' => '申请信用卡状态',
                    //数据类型
                    'target_type' => 'string',
                    //比较选项
                    'op' => 'in',
                    //选线
                    'options' => [
                        '待确认' => '待确认',
                        '待结算' => '待结算',
                        '已结算' => '已结算'
                    ]
                ],
                //申请银行
                [
                    //规则对象
                    'target' => 'users_apply_bank',
                    //参与比较的属性
                    'target_attr' => 'bank',
                    //参与比较的属性名称
                    'target_attr_name' => '申请银行',
                    //数据类型
                    'target_type' => 'string',
                    //比较选项
                    'op' => 'in',
                    //选线
                    'options' => [
                        '交通银行' => '交通银行',
                        '兴业银行' => '兴业银行',
                        '民生银行' => '民生银行',
                        '浦发银行' => '浦发银行',
                        '招商银行' => '招商银行',
                        '华夏银行' => '华夏银行',
                        '广州银行' => '广州银行',
                        '上海银行' => '上海银行',
                        '建设银行' => '建设银行',
                        '中国银行' => '中国银行',
                        '平安银行' => '平安银行'
                    ]
                ],
                //重复订单id最多计算一次，程序里写死，不再编辑
                /*
                [
                    //规则对象
                    'target' => 'users_apply_bank',
                    //参与比较的属性
                    'target_attr' => 'bank_is_applied',
                    //参与比较的属性名称
                    'target_attr_name' => '重复订单id不计算',
                    //数据类型
                    'target_type' => 'string',
                    //比较选项
                    'op' => 'eq',
                    'value' => 0
                    //选线
                    'options' => [
                        '0' => '是',
                    ]
                ],
                */
            ]
        ]
    ]
];
<?php

class XbLib_ActEvent_CommonEvent
{
    /**
     * 用户取现后
     * 
     * @var string
     */
    const AFTER_WITHDRAW = 'after_withdraw';
    
    /**
     * 上传用户信用卡申请资料后
     * 
     * @var string
     */
    const AFTER_UPLOAD_CREDITCARD_APPLY = 'after_upload_creditcard_apply';
    
    /**
     * 后台上传包含用户注册资料的excel文件后
     * 
     * @var string
     */
    const AFTER_UPLOAD_CREDITCARD_APPLY_EXCEL = 'after_upload_creditcard_apply_excel';
}
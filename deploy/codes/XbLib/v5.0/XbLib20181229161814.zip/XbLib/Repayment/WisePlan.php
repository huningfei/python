<?php
/**
 * @desc    还款通道调用
 * @author  qien
 * @date    18.04.13
 */
class XbLib_Repayment_WisePlan{
    private static $obj;
    private $totalAmount;
    public static $dayTime = 8;
    public static $hour    = 20;
    private $timeError;
    private static $factorType = array(
        1 => array('avgMin' => 300,   'avgMax' => 500,   'diffMin' => 1,   'diffMax' => 50),
        2 => array('avgMin' => 501,   'avgMax' => 2000,  'diffMin' => 1,   'diffMax' => 100),
        3 => array('avgMin' => 2001,  'avgMax' => 5000,  'diffMin' => 50,  'diffMax' => 200),
        4 => array('avgMin' => 5001,  'avgMax' => 10000, 'diffMin' => 100, 'diffMax' => 300),
        5 => array('avgMin' => 10001, 'avgMax' => 15000, 'diffMin' => 200, 'diffMax' => 400),
        6 => array('avgMin' => 15001, 'avgMax' => 20000, 'diffMin' => 300, 'diffMax' => 500)
    );

    /**
     * @desc    单例
     */
    public static function getInstance(){
        if (empty(self::$obj)) {
            self::$obj = new XbLib_Repayment_WisePlan();
        }
        return self::$obj;
    }

    /**
     * @desc    制定计划主入口
     * @param   int     $uid            用户id
     * @param   int     $amount         还款金额
     * @param   int     $cardInfo       信用卡id
     * @param   int     $mch_id         商户id
     * @param   int     $customAmount   自定义还款金额
     * @return  array   $return         返回计划详情
     */
    public function makePlan($uid, $amount, $cardInfo, $mch_id, $customAmount=0){
        $level = XbModule_Account_UsersLevel::getInstance()->getUserLevelByUid($uid);
        $channelLevelInfo = XbModule_Repayment_Channel::getInstance()->getChannelByLevel($level['level']);

        if($customAmount > 0){
            $time = $this->getCustomTime($amount, $customAmount);
            $type = 2;
        }else{
            $time = $this->getTime($amount);
            $type = 1;
        }
        //var_dump($time);exit;
        if($amount < 300 || $amount > 1000000){
            return new XbLib_WebError(4505);
        }

        //判断日期是否符合，同时或得距离还款日天数
        $checkDate = XbLib_Verify::checkDate($cardInfo['billDate'], $cardInfo['payDate']);
        if(!$checkDate){
            return new XbLib_WebError(4506);
        }
        //var_dump($checkDate);exit;
        $res = array();
        foreach($time as $v){
            $planDetail = array();
            $avg     = $this->getAvg($amount, $v, $channelLevelInfo['fee'], $channelLevelInfo['rate']);
            $factors = $this->getRandFactor($uid, $avg);

            $planDate   = $this->getPlanDate($checkDate, $cardInfo['billDate'], $cardInfo['payDate'], $v);
            if(!$planDate) continue;
            if($type == 2){
                $factors[0] = bcsub($customAmount, ceil($avg));
            }
            $planAmount = $this->getPlanAmount($avg, $factors, $v);
            if(!$planAmount) continue;

            $planDetail['planInfo'] = $this->getPlanDetail($v, $planDate, $planAmount);
            if(!$planDetail) continue;
            $planDetail['orderId']  = XbModule_Repayment_OrderPlan::getInstance($mch_id)->createOrderTmp($uid, $cardInfo['id'], $amount, $v, $this->totalAmount, $channelLevelInfo['fee'], $channelLevelInfo['rate'], $planDetail['planInfo'], $type);
            $planDetail['planInfo'] = array_values($planDetail['planInfo']);
            $planDetail['rate']     = $channelLevelInfo['rate'];
            $planDetail['fee']      = $channelLevelInfo['fee'];
            $planDetail['totalAmount'] = $this->totalAmount;
            $res[] = $planDetail;
        }
        //var_dump($res);exit;
        if(count($res) < 1){
            return $this->returnError();
        }
        return $res;
    }

    /**
     * @desc    获取自定义金额还款次数
     */
    public function getCustomTime($amount, $customAmount){
        $typeInfo = $this->getFactorType($customAmount);
        $time = ceil($amount/($customAmount - self::$factorType[$typeInfo]['diffMax']));
        return array($time);
    }

    /**
     * @desc    组装还款计划
     */
    public function getPlanDetail($time, $planDate, $planAmount){
        for($i = 0; $i < $time; $i++){
            if(!$planDate[$i] || !$planAmount[$i]){
                return false;
            }
            $res[] = array(
                'time'   => $i+1,
                'date'   => $planDate[$i],
                'amount' => $planAmount[$i],
            );
        }
        return $res;
    }

    /**
     * @desc    制定计划还款日期
     */
    public function getPlanDate($checkDate, $billDate, $payDate, $time){
        $day = date('d');
        //获取今日还能执行多少次
        $todayTime = self::getTodayTime();
        //计算从今天开始一共可以执行多少次还款
        $totalTime = ($checkDate - 1)*self::$dayTime + $todayTime;
        //var_dump($totalTime);exit;
        if($totalTime < $time){
            if(!$this->timeError) $this->timeError = new XbLib_WebError(4507);
            return false;
        }
        $avg = ceil($time/$checkDate);
        if($avg > self::$dayTime){
            if(!$this->timeError) $this->timeError = new XbLib_WebError(4507);
            return false;
        }

        //判断今天执行的次数是否小于平均数，如果小于，从新计算平拘束
        if($avg > $todayTime){
            $firstTime = ($todayTime > 0) ? $todayTime : 0;
            $avg = ceil(($time - $todayTime)/($checkDate - 1));
        }else{
            $firstTime = $avg;
        }
        //var_dump($firstTime, $avg);exit;
        $timeStop = $firstTime;
        $mouth    = date('m');
        $mouthDay = date('t');
        //$hour     = date('H', strtotime('+5 i'))+1;
        $hour     = date('H')+1;
        $hour     = $hour < 9 ? '09' : $hour;
        $startTime = 0;
        for($i = 0; $i < $time; $i++ ){
            //echo $i.'---';echo $timeStop.'----';
            if($i == $timeStop || ($i == 0 && $todayTime <= 0)){
                //echo '111-----';
                $timeStop += $avg;
                $day += 1;
                //if($todayTime <= 0) $day += 1;
                if($day > $mouthDay){
                    $mouth += 1;
                    $day = 1;
                }
                $startTime = strtotime(date('Y-'.$mouth.'-'.$day.' 09:00:00'));
            }elseif($i == 0){
                $min = '00';
                $h0 = date('H');
                $h1 = date('H', time()+180);
                if($h0 != $h1) $min = '30';
                $startTime = strtotime(date('Y-'.$mouth.'-'.$day.' '.$hour.':'.$min.':00'));
            }else{
                $startTime += '1800';
            }
            //if($timeStop == $time) continue;
            $res[] = $startTime;
            //$res[] = $startTime;

        }
        //exit;
        return $res;
        /*var_dump($avg, $time, $checkDate);exit;
        return $plandate;*/
    }

    /**
     * @desc    根据次数制定计划
     */
    public function getPlanAmount($avg, $factors, $time){
        $avg = ceil($avg); //取整
        $surplus     = $time;
        $transNum    = floor(bcdiv($time,2));
        $totalAmount = '0';
        $res = array();
        $totalAmountFormat = number_format($this->totalAmount, 0, '.', '');
        $extend = bcsub($this->totalAmount, $totalAmountFormat);
        /*生成每次需要还的金额*/
        for($i = 0; $i < $time; $i++){
            $index = $i;
            if($surplus == 1){
                /*处理最后一次*/
                $singleAmount = bcsub($totalAmountFormat, $totalAmount);
                $range        = bcmul($time, '0.01');
                $singleAmount = bcadd($singleAmount, $range);
            }elseif($i < $transNum){
                /*处理前半部分期数还款金额*/
                $singleAmount = bcadd($avg, $factors[$index]);
            }else{
                /*处理后半部分期数还款金额*/
                $index = $i - $transNum;
                $singleAmount = bcsub($avg, $factors[$index]);
            }
            $res[] = $singleAmount;
            $totalAmount = bcadd($totalAmount, $singleAmount);
            $surplus--;
        }
        /*大小排序，并在最小的数字加上小数*/
        sort($res);
        $res[0] = bcadd($res[0], $extend);
        return array_reverse($res);
    }

    public function getAvg($amount, $time, $fee, $rate){
        $feeAmount   = bcadd(bcmul($fee, $time), $amount);
        $rateDiv     = bcsub('1', $rate, 4);
        $totalAmount = bcdiv($feeAmount, $rateDiv, 4);
        $avg = bcdiv($totalAmount, $time, 4);
        $format = number_format($avg, 2, '.', '');
        if(bccomp($avg, $format) > 0){
            $format = bcadd($avg, '0.01', 2);
        }
        $this->totalAmount = bcmul($format, $time, 2);
        return $format;
    }

    public function getTime($amount){
        switch($amount){
            case $amount <= 1000 :
                $time = array(1);
                break;
            case $amount <= 1500 :
                $time = array(1,2);
                break;
            case $amount <= 5000 :
                $time = array(1,2,3);
                break;
            case $amount <= 6500 :
                $time = array(3,6,9);
                break;
            case $amount <= 50000 :
                $time = array(9,12,15);
                break;
            case $amount <= 200000 :
                $time = array(15,18,21);
                break;
            case $amount <= 300000 :
                $time = array(25,30,35);
                break;
            case $amount <= 500000 :
                $time = array(40,45,50);
                break;
            case $amount <= 700000 :
                $time = array(55,60,65);
                break;
            case $amount <= 1000000 :
                $time = array(70,75,80);
                break;
            default:
                $time = array();
                break;
        }
        return $time;
    }

    /**
     * @desc    获取随机因子，如果没有，则生成
     */
    public function getRandFactor($uid, $avg){
        $type = $this->getFactorType($avg);
        $res  = XbModule_Repayment_UsersFactor::getInstance()->getUsersFactor($uid, $type);
        if(!$res){
            $factor    = $this->makeFactor($type);
            $factorStr = implode(',', $factor);
            $create = XbModule_Repayment_UsersFactor::getInstance()->createFactor($uid, $type, $factorStr);
            if(!$create) return false;
        }
        return $res ? explode(',', $res['factor']) : $factor;
    }

    /**
     * @desc    获取随机因子类型
     */
    public function getFactorType($avg){
        $type = 0;
        foreach(self::$factorType as $k=>$v){
            if(bccomp($avg, $v['avgMin'],  2) >= 0 && bccomp($avg, $v['avgMax'],  2) <= 0){
                $type = $k;
                break;
            }
        }
        return $type;
    }

    /**
     * @desc    获取随机因子
     */
    public function makeFactor($type){
        $res = array();
        $num = 100;
        $factorType = self::$factorType[$type];
        for($i = 0; $i < $num; $i++ ){
            $res[] = rand($factorType['diffMin'], $factorType['diffMax']);
        }
        return $res;
    }

    /**
     * @desc    获取今天还能还多少次
     */
    public static function getTodayTime(){
        $h = strtotime(date('Y-m-d 20:00:00'));
        $time = floor(($h - time() - 180)/1800);
        return $time;
    }

    /**
     * @desc    返回错误
     */
    public function returnError(){
        if($this->timeError){
            return $this->timeError;
        }
        return false;
    }
}
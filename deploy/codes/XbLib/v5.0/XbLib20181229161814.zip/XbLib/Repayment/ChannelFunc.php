<?php
/**
 * @desc    还款通道调用
 * @author  qien
 * @date    18.04.27
 */
class XbLib_Repayment_ChannelFunc{

    /**
     * @desc    计算一键还款手续费
     */
    public static function getCommonFee($rate, $amount, $signle_fee){
        $amount     = bcadd($signle_fee, $amount);
        $div        = bcsub(1, $rate, 4);
        $fee        = bcdiv($amount, $div, 4);
        $fee_format = bcmul($fee, '1', 2);
        if(bccomp($fee_format, $fee, 4) < 0){
            $fee_format = bcadd($fee_format, '0.01', 2);
        }
        return $fee_format;
    }

    /**
     * @desc    计算智能还款体现手续费
     */
    public static function getWithdrawAmount($amount, $rate, $signle_fee){
        $feeAmount        = bcmul($amount, $rate, 4);
        $feeAmount_format = number_format($feeAmount, 2, '.', '');
        if(bccomp($feeAmount_format, $feeAmount, 4) < 0){
            $feeAmount_format = bcadd($feeAmount_format, '0.01', 2);
        }
        return bcadd($feeAmount_format, $signle_fee, 2);
    }

    /**
     * @desc    获取账单日/还款日，type:1.账单日 2.还款日
     */
    public static function getCreditCardDate($day, $type){
        $d = date('d');
        if($type == 1){
            if($d < $day){
                $mouth = date('m') - 1;
            }else{
                $mouth = date('m');
            }
        }elseif($type == 2){
            if($d <= $day){
                $mouth = date('m');
            }else{
                $mouth = date('m') + 1;
            }
        }else{
            return false;
        }
        return date('Y-'.$mouth.'-'.$day);
    }
}
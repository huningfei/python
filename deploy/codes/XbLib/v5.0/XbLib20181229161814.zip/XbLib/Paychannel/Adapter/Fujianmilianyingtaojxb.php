<?php

/**
 * 福建米联通道对接
 *
 *
 */
class XbLib_Paychannel_Adapter_Fujianmilianyingtaojxb extends XbLib_Paychannel_Adapter_Fujianmilian
{
    public static $obj;
    public $bus_code = '3001';

    public function __construct($config){
        parent::__construct($config);
    }

    public static function getInstance($config){
        if (empty(self::$obj)) {
            self::$obj = new self($config);
        }
        return self::$obj;
    }
}
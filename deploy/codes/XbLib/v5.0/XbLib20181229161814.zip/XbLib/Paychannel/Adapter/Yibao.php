<?php

/**
 * @desc    易宝通道对接
 * @author  qien
 * @date    18.03.19
 */
class XbLib_Paychannel_Adapter_Yibao extends XbLib_Paychannel_Abstract implements XbLib_Paychannel_Interface{
    private $account;       //通道账户
    private $signKey;       //签名加密key
    private $url;           //访问域名
    private $hmac;          //签名值
    private $data;          //需要传输数据
    private $error;         //返回的错误
    private $callBackUrl ='https://api.xiaobaijinfu.com/synorder/callBackField';   //订单回调地址
    private $webCallBackUrl ='https://www.xiaobaijinfu.com/profile/userprofile';   //支付成功页面回调地址
    private $WithDrawCallBackUrl = 'https://api.xiaobaijinfu.com/synorder/callBackSettlement';
    private $channel_tag;   //支付类型，1：有积分，2：无积分
    public  static $obj;
    protected $bank = array(   //支持储蓄卡银行
        'ICBC'    => '工商银行',
        'ABC'     => '农业银行',
        'CMB'     => '招商银行',
        'CCB'     => '建设银行',
        'COMM'    => '交通银行',
        'CITIC'   => '中信银行',
        'CEB'     => '光大银行',
        'BJBANK'  => '北京银行',
        'SPABANK' => '深圳发展银行',
        'BOC'     => '中国银行',
        'CIB'     => '兴业银行',
        'CMBC'    => '民生银行',
        'HXBANK'  => '华夏银行'
    );

    public function __construct($config){
        $this->url     = $config['url'];
        $this->signKey = $config['key'];
        $this->account = $config['appId'];
    }

    public static function getInstance($config){
        if (empty(self::$obj)) {
            self::$obj = new XbLib_Paychannel_Adapter_Yibao($config);
        }
        return self::$obj;
    }

    /**
     * @desc    签名加密
     * @param   string  $dataStr    签名字符串
     * @return  string  $return     返回签名后的字符串
     */
    function sign($dataStr){
        $key = $this->signKey;
        $bit = 64;
        if(strlen($key) > $bit){
            $key = pack("H*", md5($key));
        }
        $key    = str_pad($key, $bit, chr(0x00));
        $ipad   = str_pad('', $bit, chr(0x36));
        $opad   = str_pad('', $bit, chr(0x5c));
        $k_ipad = $key ^ $ipad;
        $k_opad = $key ^ $opad;
        return md5($k_opad . pack("H*",md5($k_ipad . $dataStr)));
    }

    /**
     * @desc    签名解密
     * @param   string      $sStr       密文
     * @return  string      $return     返回解密信息
     */
    private  function decrypt($sStr) {
        $sKey = $this->signKey;
        if(strlen($sKey) > 16) $sKey = substr($sKey, 0, 16);
        $decrypted = mcrypt_decrypt(
            MCRYPT_RIJNDAEL_128,
            $sKey,
            $this->hexToStr($sStr),
            MCRYPT_MODE_ECB
        );

        $dec_s     = strlen($decrypted);
        $padding   = ord($decrypted[$dec_s-1]);
        $decrypted = substr($decrypted, 0, -$padding);
        return $decrypted;
    }

    /**
     * 十六进行转化成字符串
     * @param string $hex
     * @return string
     */
    function hexToStr($hex=""){
        $string="";
        for($i=0; $i<strlen($hex)-1; $i+=2) $string .= chr(hexdec($hex[$i].$hex[$i+1]));
        return  $string;
    }

    /**
     * @desc    处理加密数据，返回需要加密的字符串
     * @param   array   $data   发送数据
     * @return  string  $return 返回需要加密的字符串
     */
    public function buildSignStr($data){
        $dataStr = '';
        if(count($data) > 0){
            foreach($data as $v){
                if(gettype($v) != 'string') continue;
                $dataStr .= $v;
            }
        }
        return $dataStr;
    }

    /**
     * @desc    验证加密
     * @param   array   $data
     * @param   string  $sign
     */
    function checkSign($data, $sign){

    }

    /**
     * @desc    组装加密参数
     * @param   int     $data           需要加密的数据
     * @param   boolen  $isCheckSign    是否是检验加密
     * @return  obejct  $return         返回本类
     */
    function buildSignData($data, $isCheckSign = false){
        $this->data   = $data;
        return $this;
    }

    /**
     * @desc    注册用户接口
     */
    function signUp(){
        $bankName = $this->bank[$this->data['bankCardCode']];
        $data = array(
            'mainCustomerNumber' => $this->account,
            'requestId'          => 'xiaobai_'.$this->data['phone'],    //标识
            'customerType'       => 'PERSON',                           //默认个人
            'bindMobile'         => $this->data['phone'],
            'signedName'         => $this->data['realname'],
            'linkMan'            => $this->data['realname'],
            'idCard'             => $this->data['idcardNumber'],
            'legalPerson'        => $this->data['realname'],
            'minSettleAmount'    => '1',                                //起结金额
            'riskReserveDay'     => '0',                                //开通T0，T1结算周期
            'bankAccountNumber'  => $this->data['bankcardNumber'],
            'bankName'           => $bankName,
            'accountName'        => $this->data['realname'],
            'areaCode'           => '1000',
            'manualSettle'       => 'Y'
        );

        $data['bankCardPhoto']   = new CURLFile(realpath($this->data['bankcardImage1']['path']), 'image/jpeg', $this->data['bankcardImage1']['fileName']);
        $data['idCardPhoto']     = new CURLFile(realpath($this->data['idcardImage1']['path']), 'image/jpeg', $this->data['idcardImage1']['fileName']);
        $data['idCardBackPhoto'] = new CURLFile(realpath($this->data['idcardImage2']['path']), 'image/jpeg', $this->data['idcardImage2']['fileName']);
        $data['personPhoto']     = new CURLFile(realpath($this->data['bankcardImage2']['path']), 'image/jpeg', $this->data['bankcardImage2']['fileName']);
        $data['hmac'] = $this->sign($this->buildSignStr($data));
        $url = $this->url.'register.action';
        $res = XbLib_CurlHttp::postNew($url, $data);
        $checkRes = $this->checkError($res, $data);
        if($checkRes){
            $data['channel_code'] = $res['customerNumber'];
            $success_data['channel_code'] = $res['customerNumber'];
            $this->buildSignData($data)->sendUserStatus();
        } else {
            $error_data['code'] = $res['code'];
            $error_data['message'] = $res['message'];
        }
        return $checkRes ? $success_data : $error_data;
    }
    
    /**
     * 修改结算银行卡信息，同步修改账号绑定的手机和银行卡预留手机
     * 
     * {@inheritDoc}
     * @see XbLib_Paychannel_Interface::updateUserBankAccount()
     * @return array [ code => 错误编号 0 成功 其它失败 msg => 错误信息 ]
     */
    public function updateUserBankAccount($updateUserPhone = false) {
        //修改绑定手机 
        if ($updateUserPhone) {
            $data = array(
                'mainCustomerNumber' => $this->account,
                'customerNumber'     => $this->data['channel_code'],    //用户通道标识
            );
            
            $data['bindMobile']     = $this->data['phone'];
            $data['hmac'] = $this->sign($this->buildSignStr($data));
            $data['modifyType'] = 6;
            
            $url = $this->url.'customerInforUpdate.action';
            
            $res = XbLib_CurlHttp::postNew($url, $data);
            $checkRes = $this->checkError($res, $data);
            
            if (!$checkRes) {
                return ['code' => 1, 'msg' => '修改用户基本信息失败：' .$res['messages']];
            }
        }
        
        //修改银行卡
        $data = array(
            'mainCustomerNumber' => $this->account,
            'customerNumber'     => $this->data['channel_code'],    //用户通道标识
        );
        
        $bankName               = $this->bank[$this->data['bankCardCode']];
        $data['bankCardNumber'] = $this->data['bankcardNumber'];
        $data['bankName']       = $bankName;
        $data['hmac'] = $this->sign($this->buildSignStr($data));
        $data['modifyType'] = 2;
        
        $url = $this->url.'customerInforUpdate.action';
        
        $res = XbLib_CurlHttp::postNew($url, $data);
        $checkRes = $this->checkError($res, $data);
        
        if (!$checkRes) {
            return ['code' => 1, 'msg' => '修改储蓄卡信息失败：' .$res['message']];
        }
        
        return ['code' => 0, 'msg' => 'success'];
    }

    /**
     * @desc    更改用户信息接口
     */
    function updateUserInfo(){
        $data = array(
            'mainCustomerNumber' => $this->account,
            'customerNumber'     => $this->data['channel_code'],    //用户通道标识
        );
        if($this->data['type'] == 2){
            $bankName               = $this->bank[$this->data['bankCardCode']];
            $data['bankCardNumber'] = $this->data['bankcardNumber'];
            $data['bankName']       = $bankName;
        }elseif($this->data['type'] == 3){
            $data['riskReserveDay'] = $this->data['riskReserveDay'];    //结算周期
            $data['manualSettle']   = $this->data['manualSettle'];      //是否自助结算
        }elseif($this->data['type'] == 6){
            $data['bindMobile']     = $this->data['phone'];    //结算周期
        }
        $url = $this->url.'customerInforUpdate.action';
        $data['hmac'] = $this->sign($this->buildSignStr($data));
        $data['modifyType'] = $this->data['type'];
        $res = XbLib_CurlHttp::postNew($url, $data);
        $checkRes = $this->checkError($res, $data);
        return $checkRes ? $res : false;
    }

    /**
     * @desc    发送用户审核状态
     */
    public function sendUserStatus($status = 'SUCCESS'){
        $data = array(
            'customerNumber'     => $this->data['channel_code'],    //用户通道标识
            'mainCustomerNumber' => $this->account,
            'status'             => 'SUCCESS'                         //修改类型
        );
        $url = $this->url.'auditMerchant.action';
        $data['hmac'] = $this->sign($this->buildSignStr($data));
        $res = XbLib_CurlHttp::postNew($url, $data);
        $checkRes = $this->checkError($res, $data);
        if($checkRes){
            $status = 1;
            $reason = '';
            if($res['status'] == 'SUCCESS') $status = 3;
            if(isset($res['reason'])) $reason = $res['reason'];
            return array('status' => $status, 'msg' => $reason);
        }
        return false;
    }

    /**
     * @desc    检查，校对用户审核状态
     */
    public function auditUserStatus(){
        $res = $this->getUserData();
        return $res ? array('status' => $res['retList'][0]['auditStatus'], 'msg' =>$res['retList'][0]['auditMessage']) : $res;
    }

    /**
     * @desc    设置限额
     */
    public function setUsersTradeLimit(){
        $data = array(
            'customerNumber'      => $this->data['channel_code'],
            'mainCustomerNumber'  => $this->account,
            'bankCardType'        => 'CREDIT',
            //'bankCardNo'          => $this->data['creditcardNumber'],
            'tradeLimitConfigKey' => '1',
            'singleAmount'        => (int)$this->data['maxnum_charge'],
            'dayAmount'           => (int)$this->data['channel_day_max_charge'],
            'monthAmount'         => '500000',
            'dayCount'            => '100',
            'monthCount'          => '3000'
        );
        $url = $this->url.'tradeLimitSet.action';
        $data['hmac'] = $this->sign($this->buildSignStr($data));
        $res = XbLib_CurlHttp::postNew($url, $data);
        $checkRes = $this->checkError($res, $data);
        return $checkRes ? $res : false;
    }

    /**
     * @desc    获取用户信息
     */
    public function getUserData(){
        $data = array(   //用户通道标识
            'mainCustomerNumber' => $this->account,
            'mobilePhone'        => $this->data['phone']    //用户手机号
        );
        $url = $this->url.'customerInforQuery.action';
        $data['hmac'] = $this->sign($this->buildSignStr($data));
        $res = XbLib_CurlHttp::postNew($url, $data);
        $checkRes = $this->checkError($res, $data);
        return $checkRes ? $res : false;
    }

    /**
     * @desc    修改用户费率
     * @param   int     $type       返回
     */
    public function updateRate(){
        if($this->channel_tag == 1){
            $productType = '1';     //有积分通道
        }elseif($this->channel_tag == 2){
            $productType = '7';     //无积分通道
        }elseif($this->channel_tag == 3){
            $productType = '3';     //T0自助提现费率|XX元/笔
        }elseif($this->channel_tag == 4){
            $productType = '4';     //T0 自助结算工作日额外
            $this->data['rate'] = '0';
        }elseif($this->channel_tag == 5){
            $productType = '5';     //T0 自助结算非工作日额外
            $this->data['rate'] = '0';
        }
        $data = array(
            'customerNumber'     => $this->data['channel_code'],    //用户通道标识
            'mainCustomerNumber' => $this->account,
            'productType'        => $productType,                   //产品类型
            'rate'               =>  (string)$this->data['rate']             //修改类型
        );
        $url = $this->url.'feeSetApi.action';
        $data['hmac'] = $this->sign($this->buildSignStr($data));
        $res = XbLib_CurlHttp::postNew($url, $data);
        $checkRes = $this->checkError($res, $data);
        return $checkRes;
    }

    /**
     * @desc    发送交易-下单支付
     */
    function transaction(){
        $this->channel_tag = $this->data['channel_tag'];
        if($this->channel_tag == 1){
            $productVersion = 'STANDARD';           //有积分通道
        }elseif($this->channel_tag == 2){
            $productVersion = 'PROFESSIONAL';       //无积分通道
        }
        /*$res = $this->setUsersTradeLimit();
        if(!$res) return false;*/
        $res = $this->updateRate();
        if(!$res) return false;
        $data = array(
            'source'             => 'B',                            //卡号收款
            'mainCustomerNumber' => $this->account,
            'customerNumber'     => $this->data['channel_code'],    //用户通道标识
            'amount'             => $this->data['amount'],
            'mcc'                => '5311',
            'requestId'          => $this->data['order_id'],        //订单号
            'callBackUrl'        => $this->callBackUrl,
            'webCallBackUrl'     => $this->webCallBackUrl,
            'payerBankAccountNo' => $this->data['creditcardNumber'],//信用卡号
            //'customTradeFee'     => $this->data['fee'],             //定制手续费
            //'productVersion'     => $productVersion,                //通道类型版本
        );
        $url = $this->url.'receiveApi.action';
        $data['hmac'] = $this->sign($this->buildSignStr($data));
        //$data['customTradeFee'] = $this->data['fee'];             //暂不支持定制手续费，XX元/单笔
        $data['productVersion'] = $productVersion;
        $res = XbLib_CurlHttp::postNew($url, $data);
        $checkRes = $this->checkError($res, $data);
        if(!$checkRes) return false;
        $url = $this->decrypt($res['url']);
        return $checkRes ? array('order_id' => $res['requestId'], 'url' => $url) : false;
    }

    /**
     * @desc    结算接口
     */
    public function withdraw(){
        $this->channel_tag = $this->data['channel_tag'];
        $res = $this->updateRate();
        if(!$res){
            return false;
        }
        $res = $this->setWithdrawFee();
        if(!$res){
            return false;
        }
        $data = array(
            'amount'             => $this->data['amount'],          //结算金额
            'customerNumber'     => $this->data['channel_code'],    //用户通道标识
            'externalNo'         => $this->data['order_id'],        //结算订单号
            'mainCustomerNumber' => $this->account,
            'transferWay'        => '1',                           //结算方式，自动收款
            'callBackUrl'        => $this->WithDrawCallBackUrl,
        );
        $url = $this->url.'withDrawApi.action';
        $data['hmac'] = $this->sign($this->buildSignStr($data));
        $res = XbLib_CurlHttp::postNew($url, $data);
        $checkRes = $this->checkError($res, $data);
        return $checkRes ? $res : false;
    }

    /**
     * @desc    订单查询
     */
    public function tradeRevice(){
        $page = isset($this->data['page']) ? $this->data['page'] : '1';
        $data = array(
            'mainCustomerNumber' => $this->account,
            'customerNumber'     => $this->data['channel_code'],    //用户通道标识
            'requestId'          => $this->data['order_id'],        //结算订单号
//            'createTimeBegin'    => $this->data['startTime'],       //查询开始时间
//            'createTimeEnd'      => $this->data['endTime'],         //查询结束时间
            'payTimeBegin'    => $this->data['startTime'],       //查询开始时间
            'payTimeEnd'      => $this->data['endTime'],         //查询结束时间
            'pageNo'             => $page,
        );
        $url = $this->url.'tradeReviceQuery.action';
        $data['hmac'] = $this->sign($this->buildSignStr($data));
        $res = XbLib_CurlHttp::postNew($url, $data);
        $checkRes = $this->checkError($res, $data);
        return $checkRes ? $res : false;
    }

    /**
     * @desc    结算订单查询
     */
    public function transfer(){
        $page    = isset($this->data['page']) ? $this->data['page'] : '1';
        $orderid = isset($this->data['order_id']) ? $this->data['order_id'] : '';
        $data = array(
            'customerNumber'          => $this->data['channel_code'],    //用户通道标识
            'externalNo'              => $orderid,
            'mainCustomerNumber'      => $this->account,
            'pageNo'                  => $page,
            'requestDateSectionBegin' => $this->data['startTime'],        //结算订单号
            'requestDateSectionEnd'   => $this->data['endTime'],          //查询开始时间
            'transferWay'             => '1',                             //交易方式 T0
        );
        if($data['externalNo'] == '') unset($data['externalNo']);
        $url = $this->url.'transferQuery.action';
        $data['hmac'] = $this->sign($this->buildSignStr($data));
        $res = XbLib_CurlHttp::postNew($url, $data);
        $checkRes = $this->checkError($res, $data);
        return $checkRes ? $res : false;
    }

    /**
     * @desc    订单查询，核对
     */
    function checkOrder(){

    }

    /**
     * @desc    验证错误，记录日志
     * @param   array   $data   返回的日志文件
     * @return  boolen  $return 返回验证结果
     */
    public function checkError($res, $data){
        $retrun = true;
        if($res['code'] != '0000'){
            $log  = json_encode($res);
            $log1 = json_encode($this->data);
            $log2 = json_encode($data);
            XbFunc_Log::write('yibaoError', '返回数据错误：'.$log, '请求参数：'.$log1.',加密传输数据'.$log2);
            $this->error = $res['message'];
            $retrun = false;
        }
        else {
            // 非正式  环境下记录正确调用的日志
            $env = getenv('RUNTIME_ENVIROMENT') ? getenv('RUNTIME_ENVIROMENT') : (defined('SHELL_VARIABLE') ? SHELL_VARIABLE : '');
            $env = empty($env) ? 'local' : ($env != 'rls' ? 'local' : $env);
            if ($env != 'rls') {
                $log  = json_encode($res);
                $log1 = json_encode($this->data);
                $log2 = json_encode($data);
                XbFunc_Log::write('yibaoSucc', '返回成功数据：'.$log, '请求参数：'.$log1.',加密传输数据'.$log2);
            }
        }
        return $retrun;
    }

    /**
     * @desc    设置结算额外费率
     * @return  boolen      $return     返回设置结果
     */
    public function setWithdrawFee(){
        $this->channel_tag = 4;
        $res = $this->updateRate();
        if(!$res){
            return false;
        }
        $this->channel_tag = 5;
        $res = $this->updateRate();
        if(!$res){
            return false;
        }
        return true;
    }
}
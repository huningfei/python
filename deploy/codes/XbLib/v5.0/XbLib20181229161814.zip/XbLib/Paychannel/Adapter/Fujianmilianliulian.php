<?php

/**
 * 福建米联通道对接
 *
 *
 */
class XbLib_Paychannel_Adapter_Fujianmilianliulian extends XbLib_Paychannel_Adapter_Fujianmilian implements XbLib_Paychannel_Interface
{
    public static $obj;
    
    /**
     * 支持的信用卡银行
     * 
     * @var array
     */
    protected static $_supportedBankCode = [
        //键值为银行在小白系统中的code
        'ICBC'    => '工商银行',
        'CCB'     => '建设银行',
        'BOC'     => '中国银行',
        'CIB'     => '兴业银行',
        'CMBC'    => '民生银行',
        'SPDB'    => '浦发银行',
        'CEB'     => '光大银行',
        'SPABANK' => '平安银行',
        'PSBC'    => '邮储银行',
        'GDB'     => '广发银行',
        
        //因缺少数据不能支持的银行
        //花旗银行
    ];
    
    public function __construct($config){
        parent::__construct($config);
    }
    
    public static function getInstance($config){
        if (empty(self::$obj)) {
            self::$obj = new self($config);
        }
        return self::$obj;
    }
}
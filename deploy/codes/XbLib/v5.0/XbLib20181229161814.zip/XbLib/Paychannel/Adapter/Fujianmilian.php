<?php

/**
 * @desc    福建米联通道对接基类
 * @author  yurong
 * @date    18.04.09
 */
class XbLib_Paychannel_Adapter_Fujianmilian extends XbLib_Paychannel_Abstract implements XbLib_Paychannel_Interface
{
    private $data = null;
    private $account = null;
    private $signKey = null;
    private $merchantUrl = null;
    private $host = null;
    private $payUrl = null;

//    private $webCallBackUrl ='https://m.xiaobaijinfu.com/dist#/dist';   //支付成功页面回调地址
    private $webCallBackUrl ='https://m.xiaobaijinfu.com/Synorder/webRedirect';   //支付成功页面回调地址
//    private $webCallBackUrl ='';   //支付成功页面回调地址
    private $callBackUrl = 'https://api.xiaobaijinfu.com/synorder/callBackField';   //订单回调地址


    public function __construct($config){
        $this->merchantUrl     = $config['merchantUrl'];
        $this->host             = $config['host'];
        $this->payUrl           = $config['payUrl'];
        $this->signKey          = $config['key'];
        $this->account          = $config['appId'];
    }

    /**
     * @desc    进件签名加密
     * @param   array $dataStr 签名字符串
     */
    function sign($dataStr){
        $str = '';
        $key         = $this->signKey;
        foreach ($dataStr as $k => $v){
            $str .= $k.'='.$v.'&';
        }
        $str.='key='.$key;
        $sign        = strtoupper(md5($str));
        return $sign;
    }
    public  function getSign($data,$key){
        $str = implode('',array_values($data));
        $sign_1 = strtoupper(md5($str));
        $sign_2 = strtoupper(md5($sign_1.$key));
        $sign = substr($sign_2,8,16);
        return $sign;
    }
    /**
     * @desc    验证加密
     * @param   array $data
     * @param   string $sign
     */
    function checkSign($data, $sign){

    }

    /**
     * @desc    组装加密参数
     * @param   int $data 需要加密的数据
     * @param   boolen $isCheckSign 是否是检验加密
     */
    function buildSignData($data, $isCheckSign = false){
        $this->data = $data;
        return $this;
    }
    
    
    /**
     * 根据小白的银行编号，获取对应银行在米联系统下的银行信息
     * 
     * @param string $code 银行编号
     * @param boolean $checkIsSupportedCreditCard 是否验证是通道支持的信用卡
     * @return array
     */
    public static function getBankInfoByXiaoBaiBankCode($code, $checkIsSupportedCreditCard = false)
    {
        //当前平台不支持此信用卡
        if ($checkIsSupportedCreditCard && !isset(static::$_supportedBankCode[$code]))
        {
            return false;
        }
        
        if (!isset(XbLib_Var::$bankCode2MilianBank[$code]))
        {
            return false;
        }
        
        $info = XbLib_Var::$bankCode2MilianBank[$code];
        
        $data = [
            'settBankName' => $info['name'],
            'bankChannelNo' => $info['no'],
            'bankAbbr' => $info['abbr'],
            'bankCode' => $info['code']
        ];
        
        return $data;
    }

    /**
     * @desc    注册用户接口
     */
    function signUp(){
        if (!$this->data) return false;
        
        $milian_bank_data = static::getBankInfoByXiaoBaiBankCode($this->data['bankCardCode']);
        
        if (!$milian_bank_data)
        {
            return array('code'=>'0005','message'=>'此通道不支持该银行卡');
        }
        
        $sign_param                     = array(
            'bankAccountNo' => $this->data['bankcardNumber'],
            'debitRate' => $this->data['rate'],
            'handleType' => 'A',
            'merchName' => $this->data['realname'],
            'orderId' => $this->data['order_id'],
            'parent' => $this->account,
            'phoneNo' => $this->data['phone'],
        );
        $sign_param['sign']             = $this->sign($sign_param);
        $send_data                      = $sign_param;
        $send_data['merchAbb']          = $this->data['realname'];//商户简称
        $send_data['merchAddress']      = '北京市朝阳区';//商户所在地址
        $send_data['telNo']             = $this->data['phone'];//联系电话
        $send_data['bankAccountName']   = $this->data['realname'];//银行卡户名
        $send_data['legalPersonIdcard'] = $this->data['idcardNumber'];
        $send_data['settBankName']      = $milian_bank_data['settBankName'];
        $send_data['bankChannelNo']     = $milian_bank_data['bankChannelNo'];//银行联行号
        $send_data['bankSubName']       = $milian_bank_data['settBankName'];//支行名称
        $send_data['bankProvince']      = '北京市';//所属省份
        $send_data['bankCity']          = '北京市';//所属城市
        $send_data['bankCode']          = $milian_bank_data['bankCode'];
        $send_data['bankAbbr']          = $milian_bank_data['bankAbbr'];//银行代号
        $send_data['countFeeT0']        = $this->data['fee']*100;//代付费(单笔交易手续费）
        $send_data['futureMinAmount']   = $this->data['mininum_charge'];//保底
        $send_data['debitCapAmount']    = $this->data['maxnum_charge'];//封顶

        $this_header                    = array(
            "content-type: application/x-www-form-urlencoded;charset=UTF-8"
        );
        $url = $this->merchantUrl.'/ChannelPay/merchBaseInfo/merchInterface';
        $res                            =  $this->post($url, $send_data, $this_header);
        $checkRes                       = $this->checkError($res, $send_data);
        if ($checkRes) {
            $success_data['channel_code'] = $res['data']['merchantNo'];
            $success_data['channel_key'] = $res['data']['merchantKey'];
        } else {
            $error_data['code'] = $res['respCode'];
            $error_data['message'] = $res['respMsg'];
        }
        return $checkRes ? $success_data : $error_data;
    }

    /**
     * @desc    更改用户基本信息接口
     */
    function updateUserInfo(){
        if(!$this->data) return false;
        $sign_param = array(
            'handleType' => 'M',
            'merchName' => $this->data['realname'],
            'orderId' => $this->data['order_id'],
            'parent' => $this->account,
        );
        $send_data = $sign_param;
        $send_data['sign'] = $this->sign($sign_param);
        $send_data['changeType'] = 'M01';
        $send_data['merchId'] = $this->data['channel_code'];
        $send_data['merchAbb'] = $this->data['realname'];
        $send_data['telNo'] = $this->data['phone'];
        $send_data['email'] = $this->data['email'];
        $this_header                    = array(
            "content-type: application/x-www-form-urlencoded;charset=UTF-8"
        );
        $url = $this->merchantUrl.'/ChannelPay/merchBaseInfo/merchInterface';
        $res                            =  $this->post($url, $send_data, $this_header);
        $checkRes                       = $this->checkError($res, $send_data);
        return $checkRes ? $res : false;
    }

    /**
     * @desc    获取用户秘钥
     */
    function getUserData(){
        if(!$this->data) return false;
        $sign_param = array(
            'merchId' => $this->data['channel_code'],
            'orderId' => $this->data['order_id'],
            'parent' => $this->account,
        );
        $send_data = $sign_param;
        $send_data['sign'] = $this->sign($sign_param);
        $this_header                    = array(
            "content-type: application/x-www-form-urlencoded;charset=UTF-8"
        );
        $url = $this->merchantUrl.'/ChannelPay/merchBaseInfo/queryMerchKey';
        $res                            =  $this->post($url, $send_data, $this_header);
        $checkRes                       = $this->checkError($res, $send_data);
        return $checkRes ? $res : false;
    }
    
    /**
     * 修改结算银行卡信息，同步修改账号绑定的手机和银行卡预留手机
     * （内部会创建id）
     * 
     * {@inheritDoc}
     * @see XbLib_Paychannel_Interface::updateUserBankAccount()
     * @return array [ code => 错误编号 0 成功 其它失败 msg => 错误信息 ]
     */
    public function updateUserBankAccount($updateUserPhone = false){
        if(!$this->data) return false;
        $sign_param = array(
            'bankAccountNo' => $this->data['bankcardNumber'],
            'handleType' => 'M',
            'orderId' =>  XbModule_Account_Order::getInstance(1)->getOrderCode(),
            'parent' => $this->account,
            'phoneNo' =>$this->data['phone'],
        );
        $send_data = $sign_param;
        $send_data['sign'] = $this->sign($sign_param);
        $send_data['changeType'] = 'M02';
        $send_data['bankAccountName'] = $this->data['realname'];
        $send_data['legalPersonIdcard'] = $this->data['idcardNumber'];
        $send_data['settBankName'] = $this->data['bank'];
        $send_data['bankCardCode'] =$this->data['bankCardCode'];
        $send_data['merchId'] = $this->data['channel_code'];
        
        $send_data['bankProvince'] = '北京市';
        $send_data['bankCity'] = '北京市';
        
        $milian_bank_data = static::getBankInfoByXiaoBaiBankCode($this->data['bankCardCode']);
        $send_data['bankChannelNo']     = $milian_bank_data['bankChannelNo'];//银行联行号
        $send_data['bankSubName'] = $this->data['bank'];

        $this_header                    = array(
            "content-type: application/x-www-form-urlencoded;charset=UTF-8"
        );
        $url = $this->merchantUrl.'/ChannelPay/merchBaseInfo/merchInterface';
        $res                            =  $this->post($url, $send_data, $this_header);
        $checkRes                       = $this->checkError($res, $send_data);
        
        //储蓄卡信息编辑失败
        if (!$checkRes) {
            return ['code' => 1, 'msg' => '修改储蓄卡信息失败：' . $res['respMsg']];
        }
        
        //同步修改用户个人信息的手机号码
        //米联不支持修改用户个人信息
        /*
        if ($updateUserPhone) 
        {
            $sign_param = array(
                'handleType' => 'M',
                'merchName' => $this->data['realname'],
                'orderId' => XbModule_Account_Order::getInstance(1)->getOrderCode(),
                'parent' => $this->account,
            );
            $send_data = $sign_param;
            $send_data['sign'] = $this->sign($sign_param);
            $send_data['changeType'] = 'M01';
            $send_data['merchId'] = $this->data['channel_code'];
    
            $send_data['telNo'] = $this->data['phone'];
    
            $this_header                    = array(
                "content-type: application/x-www-form-urlencoded;charset=UTF-8"
            );
            $url = $this->merchantUrl.'/ChannelPay/merchBaseInfo/merchInterface';
            $res                            =  $this->post($url, $send_data, $this_header);
            $checkRes                       = $this->checkError($res, $send_data);
            
            //储蓄卡信息编辑失败
            if (!$checkRes) {
                return ['code' => 1, 'msg' => '修改用户基本信息失败：' .$res['respMsg']];
            }
        }
        */
        
        return ['code' => 0, 'msg' => 'success'];
    }
    
    /**
     * @desc 修改用户费率
     * */
    public function updateRate(){
        if(!$this->data) return false;
        $sign_param = array(
            'debitRate'=>$this->data['rate'],
            'handleType'=>'M',
            'orderId' => $this->data['order_id'],
            'parent' => $this->account
        );
        $send_data = $sign_param;
        $send_data['sign'] = $this->sign($sign_param);
        $send_data['changeType'] = 'M03';
        $send_data['countFeeT0'] = $this->data['fee']*100;
        $send_data['merchId'] = $this->data['channel_code'];
        $this_header                    = array(
            "content-type: application/x-www-form-urlencoded;charset=UTF-8"
        );
        $url = $this->merchantUrl.'/ChannelPay/merchBaseInfo/merchInterface';
        $res                            =  $this->post($url, $send_data, $this_header);
        $checkRes                       = $this->checkError($res, $send_data);
        return $checkRes ? true : false;
    }

    /**
     * @desc 商户秘钥查询--OK
     * */
    public function gerUserKey(){
        if(!$this->data) return false;
        $sign_param = array(
            'merchId'  => $this->data['channel_code'],
            'orderId'  => $this->data['order_id'],
            'parent'  => $this->account,
        );
        $send_data = $sign_param;
        $send_data['sign'] = $this->sign($sign_param);
        $this_header                    = array(
            "content-type: application/x-www-form-urlencoded;charset=UTF-8"
        );
        $url = $this->merchantUrl.'/ChannelPay/merchBaseInfo/queryMerchKey';
        $res                            =  $this->post($url, $send_data, $this_header);
        $checkRes                       = $this->checkError($res, $send_data);
        return $checkRes ? array('channel_code'=>$res['data']['merchantNo'],'channel_key'=>$res['data']['merchantKey']) : false;

    }
    /**
     * @desc 快捷交易
     * */
    function transaction(){
        if (!$this->data) return false;
        $res = $this->updateRate();
        if(!$res) return false;
        $bus_code = isset($this->bus_code) ? $this->bus_code : '5015';
        $sign_param            = array(
            'ORDER_ID' => $this->data['order_id'],
            'ORDER_AMT' => sprintf("%.2f", $this->data['amount']),
            'ORDER_TIME' => $this->data['time'],
            'PAY_TYPE' => '13',
            'USER_TYPE' => '02',
            'USER_ID' => $this->data['channel_code'],
            'BUS_CODE' => $bus_code,
        );
        XbFunc_Log::write('debug', json_encode($sign_param));
        $send_data             = $sign_param;
        $send_data['SIGN']     = $this->getSign($sign_param,$this->data['channel_key']);
        $send_data['SIGN_TYPE'] = '03';
        $send_data['CCT'] = 'CNY';
        $send_data['BG_URL'] = $this->callBackUrl;
        $send_data['PAGE_URL'] = $this->webCallBackUrl;
        $send_data['ID_NO']     = $this->data['idcardNumber'];
        $send_data['SETT_ACCT_NO']     = $this->data['bankcardNumber'];
        $send_data['CARD_INST_NAME']     = $this->data['bank'];
        $send_data['NAME']     = $this->data['realname'];
        $send_data['PHONE_NO'] = $this->data['phone'];;
        $send_data['ADD1'] = $this->data['creditcardNumber'];;
        $this_header         = array(
            "content-type: application/x-www-form-urlencoded;charset=UTF-8"
        );
        $url = $this->payUrl.'/MyLandQuickPay/servlet/QuickPay';
        $res                 = $this->post($url, $send_data, $this_header,1);
        $checkRes            = $this->checkError($res, $send_data);
        return $checkRes ? array('url'=>$res['html'],'order_id'=>$this->data['order_id']) : false;
    }
    /**
     * @desc 交易结果查询
     * */
    public function tradeRevice(){
        if (!$this->data) return false;
        $sign_param             = array(
            'ORDER_ID' => $this->data['order_id'],
            'ORG_ORDER_ID' => $this->data['axf_order_no'],
            'USER_ID' => $this->data['channel_code'],
        );
        $send_data              = $sign_param;
        $send_data['SIGN']      = $this->getSign($sign_param,$this->data['channel_key']);
        $send_data['USER_TYPE'] = '02';
        $send_data['SIGN_TYPE'] = '03';
        $this_header            = array(
            "content-type: application/x-www-form-urlencoded;charset=UTF-8"
        );
        $url = $this->host.'/servlet/Query';
        $res                    = $this->post($url, $send_data, $this_header,2);
        $checkRes               = $this->checkError($res, $send_data,true);
        if($checkRes){
            $res['code'] = $res['RESP_CODE'];
            return $res;
        }
        return false;
    }

    /**
     * @desc    订单查询，核对
     */
    function checkOrder()
    {
    }

    public function checkError($data, $send_data,$type='false')
    {
        $return = true;
        if($data['RESP_CODE']){
            $code = $data['RESP_CODE'];
            $check = array('00','0000');
            if($type){
                if($data['STATUS']==1){
                    $check = array('00','0000','0100');
                }
            }
        }elseif($data['respCode']){
            $code = $data['respCode'];
            $check = array('0000');
        }
        if($data && !in_array($code,$check)){
            XbFunc_Log::write('fujianError', '福建米联返回数据错误，请求参数:' . json_encode($send_data), ';返回参数：' . json_encode($data));
            $return = false;
        }
        else {
            // 非正式  环境下记录正确调用的日志
            $env = getenv('RUNTIME_ENVIROMENT') ? getenv('RUNTIME_ENVIROMENT') : (defined('SHELL_VARIABLE') ? SHELL_VARIABLE : '');
            $env = empty($env) ? 'local' : ($env != 'rls' ? 'local' : $env);
            if ($env != 'rls') {
                XbFunc_Log::write('fujianSucc', '福建米联返回数据，请求参数:' . json_encode($send_data), ';返回参数：' . json_encode($data));
            }
        }
        
        return $return;
    }
     public function post($url, $post_data, $header = array(),$is_xml=false)
    {
        $ret = array(
            'error' => 500,     /** 参数不正确 */
            'data'  => array(),
        );
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => http_build_query($post_data),
            CURLOPT_HTTPHEADER => $header,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_SSL_VERIFYHOST => 0,
        ));
        $ch_ret = curl_exec($ch);
        if (0 != ($errno = curl_errno($ch)))
        {
            XbFunc_Log::write('curlError', '错误编号：'.curl_errno($ch), '具体错误：'.curl_error($ch));
            $ret['error'] = 501;
            curl_close($ch);
            return $ret;
        }
        curl_close($ch);
        if($is_xml==2){
            $result = $this->xmlToArray($ch_ret);
        }else if($is_xml == 1){
            $result['html'] = $ch_ret;
            $result['respCode'] = '0000';
        }else{
            $result = json_decode($ch_ret, true);
        }
        if (! is_array($result) || count($result) <= 0)
        {
            $ret['error'] = 400;
            return $ret;
        }

        $ret = $result;
        return $ret;
    }
    //将XML转为array
     public function xmlToArray($xml)
    {
        //禁止引用外部xml实体
        libxml_disable_entity_loader(true);
        $values = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
        return $values;
    }
    /**
     * @desc    渠道提现
     */
    function withdraw(){}
}
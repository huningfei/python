<?php
// require_once ROOT_PATH.'/XbLib/Mailer/PHPMailerAutoload.php';
require_once 'Mailer/PHPMailerAutoload.php';
class XbLib_Postman{
    static $Mailer;
    
    private static function getInstance(){
        if(self::$Mailer instanceof self){
            return self::$Mailer;
        }else{
            return self::$Mailer = new PHPMailer;
        }
    }
    /*
    * @params $address 收件人地址 $subject 邮件标题 $body表示邮件正文
    */
    static function sendMail($address,$subject = "",$body = "",$attach=""){
        date_default_timezone_set("Asia/Shanghai"); //设定时区东八区
        $config =XbLib_Mailer_Config::$_config;// Yaf_Registry::get("config")->mailer;
        $mail = self::getInstance();
        //$body = preg_match("[\]",'',$body);       //对邮件内容进行必要的过滤
        $mail->CharSet = $config['charset'];         //设定邮件编码，默认ISO-8859-1，如果发中文此项必须设置，否则乱码
        $mail->IsSMTP();                            // 设定使用SMTP服务
        $mail->SMTPAuth = true;                   // 启用 SMTP 验证功能
        $mail->Host = $config['host'];      // SMTP 服务器
        $mail->Port = $config['port'];                   // SMTP服务器的端口号
        $mail->Username = $config['smtp_username'];  // SMTP服务器用户名
        $mail->Password = $config['smtp_password'];
        if(isset($config['auth'])){
        	$mail->SMTPAuth = $config['auth'];
        }
       	if(isset($config['secure'])){
       		$mail->SMTPSecure = $config['secure'];
       	}
        
        //SMTP调试
        if($config['smtp_debug']){
            error_reporting(E_ALL);
            // 1 = errors and messages
            // 2 = messages only
            $mail->SMTPDebug  = $config['smtp_debug'];
        }
        //$mail->SMTPSecure = "ssl";                 // 安全协议
        $mail->From = $config['from'];
        $mail->FromName = $config['from_name'];
        if (is_array($address)) {
            foreach ($address as $addr) {
                $mail->addAddress($addr);
            }
        }
        else {
            $mail->addAddress($address);               //设置收件人,参数2为收件人名称,可选
        }
        //设置收件人,参数2为收件人名称,可选  
        //$mail->addReplyTo($config['replyto']);
        //$mail->addCC('cc@example.com');
        //$mail->addBCC('bcc@example.com');
        
        //$mail->WordWrap = 50;                                 // Set word wrap to 50 characters
        //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
        if ($attach){
            $mail->addAttachment($attach);
        }
        //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
        $mail->isHTML(true);                        
        $mail->Subject = $subject;                              //邮件标题
        $mail->Body = $body;                                    //邮件内容
        if(!$mail->Send()) {
            return false;
        }else{
            return true;
        }
    }
    static function gotomail($mail){
        $t=explode('@',$mail);
        $t=strtolower(isset($t[1])?$t[1]:'');
        if($t=='163.com'){
            return 'mail.163.com';
        }else if($t=='vip.163.com'){
            return 'vip.163.com';
        }else if($t=='126.com'){
            return 'mail.126.com';
        }else if($t=='qq.com'||$t=='vip.qq.com'||$t=='foxmail.com'){
            return 'mail.qq.com';
        }else if($t=='gmail.com'){
            return 'mail.google.com';
        }else if($t=='sohu.com'){
            return 'mail.sohu.com';
        }else if($t=='tom.com'){
            return 'mail.tom.com';
        }else if($t=='vip.sina.com'){
            return 'vip.sina.com';
        }else if($t=='sina.com.cn'||$t=='sina.com'){
            return 'mail.sina.com.cn';
        }else if($t=='tom.com'){
            return 'mail.tom.com';
        }else if($t=='yahoo.com.cn'||$t=='yahoo.cn'){
            return 'mail.cn.yahoo.com';
        }else if($t=='tom.com'){
            return 'mail.tom.com';
        }else if($t=='yeah.net'){
            return 'www.yeah.net';
        }else if($t=='21cn.com'){
            return 'mail.21cn.com';
        }else if($t=='hotmail.com'){
            return 'www.hotmail.com';
        }else if($t=='sogou.com'){
            return 'mail.sogou.com';
        }else if($t=='188.com'){
            return 'www.188.com';
        }else if($t=='139.com'){
            return 'mail.10086.cn';
        }else if($t=='189.cn'){
            return 'webmail15.189.cn/webmail';
        }else if($t=='wo.com.cn'){
            return 'mail.wo.com.cn/smsmail';
        }else if($t=='139.com'){
            return 'mail.10086.cn';
        }else {
            return '';
        }
    }
}
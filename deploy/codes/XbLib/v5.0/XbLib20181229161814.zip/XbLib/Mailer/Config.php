<?php
//发送邮件的配置文件
class XbLib_Mailer_Config {
    //发邮件的配置文件
    public static  $_config = array(
        'charset' => 'utf-8',
        'host' => 'email-smtp.us-east-1.amazonaws.com',
        'port' => '25',
        'smtp_username' => 'AKIAJ35Q4FI3E5DY4LUA',
        'smtp_password' => 'Aqo+9BC9Hh0TCbmvuQ1jnRf8fvw69cDo+c7eprhezvzh',
        'smtp_debug' => '0',
        'from' => 'no-reply@p2peye.com',
        'from_name' => '网贷天眼',
        'auth' => true,
        'secure' => 'tls'
    );
}
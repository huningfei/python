<?php
/**
 * @desc    支付通道工厂类
 * @author  qien
 * @date    18.04.08
 */
class XbLib_Repaymentchannel_Factory{
	private $adapter        = null;
	private $channel_config = null;
	
	/**
	 * 获得   XbLib_Repaymentchannel_Factory
	 * @param   string      $pay_adapter
	 * @throws  Exception
	 */
	function __construct($pay_adapter){
		$env = getenv('RUNTIME_ENVIROMENT') ? getenv('RUNTIME_ENVIROMENT') : (defined('SHELL_VARIABLE') ? SHELL_VARIABLE : '');
		$env = empty($env) ? 'local' : ($env != 'rls' ? 'local' : $env);
		$config = XbLib_Repaymentchannel_Config::getConfig($pay_adapter, $env);
		if(!$config){
			throw new Exception('can not found the pay_config env:'.$env);
		}
		$this->adapter        = $pay_adapter;
		$this->channel_config = $config;
	}
	
	/**
	 * 
	 * @return Ambigous <NULL,XbLib_Paychannel_Abstract,XbLib_Paychannel_Interface>
	 */
	public function getRepaymentchannelAdapter(){
		$adapter = null;
		switch ($this->adapter){
			case 'milianYingtao':
				$adapter = XbLib_Repaymentchannel_Adapter_MilianYingtao::getInstance($this->channel_config);
				break;
            case 'milianYangtao':
                $adapter = XbLib_Repaymentchannel_Adapter_MilianYangtao::getInstance($this->channel_config);
                break;
            case 'YaKuKuBao':
                $adapter = XbLib_Repaymentchannel_Adapter_YaKuKuBao::getInstance($this->channel_config);
                break;
			default:
                break;
		}
		return $adapter;
	}
}

<?php
/**
 * @desc    支付通道抽象类
 * @author  qien
 * @date    18.04.08
 */
abstract class XbLib_Repaymentchannel_Abstract{

    protected function _init($config){

    }

    /**
     * @desc    加密签名类，加密方式：将key以ASCII排序，将key=value使用&链接，如果值为空不参与加密
     * @param   array   $data   需要加密的数据
     * @param   string  $key    通道key
     * @return  string  $return 返回加密后的数据
     */
    protected function sign($data){
        $key = $this->signKey;
        foreach($data as $k=>$v){
            if($v === '' || $v === null || $v === false){
                unset($data[$k]);
            }else{
                $data[$k] = $k.'='.$v;
            }
        }
        ksort($data);
        $dataStr = implode('&', $data);
        $signStr = $dataStr.'&key='.$key;
        return md5($signStr);
    }

    protected function sortSignStr(){

    }

    /**
     * @desc    生成加密随机字符串，使用RandomLib类库生成
     * @param   int     $num        生成位数
     * @return  string  $return     返回随机字符串
     */
    protected function getNonceStr($num){
        $factory   = new RandomLib\Factory();
        $generator = $factory->getGenerator(new SecurityLib\Strength());
        $nonceStr  = $generator->generateString($num, "abcdefghijklmnopqrstuvwxyz1234567890");
        return $nonceStr;
    }
}
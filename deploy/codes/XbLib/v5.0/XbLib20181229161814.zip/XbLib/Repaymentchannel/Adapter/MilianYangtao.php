<?php

/**
 * 福建米联杨桃还款通道
 *
 *
 */
class XbLib_Repaymentchannel_Adapter_MilianYangtao extends XbLib_Repaymentchannel_Adapter_Milian implements XbLib_Paychannel_Interface
{
    public static $obj;

    public function __construct($config){
        parent::__construct($config);
    }

    public static function getInstance($config){
        if (empty(self::$obj)) {
            self::$obj = new self($config);
        }
        return self::$obj;
    }
}
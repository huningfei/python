<?php
//雅酷还款基类
class XbLib_Repaymentchannel_Adapter_YaKu extends XbLib_Repaymentchannel_Abstract implements XbLib_Repaymentchannel_Interface{
    public $channel_config = '';

    public function __construct($config){
        $this->channel_config = $config;
        $this->data      = '';
    }

    /**
     * @desc    获取基本参数
     * @return  array  $return     获取基本参数
     */
    public function getBaseParam() {
        $param=array();
        $param['service']       = '';//服务名称
        $param['version']       = $this->channel_config['version'];//接口版本
        $param['request_time']  = date("YmdHis");//请求时间
        $param['partner_id']    = $this->channel_config['partner_id'];//合作者身份ID
        $param['_input_charset']= $this->channel_config['_input_charset'];//参数编码字符集
        $param['sign_type']     = $this->channel_config['sign_type'];//签名类型
        $param['notify_url']    = '';//异步通知地址
        $param['memo']          = '';//备注
        return $param;

    }

    /**
     * @desc    发送请求
     * @return  boolean  $return     发送请求
     */
    public function send($YaKuTools, $param, $requestUrl='mgsRequestUrl'){
        ksort($param);//对签名参数据排序
        //进行签名
        $sign=$YaKuTools->getSignMsg($param);
        //将签名结果存入请求数组中
        $param['sign']=$sign;
        XbFunc_Log::write('yakuSend', '请求参数', json_encode($param));
        $data = $YaKuTools->createcurl_data($param);
        // 调用createcurl_data创建模拟表单需要的数据
        $result = $YaKuTools->curlPost($this->channel_config[$requestUrl], $data);
        // 使用模拟表单提交进行数据提交
        $splitdata = json_decode($result,true);
        $sign_type = $splitdata['sign_type'];//签名方式
        ksort($splitdata); // 对签名参数据排序
//        if ($YaKuTools->checkSignMsg($splitdata)) {
//            $YaKuTools->write_log("返回结果签名验证成功");
//            $result = "同步返回参数:\n".$result."\n\n返回结果签名验证：成功";
//        } else {
//            $YaKuTools->write_log("返回结果签名验证错误");
//            $result = "同步返回参数:\n".$result."\n\n返回结果签名验证：错误";
//        }
        $res['success'] = $splitdata['response_code'] == 'APPLY_SUCCESS' ? 1 : 0;
        $res['data']    = $splitdata;
        return $res;
    }

    /**
     * @desc    组装加密参数
     * @param   int     $data           需要加密的数据
     * @param   boolen  $isCheckSign    是否是检验加密
     */
    function buildSignData($data, $isCheckSign = false){
        $this->data = $data;
        return $this;
    }

    /**
     * @desc    注册用户接口
     */
    function signUp(){
        $YaKuTools = new XbLib_RepaymentObjs_Tool_YaKuTool($this->channel_config);
        $param                      = $this->getBaseParam();
        $param['service']           = 'mimer_register_merchant';//小微商户入网

        $param['request_no']        = $this->data->param['order_id'];//商户请求号
        $param['identity_id']       = $this->data->user->info['uid'];//小微商户ID
        $param['mimer_name']        = $this->data->user->info['realname'];//小微商户姓名
        $param['mimer_cert_no']     = $this->data->user->info['idcardNumber'];//小微商户身份证号
        $param['mimer_phone']       = $this->data->user->info['phone'];//小微商户手机号
        $param['mimer_cert_pic1']   = $YaKuTools->get_base64($this->data->user->info['idcardImage1']);//身份证影印正面
        $param['mimer_cert_pic2']   = $YaKuTools->get_base64($this->data->user->info['idcardImage2']);//身份证影印反面

        foreach (array('mimer_name', 'mimer_cert_no', 'mimer_phone') as $key => $value) {
            $param[$value] = $YaKuTools->Rsa_encrypt($param[$value]);
        }

        XbFunc_Log::write('yakukubaoSignUp','雅酷入网请求 '.$this->data->user->info['uid'], serialize($this->data));
        $res_register = $this->send($YaKuTools, $param, 'mgsRequestUrl');
        XbFunc_Log::write('yakukubaoSignUp','雅酷入网结果 '.$this->data->user->info['uid'], json_encode($res_register));

        if ($res_register['success']) {
            $param                      = $this->getBaseParam();
            $param['service']           = 'mimer_bind_fundout_card';//小微商户绑定结算卡

            $param['request_no']        = $this->data->param['order_id'];//绑卡请求号
            $param['mimer_member_id']   = $res_register['data']['mimer_member_id'];//小微商户编号
            $param['settle_bank_card']  = $this->data->user->info['bankcardNumber'];//结算银行卡号 需要RSA公钥加密处理
            $param['mimer_bind_phone']  = $this->data->user->info['bankcard_phone'];//小微商户绑卡手机号 需要RSA公钥加密处理
            $param['is_real_time']      = '0';//是否实时结算
            $param['bank_code']         = $YaKuTools->get_bank_code($this->data->user->info['bankCode']);//开户银行编号

            foreach (array('settle_bank_card', 'mimer_bind_phone') as $key => $value) {
                $param[$value] = $YaKuTools->Rsa_encrypt($param[$value]);
            }

            XbFunc_Log::write('yakukubaoSignUp','雅酷绑卡请求 '.$this->data->user->info['uid'], serialize($this->data));
            $res_bindcard = $this->send($YaKuTools, $param, 'mgsRequestUrl');
            XbFunc_Log::write('yakukubaoSignUp','雅酷绑卡结果 '.$this->data->user->info['uid'], json_encode($res_bindcard));
        }

        return $res_bindcard;
    }

    /**
     * @desc    发送交易-下单支付
     */
    function transaction(){
        $YaKuTools = new XbLib_RepaymentObjs_Tool_YaKuTool($this->channel_config);
        $param                      = $this->getBaseParam();
        $param['service']           = 'mimer_bank_card_pay';//卡要素支付
        if ($this->data->param['notify_type'] == 1){
            $param['notify_url']        = $this->channel_config['notify_url_1'];//异步通知地址:一键
        }else{
            $param['notify_url']        = $this->channel_config['notify_url_3'];//异步通知地址:智能
        }

        $param['out_trade_no']      = $this->data->param['order_id'];//商户订单号
        $param['summary']           = '房贷还款';//摘要
        $param['payer_id']          = $this->data->user->channel_code['channel_code'];//付款用户标识
        $param['payee_id']          = $this->data->user->uid;//收款方用户标识
        $param['amount']            = $this->data->param['pay_amount'];//金额
        $param['split_ratio']       = $this->data->param['rate'] * 100;//分账比率
        $param['split_type']        = 2;//分账类型
        $param['bank_code']         = $YaKuTools->get_bank_code($this->data->user->card['bankCode']);//银行编号
        $param['bank_card_no']      = $this->data->user->card['cardNumber'];//银行卡号 需要RSA公钥加密处理
        $param['account_name']      = $this->data->user->info['realname'];//持卡人姓名 需要RSA公钥加密处理
        $param['card_type']         = 'CREDIT';//卡类型
        $param['card_attribute']    = 'C';//卡属性
        $param['cert_type']         = 'IC';//证件类型
        $param['cert_no']           = $this->data->user->info['idcardNumber'];//证件号码 需要RSA公钥加密处理
        $param['phone_no']          = $this->data->user->card['telephone'];//手机号 需要RSA公钥加密处理
        $param['validity_period']   = substr_replace($this->data->user->card['validDate'],'/',2,0);//有效期 需要RSA公钥加密处理
        $param['verification_value']= $this->data->user->card['cvv'];//CVV2 需要RSA公钥加密处理
        $param['payer_ip']          = $YaKuTools->get_ip();//请求者IP
        $param['extend_param']      = 'PERFECT_BILL^'.$this->data->param['merchant_no'];
        $param['settle_account_type']= 'BXT_D0_SETTLE';//结算账户类型

        foreach (array('bank_card_no', 'account_name', 'cert_no', 'phone_no', 'validity_period', 'verification_value') as $key => $value) {
            $param[$value] = $YaKuTools->Rsa_encrypt($param[$value]);
        }

        XbFunc_Log::write('yakukubaoCreateOrder','雅酷支付请求 '.$this->data->user->info['uid'], serialize($this->data));
        $res = $this->send($YaKuTools, $param, 'masRequestUrl');
        XbFunc_Log::write('yakukubaoCreateOrder','雅酷支付结果 '.$this->data->user->info['uid'], json_encode($res));
//        $res['success'] = 1;
        return $res;
    }

    /**
     * @desc    发送交易-下单代付
     */
    function withdraw(){
        $YaKuTools = new XbLib_RepaymentObjs_Tool_YaKuTool($this->channel_config);
        $param                      = $this->getBaseParam();
        $param['service']           = 'mimer_single_pay2bank';//代付
        if ($this->data->param['notify_type'] == 2){
            $param['notify_url']        = $this->channel_config['notify_url_2'];//异步通知地址:一键
        }else{
            $param['notify_url']        = $this->channel_config['notify_url_4'];//异步通知地址:智能
        }

        $param['out_trade_no']      = $this->data->param['order_id'];
        $param['identity_id']       = $this->data->user->uid;
        $param['bank_account_num']  = $this->data->user->card['cardNumber'];
        $param['phone_no']          = $this->data->user->card['telephone'];
        $param['bank_name']         = $this->data->user->card['bank'];
        $param['bank_code']         = $YaKuTools->get_bank_code($this->data->user->card['bankCode']);
        $param['amount']            = $this->data->param['custom_amount'] + $this->data->param['single_fee'];
        $param['split_amount']      = $this->data->param['single_fee'];
        $param['split_type']        = 1;
        $param['card_attribute']    ='C';
        $param['card_type']         = 'CREDIT';
        $param['account_type']      = 'BXT_D0_SETTLE';

        foreach (array('bank_account_num', 'phone_no') as $key => $value) {
            $param[$value] = $YaKuTools->Rsa_encrypt($param[$value]);
        }

        XbFunc_Log::write('yakukubaoCreatePayOrder','雅酷代付请求 '.$this->data->user->info['uid'], serialize($this->data));
        $res = $this->send($YaKuTools, $param, 'masRequestUrl');
        XbFunc_Log::write('yakukubaoCreatePayOrder','雅酷代付结果 '.$this->data->user->info['uid'], json_encode($res));
//        $res['success'] = 1;
        return $res;

    }

    /**
     * @desc    单笔支付查询
     * @return  null  $return   单笔支付查询
     */
    public function queryOrder(){
        $YaKuTools = new XbLib_RepaymentObjs_Tool_YaKuTool($this->channel_config);
        $param                      = $this->getBaseParam();
        $param['service']           = 'mimer_query_single_pay';//单笔支付查询

        $param['out_trade_no']      = $this->data['order_id'];//商户订单号

        $res = $this->send($YaKuTools, $param, 'masRequestUrl');
        return $res;
    }

    /**
     * @desc    单笔待付查询
     * @return  null  $return   单笔支付查询
     */
    public function queryPayOrder(){
        $YaKuTools = new XbLib_RepaymentObjs_Tool_YaKuTool($this->channel_config);
        $param                      = $this->getBaseParam();
        $param['service']           = 'mimer_query_single_pay2bank';//单笔支付查询

        $param['out_trade_no']      = $this->data['order_id'];//商户订单号

        $res = $this->send($YaKuTools, $param, 'masRequestUrl');
        return $res;
    }

    /**
     * @desc    账户余额查询
     * @return  null  $return   账户余额查询
     */
    public function getBalance(){
        $YaKuTools = new XbLib_RepaymentObjs_Tool_YaKuTool($this->channel_config);
        $param                      = $this->getBaseParam();
        $param['service']           = 'mimer_query_balance';//账户余额查询

        $param['mimer_member_id']   = $this->data['channel_code'];
        $param['balance_type']      = 2;

        $res = $this->send($YaKuTools, $param, 'queryRequestUrl');
        return $res;
    }

    /**
     * @desc    订单查询，核对
     */
    function checkOrder(){
        if ($this->data['type'] == 1){
            $res = $this->queryOrder();
            $status_arr = array(
                'WAIT_PAY'      => '0100',//等待付款(系统不会异步通知)
                'PAY_FINISHED'  => '0000',//已付款(系统会异步通知)
                'TRADE_FAILED'	=> 2,//交易失败(系统会异步通知)
                'TRADE_FINISHED'=> '0000',//交易结束(系统会异步通知）支付成功
                'TRADE_CLOSED'  => 2,//交易关闭 (系统会异步通知) 超时未支付
            );
            $res['res']['RESP_CODE']   = $status_arr[$res['data']['trade_status']];
//            $res['res']['RESP_CODE']   = '0000';
        }elseif($this->data['type'] == 2){
            $res = $this->queryPayOrder();
            $status_arr = array(
                'SUCCESS'       => '0000',//成功(系统会异步通知)
                'FAILED'        => 2,//失败(系统会异步通知)
                'PROCESSING'	=> '0100',//处理中(系统不会异步通知)
                'RETURNT_TICKET'=> 2,//银行退票(系统会异步通知)
            );
            $res['res']['RESP_CODE']   = $status_arr[$res['data']['withdraw_status']];
//            $res['res']['RESP_CODE']   = '0000';
        }
        return $res;
    }

    public function checkChannelBank(){
        return true;
    }

    /**
     * @desc    签名加密
     * @param   string  $dataStr    签名字符串
     */
    function sign($dataStr){}

    /**
     * @desc    验证加密
     * @param   array   $data
     * @param   string  $sign
     */
    function checkSign($data, $sign){}


    /**
     * @desc    更改用户信息接口
     */
    function updateUserInfo(){}

}
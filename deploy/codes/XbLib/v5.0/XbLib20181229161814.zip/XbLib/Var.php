<?php

/**
 *
 * Author: abel
 * Date: 2017/12/11
 * Time: 11:35
 */
class XbLib_Var {
    //const TOKEN_TYPE = array('ios', 'android');
    public static $channelBank = array(   //支持储蓄卡银行
        'ICBC'    => '工商银行',
        'ABC'     => '农业银行',
        'CMB'     => '招商银行',
        'CCB'     => '建设银行',
        'COMM'    => '交通银行',
        'CITIC'   => '中信银行',
        'CEB'     => '光大银行',
        'BJBANK'  => '北京银行',
        'SPABANK' => '深圳发展银行',
        'BOC'     => '中国银行',
        'CIB'     => '兴业银行',
        'CMBC'    => '民生银行',
        'HXBANK'  => '华夏银行'
    );

    public static $numFormat = array(
        1   => '一',
        2   => '二',
        3   => '三',
        4   => '四',
        5   => '五',
        6   => '六',
        7   => '七',
        8   => '八',
        9   => '九',
        10  => '十',
        11  => '十一',
        12  => '十二',
        13  => '十三',
        14  => '十四',
        15  => '十五',
        16  => '十六',
        17  => '十七',
        18  => '十八',
        19  => '十九',
        20  => '二十',
        21  => '二十一',
        22  => '二十二',
        23  => '二十三',
        24  => '二十四',
        25  => '二十五',
        26  => '二十六',
        27  => '二十七',
        28  => '二十八',
        29  => '二十九',
        30  => '三十',
        31  => '三十一',
        32  => '三十二',
        33  => '三十三',
        34  => '三十四',
        35  => '三十五',
        36  => '三十六',
        37  => '三十七',
        38  => '三十八',
        39  => '三十九',
        40  => '四十',
        41  => '四十一',
        42  => '四十二',
        43  => '四十三',
        44  => '四十四',
        45  => '四十五',
        46  => '四十六',
        47  => '四十七',
        48  => '四十八',
        49  => '四十九',
        50  => '五十',
        51  => '五十一',
        52  => '五十二',
        53  => '五十三',
        54  => '五十四',
        55  => '五十五',
        56  => '五十六',
        57  => '五十七',
        58  => '五十八',
        59  => '五十九',
        60  => '六十',
        61  => '六十一',
        62  => '六十二',
        63  => '六十三',
        64  => '六十四',
        65  => '六十五',
        66  => '六十六',
        67  => '六十七',
        68  => '六十八',
        69  => '六十九',
        70  => '七十',
        71  => '七十一',
        72  => '七十二',
        73  => '七十三',
        74  => '七十四',
        75  => '七十五',
        76  => '七十六',
        77  => '七十七',
        78  => '七十八',
        79  => '七十九',
        80  => '八十',
        81  => '八十一',
        82  => '八十二',
        83  => '八十三',
        84  => '八十四',
        85  => '八十五',
        86  => '八十六',
        87  => '八十七',
        88  => '八十八',
        89  => '八十九',
        90  => '九十',
        91  => '九十一',
        92  => '九十二',
        93  => '九十三',
        94  => '九十四',
        95  => '九十五',
        96  => '九十六',
        97  => '九十七',
        98  => '九十八',
        99  => '九十九',
        100 => '一百'
    );

    /**
     * 小白银行code 与 米联系统银行信息对应关系
     * 
     */
    public static $bankCode2MilianBank = array(
        'ICBC' =>
        array (
            'abbr' => '102',              //银行代号
            'code' => 'ICBC',             //银行英文编号
            'name' => '中国工商银行',         //银行名称
            'no' => '102100099996',       //银行联行号
        ),
        'ABC' =>
        array (
            'abbr' => '103',
            'code' => 'ABC',
            'name' => '中国农业银行',
            'no' => '103100000026',
        ),
        'BOC' =>
        array (
            'abbr' => '104',
            'code' => 'BOC',
            'name' => '中国银行',
            'no' => '104100000004',
        ),
        'CCB' =>
        array (
            'abbr' => '105',
            'code' => 'CCB',
            'name' => '中国建设银行',
            'no' => '105100000017',
        ),
       
        'COMM' =>
        array (
            'abbr' => '301',
            'code' => 'BCOM',
            'name' => '交通银行',
            'no' => '301290000007',
        ),
        'CITIC' =>
        array (
            'abbr' => '302',
            'code' => 'CITIC',
            'name' => '中信银行',
            'no' => '302100011000',
        ),
        'CEB' =>
        array (
            'abbr' => '303',
            'code' => 'CEB',
            'name' => '中国光大银行',
            'no' => '303100000006',
        ),
        'HXBANK' =>
        array (
            'abbr' => '304',
            'code' => 'HXB',
            'name' => '华夏银行',
            'no' => '304100040000',
        ),
        'CMBC' =>
        array (
            'abbr' => '305',
            'code' => 'CMBC',
            'name' => '中国民生银行',
            'no' => '305100000013',
        ),
        
        'CMB' =>
        array (
            'abbr' => '308',
            'code' => 'CMB',
            'name' => '招商银行',
            'no' => '308584000013',
        ),
        'CIB' =>
        array (
            'abbr' => '309',
            'code' => 'CIB',
            'name' => '兴业银行',
            'no' => '309391000011',
        ),
        'BJBANK' =>
        array (
            'abbr' => '317',
            'code' => 'BOB',
            'name' => '北京银行',
            'no' => '313100000013',
        ),
        /*'SPABANK' =>    //现为平安银行
        array (
            'abbr' => '783',
            'code' => 'SDB',
            'name' => '深圳发展银行',
            'no' => NULL,
        ),*/
        
        //其它非常用银行
        'SPDB' =>
        array (
            'abbr' => '310',
            'code' => 'SPDB',
            'name' => '上海浦东发展银行',
            'no' => '310290000013',
        ),
        'GDB' =>
        array (
            'abbr' => '306',
            'code' => 'CGB',
            'name' => '广东发展银行',
            'no' => '306331003281',
        ),
        'SPABANK' =>
        array (
            'abbr' => '307',
            'code' => 'PAB',
            'name' => '平安银行',
            'no' => '307584007998',
        ),
        
        'EGBANK' =>
        array (
            'abbr' => '315',
            'code' => 'EGBANK',
            'name' => '恒丰银行',
            'no' => '315456000105',
        ),
        'CZBANK' =>
        array (
            'abbr' => '316',
            'code' => 'CZB',
            'name' => '浙商银行',
            'no' => '316331000018',
        ),
        'PSBC' =>
        array (
            'abbr' => '403',
            'code' => 'PSBC',
            'name' => '中国邮政储蓄银行',
            'no' => '403100000004',
        ),
        'HZCB' =>
        array (
            'abbr' => '318',
            'code' => 'HCCB',
            'name' => '杭州银行',
            'no' => '313331000014',
        ),
        'NJCB' =>
        array (
            'abbr' => '319',
            'code' => 'NJCB',
            'name' => '南京银行',
            'no' => '313301008887',
        ),
        'BJRCB' =>
        array (
            'abbr' => '314',
            'code' => 'BRCB',
            'name' => '北京农村商业银行',
            'no' => '402100000018',
        ),
        
        //数据不完整
        /*
        17 =>
        array (
            'abbr' => '313',
            'code' => 'BIN',
            'name' => '宁波国际银行',
            'no' => NULL,
        ),
        21 =>
        array (
            'abbr' => '501',
            'code' => 'HSBC',
            'name' => '汇丰银行',
            'no' => NULL,
        ),
        22 =>
        array (
            'abbr' => '502',
            'code' => 'HKBEA',
            'name' => '东亚银行',
            'no' => NULL,
        ),
        23 =>
        array (
            'abbr' => '503',
            'code' => 'NCBCHINA',
            'name' => '南洋商业银行',
            'no' => NULL,
        ),
        24 =>
        array (
            'abbr' => '504',
            'code' => 'HANGSENG',
            'name' => '恒生银行',
            'no' => NULL,
        ),
        
        26 =>
        array (
            'abbr' => '905',
            'code' => 'UNIONPAY',
            'name' => '中国银联',
            'no' => NULL,
        ),
        
        
        4 =>
        array (
            'abbr' => '201',
            'code' => 'CDB',
            'name' => '国家开发银行',
            'no' => NULL,
        ),
        5 =>
        array (
            'abbr' => '202',
            'code' => 'EXIMBANK',
            'name' => '中国进出口银行',
            'no' => NULL,
        ),
        6 =>
        array (
            'abbr' => '203',
            'code' => 'ADBC',
            'name' => '中国农业发展银行',
            'no' => NULL,
        ),
        */
    );

    public static $help_type = array(   //帮助所属问题
        '1'    => '快捷收款',
        '2'    => '智能还款',
        '3'    => '申请办卡',
        '4'    => '认证审核',
        '5'    => '账户等级',
        '6'    => '安全相关',
        '7'    => '业务合作',
        '8'    => '其他',
    );

    public static $profitType = array(
        1 => '分润奖励',
        2 => '提现',
        3 => '收款红包',
        4 => '办信用卡红包'
    );

    public static $withdrawBatchStatus = array(
        1 => '审核中',     //生成订单
        2 => '审核通过',     //生成订单
        3 => '上传文件成功',     //生成订单
        4 => '上传文件失败',     //生成订单
        5 => '付款中',     //生成订单
        6 => '付款成功',     //生成订单
        7 => '付款失败',     //生成订单

    );

    public static $msgTemplate = [
        'reg' => [
            'app' => [
                'title'     => '欢迎您成功注册小白信用卡',
                'content'   => '欢迎来到小白信用卡，您在此可以轻松完成信用卡收款功能，提现秒到账，邀请其他用户更可拿到分润！',
                'url'       => 'message',
                'isLogin'   => 'true',
            ],
        ],
        'inviteReg' => [
            'app' => [
                'title'     => '您邀请的用户已完成注册',
                'content'   => '您邀请的用户__phone已完成注册，实名之后邀请关系才能生效！',
                'url'       => 'message',
                'isLogin'   => 'true',
            ],
        ],
        'inviteAuth' => [
            'app' => [
                'title'     => '您邀请的用户已完成实名认证',
                'content'   => '您邀请的用户__phone已成功完成实名认证，邀请关系已生效！',
                'url'       => 'message',
                'isLogin'   => 'true',
            ],
        ],
        'profit' => [
            'app' => [
                'title'     => '您邀请的用户完成一笔收款',
                'content'   => '您邀请的用户__phone成功收款1笔，去看看是否拿到分润吧！',
                'url'       => 'message',
                'isLogin'   => 'true',
            ],
        ],
        'repaymentProfit' => [
            'app' => [
                'title'     => '您邀请的用户完成一笔还款',
                'content'   => '您邀请的用户__phone成功收款1笔，去看看是否拿到分润吧！',
                'url'       => 'message',
                'isLogin'   => 'true',
            ],
        ],
        'authFail' => [
            'app' => [
                'title'     => '您的实名认证失败',
                'content'   => '您填写的实名信息有误，请重新填写提交！',
                'url'       => 'message',
                'isLogin'   => 'true',
            ],
            'wx'  => [
                'first'     => ['value' => '很遗憾您实名认证失败','color' => '#173177'],
                'keyword1'  => ['value' => '__name'],
                'keyword2'  => ['value' => '__phone'],
                'remark'    => ['value' => '您提交的实名认证资料未通过审核，点击重新认证','color' => '#173177'],
            ],
        ],
        'authSuccess' => [
            'app' => [
                'title'     => '您的实名认证成功',
                'content'   => '您已经实名认证成功，快去收款吧！',
                'url'       => 'message',
                'isLogin'   => 'true',
            ],
            'wx'  => [
                'first'     => ['value' => '恭喜您实名认证成功','color' => '#173177'],
                'keyword1'  => ['value' => '__name'],
                'keyword2'  => ['value' => '__phone'],
                'remark'    => ['value' => '您提交的实名资料已成功通过审核，快来收款吧！','color' => '#173177'],
            ],
        ],
        'commonRepaymentSuccess' => [
            'app' => [
                'title'     => '恭喜您成功还款__amount元至您尾号__cardNumber的信用卡',
                'content'   => '恭喜您成功还款__amount元至您尾号__cardNumber的信用卡，去看看您的订单详情吧！',
                'url'       => 'message',
                'isLogin'   => 'true',
            ],
            'wx'  => [
                'first'     => ['value' => '您好，您的一键还款订单支付成功','color' => '#173177'],
                'keyword1'  => ['value' => '一键还款支付'],
                'keyword2'  => ['value' => '__name'],
                'keyword3'  => ['value' => '__amount元（实际到账__amountActual元）', 'color' => '#FF4040'],
                'keyword4'  => ['value' => '__date'],
                'keyword5'  => ['value' => '__orderNumber'],
                'remark'    => ['value' => '点击查看详情','color' => '#173177'],
            ],
        ],
        'commonRepaymentFail' => [
            'wx'  => [
                'first'     => ['value' => '您好，您的一键还款订单支付失败','color' => '#173177'],
                'keyword1'  => ['value' => '一键还款支付'],
                'keyword2'  => ['value' => '__name'],
                'keyword3'  => ['value' => '__amount元（实际到账__amountActual元）', 'color' => '#FF4040'],
                'keyword4'  => ['value' => '__date'],
                'keyword5'  => ['value' => '__orderNumber'],
                'remark'    => ['value' => '点击查看详情','color' => '#173177'],
            ],
        ],
        'wiseRepaymentPlanSuccess' => [
            'wx'  => [
                'first'     => ['value' => '您好，您的智能还款订单制定成功','color' => '#173177'],
                'keyword1'  => ['value' => '智能还款'],
                'keyword2'  => ['value' => '__name'],
                'keyword3'  => ['value' => '__amount元', 'color' => '#FF4040'],
                'keyword4'  => ['value' => '__date'],
                'keyword5'  => ['value' => '__orderNumber'],
                'remark'    => ['value' => '点击查看详情','color' => '#173177'],
            ],
        ],
        'wiseSingleRepayment' => [
            'app' => [
                'title'     => '小白已成功为您执行一次智能还款任务',
                'content'   => '您的智能还款计划已成功执行一笔还款任务，还款金额：__amount.查看还款详情',
                'url'       => 'message',
                'isLogin'   => 'true',
            ],
            'wx'  => [
                'first'     => ['value' => '您好，你的智能还款订单成功执行一笔','color' => '#173177'],
                'keyword1'  => ['value' => '智能还款'],
                'keyword2'  => ['value' => '__name'],
                'keyword3'  => ['value' => '__amount元（实际到账__amountActual元）', 'color' => '#FF4040'],
                'keyword4'  => ['value' => '__date'],
                'keyword5'  => ['value' => '__orderNumber'],
                'remark'    => ['value' => '点击查看详情','color' => '#173177'],
            ],
        ],
        'wiseRepaymentSuccess' => [
            'app' => [
                'title'     => '恭喜您尾号__cardNumber信用卡的智能还款计划已全部完成',
                'content'   => '尊敬的用户您好，您尾号__cardNumber信用卡的智能还款计划已全部完成',
                'url'       => 'message',
                'isLogin'   => 'true',
            ],
            'wx'  => [
                'first'     => ['value' => '您好，您的智能还款订单已完成','color' => '#173177'],
                'keyword1'  => ['value' => '智能还款'],
                'keyword2'  => ['value' => '__name'],
                'keyword3'  => ['value' => '__amount元（实际到账__amountActual元）', 'color' => '#FF4040'],
                'keyword4'  => ['value' => '__date'],
                'keyword5'  => ['value' => '__orderNumber'],
                'remark'    => ['value' => '点击查看详情','color' => '#173177'],
            ],
        ],
        'wiseRepaymentStop' => [
            'app' => [
                'title'     => '您的还款计划已暂停执行',
                'content'   => '尊敬的用户您好，您的还款计划已暂停执行，去看看是什么原因吧。',
                'url'       => 'message',
                'isLogin'   => 'true',
            ],
            'wx'  => [
                'first'     => ['value' => '您好，您的智能还款订单还款失败，还款计划已终止','color' => '#173177'],
                'keyword1'  => ['value' => '智能还款'],
                'keyword2'  => ['value' => '__name'],
                'keyword3'  => ['value' => '__amount元（实际到账__amountActual元）', 'color' => '#FF4040'],
                'keyword4'  => ['value' => '__date'],
                'keyword5'  => ['value' => '__orderNumber'],
                'remark'    => ['value' => '点击查看详情','color' => '#173177'],
            ],
        ],
        'repaymentBillDate' => [
            'app'   => [
                'title'     => '账单日提醒',
                'content'   => '尊敬的用户您好，您尾号__cardNumber的__cardBank信用卡账单日已到，点击查看',
                'url'       => 'message',
                'isLogin'   => 'true'
            ],
            'wx'  => [
                'first'     => ['value' => '您尾号__cardNumber的__cardBank信用卡的账单日已到','color' => '#173177'],
                'remark'    => ['value' => '为避免逾期，请及时还款','color' => '#173177'],
                'keyword1'  => ['value' =>'__billDate'],
                'keyword2'  => ['value' =>'__payDate'],
            ],
        ],
        'repaymentPayDate' => [
            'app'   => [
                'title'     => '还款日提醒',
                'content'   => '尊敬的用户您好，您尾号__cardNumber的__cardBank信用卡最后还款日已到，为避免信用卡逾期，请点击还款。',
                'url'       => 'message',
                'isLogin'   => 'true'
            ],
            'wx'  => [
                'first'     => ['value' => '您尾号__cardNumber的__cardBank信用卡的还款日已到','color' => '#173177'],
                'remark'    => ['value' => '为避免逾期，请及时还款','color' => '#173177'],
                'keyword1'  => ['value' =>'__billDate'],
                'keyword2'  => ['value' =>'__payDate'],
            ],
        ],
        'bankcardUpdateFail' => [
            'app'   => [
                'title'     => '储蓄卡编辑提醒',
                'content'   => '尊敬的用户您好，您的储蓄卡编辑操作失败，请重新提交。',
                'url'       => 'message',
                'isLogin'   => 'true'
            ],
        ],
        'awardremind' => [
            'app'   => [
                'title'     => '您有__money元红包 即将失效',
                'content'   => '您的账户中有__money元的红包明天就失效了，立即点击领取吧',
                'url'       => 'message',
                'isLogin'   => 'true'
            ],
            'wx'    => [
                'first'     =>  ['value' => '您参加‘__name’活动的红包明天就失效啦','color'=>'#173177'],
                'keyword1'  =>  ['value' => '__date'],
                'keyword2'  =>  ['value' => '返现红包'],
                'keyword3'  =>  ['value' => '将于明天失效'],
                'keyword4'  =>  ['value' => '__name'],
                'keyword5'  =>  ['value' => '__type'],
                'remark'    =>  ['value' => '点击查看详情','color' => '#173177'],
            ],
        ],
        'awardarrive' => [
            'app'   => [
                'title'     => '恭喜您，收到__name共计__money元，点击立即领取',
                'content'   => '您参加__name活动的__money元奖励已经到账，点击即可领取到账户余额。',
                'url'       => 'message',
                'isLogin'   => 'true'
            ],
            'wx'    => [
                'first'     =>  ['value' => '您参加‘__name’活动的奖励到账了！','color'=>'#173177'],
                'keyword1'  =>  ['value' => '小白卡管家'],
                'keyword2'  =>  ['value' => '__money'],
                'keyword3'  =>  ['value' => '__date'],
                'keyword4'  =>  ['value' => '返现红包(__type)'],
                'keyword5'  =>  ['value' => '奖励已发送至【我的奖励】中'],
                'remark'    =>  ['value' => '点击查看详情','color' => '#173177'],
            ],
        ],
        'bindWx' => [
            'wx' => [
                'first'     => ['value' => '欢迎来到小白用卡管家，您在这里可以轻松完成信用卡收款、还款，收款超低费率1秒到账，邀请其他用户更可坐享分润~','color' => '#173177'],
                'keyword1'  => ['value' => '__phone'],
                'keyword2'  => ['value' => '__date'],
                'remark'    => ['value' => '感谢您对小白用卡管家支持，快来收款吧~','color' => '#173177'],
            ],
        ],
        'orderPayment' => [
            'wx' => [
                'first'     => ['value' => '您好，您的收款订单已成功到账','color' => '#173177'],
                'keyword1'  => ['value' => '收款支付'],
                'keyword2'  => ['value' => '__name'],
                'keyword3'  => ['value' => '__amount','color'=>'#FF4040'],
                'keyword4'  => ['value' => '__date'],
                'keyword5'  => ['value' => '__orderNumber'],
                'remark'    => ['value' => '点击查看详情','color'=>'#173177'],
            ],
        ],
    ];
}
<?php
/**
 * Created by PhpStorm.
 * User: yurong
 * Date: 2018/6/4
 * Time: 下午5:35
 */
Class XbModel_Act_Activity extends XbModel_BaseModel {
    public static $cache_tag = "Act_Activity_";
    public static $cache_expire = 259200;
    function __construct() {
        parent::_init("xb_act");
    }
    
    public static $activityStatus = [
        1 => '未开始',
        2 => '进行中', 
        3 => '已结束',
    ];
    
    /**
     * @desc 获取当前进行中活动
     * */
    public function getBeginActivity(){
        $time = time();
        $sql = " SELECT * FROM `activity` WHERE `start_time` <= '$time' AND `end_time` >= '$time'";
        $data = [];
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
    }
    
    /**
     * 获取活动列表
     * 
     * @param string $parentname
     * @param string $name
     * @param string $starttime
     * @param string $endtime
     * @param string $status
     * @param string $is_menu
     * @param number $offset
     * @param number $limit
     * @return array|multitype:|array
     */
    public function listActivity($parentname = '', $name = '', $starttime = '', $endtime = '', $status = '', $is_menu = '', $offset = 0, $limit = 20) {
        $sql = 'SELECT a.*, p.name as parent_name FROM `activity` AS a LEFT JOIN `activity` AS p ON a.pid = p.id WHERE 1 ';
        
        $data = [];
        
        if ($parentname) {
            $sql .= ' AND p.name LIKE :parentname ';
            $data[':parentname'] = "%{$parentname}%";
        }
        
        if ($name) {
            $sql .= ' AND a.name LIKE :name ';
            $data[':name'] = "%{$name}%";
        }
        
        if ($starttime) {
            $starttime = is_numeric($starttime) ? $starttime : strtotime($starttime . ' 00:00:00');
            $sql .= ' AND a.start_time >= :starttime ';
            $data[':starttime'] = $starttime;
        }
        
        if ($endtime) {
            $endtime = is_numeric($endtime) ? $endtime : strtotime($endtime . ' 23:59:59');
            $sql .= ' AND a.end_time <= :endtime ';
            $data[':endtime'] = $endtime;
        }
        
        if ($is_menu !== '') {
            $sql .= ' AND a.is_menu = ' . ($is_menu ? 1 : 0);
        }
        
        $currenttime = time();
        switch ($status) {
            case 1:
                $sql .= ' AND a.start_time > :currenttime ';
                $data[':currenttime'] = $currenttime;
                break;
            case 2:
                $sql .= ' AND a.start_time <= :currenttime ';
                $sql .= ' AND a.end_time >= :currenttime ';
                $data[':currenttime'] = $currenttime;
                break;
            case 3:
                $sql .= ' AND a.end_time < :currenttime ';
                $data[':currenttime'] = $currenttime;
                break;
            default:
                break;
        }
        
        $offset = (int)$offset;
        $limit = (int)$limit;
        
        $sql .= ' ORDER BY a.id desc';
        
        $sql .= " LIMIT {$offset},{$limit}";

        $data = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
        
        return $data ? $data : [];
    }
    
    /**
     * 获取活动列表
     *
     * @param string $parentname
     * @param string $name
     * @param string $starttime
     * @param string $endtime
     * @param string $status
     * @param string $is_menu
     * @return number
     */
    public function countActivity($parentname = '', $name = '', $starttime = '', $endtime = '', $status = '', $is_menu = '') {
        $sql = 'SELECT COUNT(*) FROM `activity` AS a LEFT JOIN `activity` AS p ON a.pid = p.id WHERE 1 ';
        
        $data = [];
        
        if ($parentname) {
            $sql .= ' AND p.name LIKE :parentname ';
            $data[':parentname'] = "%{$parentname}%";
        }
        
        if ($name) {
            $sql .= ' AND a.name LIKE :name ';
            $data[':name'] = "%{$name}%";
        }
        
        if ($starttime) {
            $starttime = is_numeric($starttime) ? $starttime : strtotime($starttime . ' 00:00:00');
            $sql .= ' AND a.start_time >= :starttime ';
            $data[':starttime'] = $starttime;
        }
        
        if ($endtime) {
            $endtime = is_numeric($endtime) ? $endtime : strtotime($endtime . ' 23:59:59');
            $sql .= ' AND a.end_time <= :endtime ';
            $data[':endtime'] = $endtime;
        }
        
        if ($is_menu !== '') {
            $sql .= ' a.is_menu = ' . ($is_menu ? 1 : 0);
        }
        
        $currenttime = time();
        switch ($status) {
            case 1:
                $sql .= ' AND a.start_time > :currenttime ';
                $data[':currenttime'] = $currenttime;
                break;
            case 2:
                $sql .= ' AND a.start_time <= :currenttime ';
                $sql .= ' AND a.end_time >= :currenttime ';
                $data[':currenttime'] = $currenttime;
                break;
            case 3:
                $sql .= ' AND a.end_time < :currenttime ';
                $data[':currenttime'] = $currenttime;
                break;
            default:
                break;
        }

        $data = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchColumn(0);
        
        return $data ? $data : 0;
    }
    
    /**
     * 获取活动信息
     *
     * @param unknown $id
     * @return unknown
     */
    public function getActivityById($id) {
        $sql = 'SELECT * FROM `activity` WHERE id = :id';
        $data = [':id' => $id];
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }
    
    /**
     * 添加活动
     * 
     * @param unknown $is_menu
     * @param unknown $pid
     * @param unknown $name
     * @param unknown $url
     * @param unknown $start_time
     * @param unknown $end_time
     * @param unknown $rule_id
     * @param unknown $award_rule_id
     * @return boolean|string
     */
    public function addActivity($is_menu, $pid, $name, $url, $start_time, $end_time, $rule_id, $award_rule_id) {
        if ($is_menu) {
            $pid = 0;
            $rule_id = 0;
            $award_rule_id = 0;
        }
        
        if (!$is_menu && (!$rule_id || !$award_rule_id)) {
            return false;
        }
        
        if (!$name || !$url || !$start_time || !$end_time) {
            return false;
        }
        
        $sql = 'INSERT INTO `activity` (`is_menu`, `pid`, `name`, `url`, `start_time`, `end_time`, `rule_id`, `award_rule_id`, `create_time`) VALUES 
                (:is_menu, :pid, :name, :url, :start_time, :end_time, :rule_id, :award_rule_id, :create_time)';
        
        $data = [
            ':is_menu' => $is_menu ? 1 : 0, 
            ':pid' => $pid, 
            ':name' => $name,
            ':url' => $url, 
            ':start_time' => is_numeric($start_time) ? $start_time : strtotime($start_time), 
            ':end_time' => is_numeric($end_time) ? $end_time : strtotime($end_time), 
            ':rule_id' => $rule_id, 
            ':award_rule_id' => $award_rule_id,
            ':create_time' => time()
        ];

        $id = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
        
        if ($id)
            $this->dao->clearTag(self::$cache_tag);
        
        return $id ? $id : false;
    }
    
    /**
     * 编辑活动
     * 
     * @param unknown $id
     * @param unknown $is_menu
     * @param unknown $pid
     * @param unknown $name
     * @param unknown $url
     * @param unknown $start_time
     * @param unknown $end_time
     * @param unknown $rule_id
     * @param unknown $award_rule_id
     * @return boolean
     */
    public function editActivity($id, $is_menu, $pid, $name, $url, $start_time, $end_time, $rule_id, $award_rule_id) {
        if ($is_menu) {
            $pid = 0;
            $rule_id = 0;
            $award_rule_id = 0;
        }
        
        if (!$is_menu && (!$rule_id || !$award_rule_id)) {
            return false;
        }
        
        if (!$name || !$url || !$start_time || !$end_time) {
            return false;
        }
        
        $sql = 'UPDATE `activity` SET `is_menu` = :is_menu, `pid` = :pid, `name` = :name, `url` = :url, `start_time` = :start_time, `end_time` = :end_time, 
                `rule_id` = :rule_id, `award_rule_id` = :award_rule_id, `update_time` = :update_time WHERE id = :id';
        
        $data = [
            ':id' => $id,
            ':is_menu' => $is_menu ? 1 : 0,
            ':pid' => $pid,
            ':name' => $name,
            ':url' => $url,
            ':start_time' => is_numeric($start_time) ? $start_time : strtotime($start_time),
            ':end_time' => is_numeric($end_time) ? $end_time : strtotime($end_time),
            ':rule_id' => $rule_id,
            ':award_rule_id' => $award_rule_id,
            ':update_time' => time()
        ];
        
        $id = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->excute();
        
        if ($id)
            $this->dao->clearTag(self::$cache_tag);
            $this->dao->clearTag('Act_Award_');

        return $id ? $id : false;
    }
    
    /**
     * 获取活动分享设置
     * 
     * @param unknown $id
     * @return array|mixed|multitype:|unknown
     */
    public function getShareByActivityId($id) {
        $id = (int)$id;
        $sql = "SELECT * FROM `share` WHERE `target_table` = 'activity' AND `target_id` = {$id} AND `type` = 'wx'";
        
        $data = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, [])->fetchOne();
        
        return $data ? $data : [];
    }
    
    /**
     * 设置活动分享规则
     * 
     * @param unknown $id
     * @param unknown $icon
     * @param unknown $title
     * @param unknown $desc
     * @return boolean
     */
    public function setShare($id, $icon, $title, $desc) {
        $sql = "REPLACE INTO `share` (`target_table`, `target_id`, `type`, `icon`, `title`, `desc`) VALUES 
                ('activity', :target_id, 'wx', :icon, :title, :desc)";
        
        $data = [
            ':target_id' => $id, 
            ':icon' => $icon, 
            ':title' => $title, 
            ':desc' => $desc
        ];
        
        $data = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->excute();
        
        if ($data)
            $this->dao->clearTag(self::$cache_tag);
        
        return $data;
    }
    
    
}
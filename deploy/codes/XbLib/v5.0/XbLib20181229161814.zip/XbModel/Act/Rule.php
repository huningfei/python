<?php

class XbModel_Act_Rule extends XbModel_BaseModel {
    public static $cache_tag = "Act_Rule_";
    
    public static $cache_expire = 259200;
    
    public static $statusList = [
        '1' => '未使用',
        '2' => '使用中'
    ];
    
    public function __construct() {
        parent::_init("xb_act");
    }

    /**
     * 规则列表
     *
     * @param string $id
     * @param string $name
     * @param string $status
     * @param number $offset
     * @param number $limit
     * @return unknown
     */
    public function listRule($id = '', $name = '', $status = '', $offset = 0, $limit = 20) {
        $sql = 'SELECT * FROM `rule` WHERE 1 ';
        $data = [];
        if ($id) {
            $sql .= ' AND id = :id ';
            $data[':id'] = $id;
        }
        
        if ($name) {
            $sql .= ' AND name like :name ';
            $data[':name'] = "%{$name}%";
        }
        
        if ($status) {
            if ($status == 1) {
                $sql .= " AND `activity_id_list` = '' ";
            }
            else {
                $sql .= " AND `activity_id_list` <> '' ";
            }
        }
        
        $sql .= " ORDER BY id desc LIMIT {$offset},{$limit} ";

        $data = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
        
        return $data ? $data : [];
    }
    
    /**
     * 规则数量
     *
     * @param string $id
     * @param string $name
     * @param string $status
     * @return unknown
     */
    public function countRule($id = '', $name = '', $status = '') {
        $sql = 'SELECT COUNT(*) FROM `rule` WHERE 1 ';
        $data = [];
        if ($id) {
            $sql .= ' AND id = :id ';
            $data[':id'] = $id;
        }
        
        if ($name) {
            $sql .= ' AND name like :name ';
            $data[':name'] = "%{$name}%";
        }
        
        if ($status) {
            if ($status == 1) {
                $sql .= " AND `activity_id_list` = '' ";
            }
            else {
                $sql .= " AND `activity_id_list` <> '' ";
            }
        }
        
        $data = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchColumn(0);
        
        return $data ? $data : 0;
    }
    
    /**
     * 获取活动规则
     *
     * @param unknown $id
     * @return unknown
     */
    public function getRuleById($id) {
        $id = (int)$id;
        $sql = 'SELECT * FROM `rule` WHERE id = ' . $id;
        $data = [];

        $data = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
        
        return $data;
    }
    
    /**
     * 创建规则
     * 
     * @param unknown $id
     * @param unknown $name
     * @param unknown $rule_type_id
     * @return boolean|string
     */
    public function addRule($name, $rule_type_id) {
        $sql = 'INSERT INTO `rule` (`name`, `rule_type_id`, `activity_id_list`, `create_time`, `update_time`) 
                VALUES (:name, :rule_type_id, :activity_id_list, :create_time, :update_time)';
        
        $data = [
            ':name' => $name,
            ':rule_type_id' => $rule_type_id,
            ':activity_id_list' => '',
            ':create_time' => time(), 
            ':update_time' => 0
        ];
        
        $id = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
        
        if ($id)
            $this->dao->clearTag(self::$cache_tag);
        
        return $id ? $id : false;
    }
    
    /**
     * 编辑规则
     * 
     * @param unknown $id
     * @param unknown $name
     * @param unknown $rule_type_id
     * @param unknown $activity_id_list
     * @return boolean
     */
    public function editRule($id, $name = null, $rule_type_id = null, $activity_id_list = null) {
        $sql = 'UPDATE `rule` SET `update_time` = ' . time();
        $data = [];
        
        if ($name !== null) {
            $sql .= ', `name` = :name ';
            $data[':name'] = $name;
        }
        
        if ($rule_type_id !== null) {
            $sql .= ', `rule_type_id` = :rule_type_id ';
            $data[':rule_type_id'] = $rule_type_id;
        }
        
        if ($activity_id_list !== null) {
            $sql .= ', `activity_id_list` = :activity_id_list ';
            $data[':activity_id_list'] = $activity_id_list;
        }
        
        $sql .= ' WHERE id = :id';
        $data[':id'] = $id;
        
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->excute();
        
        if ($res)
            $this->dao->clearTag(self::$cache_tag);
        
        return $res ? $res : false;
        
    }
    
    /**
     * 更新策略使用状态
     *
     * @param unknown $rule_id
     */
    public function updateActivityIdList($rule_id) {
        $rule_id = (int)$rule_id;
        if (!$rule_id) {
            return false;
        }
        
        $sql = 'SELECT id FROM `activity` WHERE rule_id = ' . $rule_id;
        $data = $this->dao->conn(false)->noCache()->preparedSql($sql, [])->fetchAll();
        
        $id_list = [];
        foreach ($data as $item) {
            $id_list[] = $item['id'];
        }
        
        return $this->editRule($rule_id, null, null, implode(',', $id_list));
    }
    
    /**
     * 删除规则
     * 
     * @param unknown $id
     * @return boolean
     */
    public function deleteRule($id) {
        $id = (int)$id;
        $sql = 'DELETE FROM  `rule` WHERE id = ' . $id;

        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, [])->excute();
        
        if ($res)
            $this->dao->clearTag(self::$cache_tag);
        
        return $res ? $res : false;
    }
    
}
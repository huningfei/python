<?php
/**
 * @desc  奖励管理
 * User: zq
 * Date: 4/6/18
 * Time: 15:33
 */
class XbModel_Act_Award extends XbModel_BaseModel{
    static $cache_tag = "Act_Award_";

    //链接库
    function __construct() {
        parent::_init("xb_act");
    }

    /**
     * @desc 获取奖励策略管理列表
     * @param    int       $id          id
     * @param    string    $title       奖励名称
     * @param    int       $award_type  奖励类型
     * @return   array     $return      返回执行结果
     * */
    public  function getList($id, $title, $award_type, $page){
        $sql_search = "select * from `award` WHERE 1=1";
        $sql_count  = "select count(*) as count from `award` where  1=1";
        $sql = '';
        $param = [];
        if($id){
            $sql .= " AND `id` = :id";
            $param[':id'] = $id;
        }
        if($title){
            $sql .= " AND `title` LIKE :title";
            $param[':title'] = "%{$title}%";
        }
        if($award_type){
            $sql .= " AND `award_type`=:award_type";
            $param[':award_type'] = $award_type;
        }
        if(isset($page['offset']) && isset($page['limit'])){
            $sql .=" limit :offset,:limit";
            $param[':offset'] = $page['offset'];
            $param[':limit']  = $page['limit'];
            $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_search.$sql,$param)->fetchAll();
        } else {
            $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_count.$sql,$param)->fetchOne()['count'];
        }
        return $res;

    }

    /**
     * @desc 根据奖励id获取活动
     * @param    int       $award_id        award_id
     * @return   array     $return          返回执行结果
     * */
    public function getActivityByAwardId($award_id) {
        $sql_search = "select * from `activity` WHERE award_rule_id = $award_id";
        $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_search, array())->fetchOne();
        return $res;
    }

    /**
     * @desc 根据act_id获取活动与奖励
     * @param    int       $act_id          act_id
     * @return   array     $return          返回执行结果
     * */
    public function getActAwardByActId($act_id) {
        $sql_search = "select a.*,b.act_type,b.money_type,b.money,b.dead_type,b.dead_time,b.dead_day from `activity` a LEFT JOIN `award` b on a.award_rule_id = b.id WHERE a.id = $act_id";
        $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_search, array())->fetchOne();
        return $res;
    }

    /**
     * @desc 获取一行奖励管理记录
     * @param    int       $id          id
     * @return   array     $return      返回执行结果
     * */
    public function getAwardById($id){
        $sql_search = "select * from `award` WHERE id = $id";
        $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_search,[])->fetchOne();
        return $res;
    }

    /**
     * @desc 修改奖励策略
     * @param    int       $param       参数
     * @return   array     $return      返回执行结果
     * */
    public function edit($id, $title, $award_type, $money_type, $money, $dead_type, $dead_time, $dead_day, $act_type, $description){
        $param = compact('id', 'title', 'award_type', 'money_type', 'money', 'dead_type', 'dead_time', 'dead_day', 'act_type','description');
        $sql = 'UPDATE `award` set `title`=:title,`award_type`=:award_type,`money_type`=:money_type,`money`=:money,`dead_type`=:dead_type,`dead_time`=:dead_time,`dead_day`=:dead_day,`act_type`=:act_type,`description`=:description WHERE `id`=:id';
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql,$param)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /**
     * @desc 新增奖励策略
     * @param    array     $param       参数
     * @return   array     $return      返回执行结果
     * */
    public function add($title, $award_type, $money_type, $money, $dead_type, $dead_time, $dead_day, $act_type,$description){
        $param = compact('title', 'award_type', 'money_type', 'money', 'dead_type', 'dead_time', 'dead_day', 'act_type','description');
        $param['create_time']   = time();
        $sql = 'INSERT INTO  `award`(`title`,`award_type`,`money_type`,`money`,`dead_type`,`dead_time`,`dead_day`,`act_type`,`description`,`create_time`) values(:title,:award_type,:money_type,:money,:dead_type,:dead_time,:dead_day,:act_type,:description,:create_time)';
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql,$param)->lastInsertId();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }


    /**
     * @desc 获取用户奖励记录列表
     * @param    int       $id          id
     * @param    string    $title       奖励名称
     * @param    int       $award_type  奖励类型
     * @return   array     $return      返回执行结果
     * */
    public  function getItemList($award_id, $title, $award_type, $phone, $item_state, $start_time, $end_time, $page){
        $sql_search = "select a.*,b.title,b.award_type from `award_item` a ";
        $sql_count  = "select count(a.award_id) as count from `award_item` a";
        $sql = ' LEFT JOIN `award` b ON a.award_id = b.id where  1=1';
        $param = [];
        if ($award_id) {
            $sql .= " AND `award_id`=:award_id";
            $param[':award_id'] = $award_id;
        }
        if($title){
            $sql .= " AND `title` LIKE :title";
            $param[':title'] = "%{$title}%";
        }
        if($award_type){
            $sql .= " AND `award_type`=:award_type";
            $param[':award_type'] = $award_type;
        }
        if($phone){
            $user = XbModule_Account_Users::getInstance()->getUserByPhone($phone);
            if ($user){
                $sql .= " AND `uid`=:uid";
                $param[':uid'] = $user['id'];
            } else {
                $sql .= " AND uid='' ";
            }
        }
        if($item_state){
            if ($item_state ==1 || $item_state ==3) {
                if ($item_state == 1){
                    $sql .= " AND `deadline`>:now_time";
                } elseif ($item_state == 3) {
                    $sql .= " AND `deadline`<=:now_time";
                }
                $param[':now_time'] = time();
                $item_state = 1;
            }

            $sql .= " AND `item_state`=:item_state";
            $param[':item_state'] = $item_state;
        }
        if($start_time){
            $sql .= " AND a.`create_time` >= :start_time";
            $param[':start_time'] = strtotime($start_time.' 00:00:00');
        }
        if($end_time){
            $sql .= " AND a.`create_time`<:end_time";
            $param[':end_time'] = strtotime($end_time.' 23:59:59');
        }
        $sql .= " ORDER BY a.id desc ";
        if(isset($page['offset']) && isset($page['limit'])){
            $sql .=" limit :offset,:limit ";
            $param[':offset'] = $page['offset'];
            $param[':limit']  = $page['limit'];

            $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_search.$sql,$param)->fetchAll();
        } else {
            $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_count.$sql,$param)->fetchOne()['count'];
        }
        return $res;

    }

    /**
     * @desc 计算红包
     * @param    int       $act_log_id  act_log_id
     * @return   array     $return      返回执行结果
     * */
    public function computeAward($act_log_id){
        $sql_actlog = "select * from `activity_log` where id = $act_log_id";
        $res_actlog = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_actlog,array())->fetchOne();
        if (!$res_actlog) {
            XbFunc_Log::write('sendAward',"红包计算失败:没有查到 log_id=".$act_log_id);
            return false;
        }
        if ($res_actlog['status'] != 1) {
            XbFunc_Log::write('sendAward',"红包计算失败:该log_id已经发过红包了 log_id=".$act_log_id);
            return false;
        }
        $res_act_award = XbModule_Act_Award::getInstance()->getActAwardByActId($res_actlog['activity_id']);
        if (!$res_act_award) {
            XbFunc_Log::write('sendAward',"红包计算失败:没有查到活动信息 log_id=".$act_log_id);
            return false;
        }

        $res_arr['uid'] =  $res_actlog['user_id'];
        $res_arr['act_id'] = $res_act_award['id'];
        $res_arr['act_name'] = $res_act_award['name'];
        $res_arr['award_id'] = $res_act_award['award_rule_id'];
        $res_arr['act_type'] = $res_act_award['act_type'];
        $res_arr['order_no'] =  $res_actlog['order_id'];
        $res_arr['money'] = 0;
        $res_arr['deadline'] = 0;
        $res_arr['state'] = $res_actlog['status'];
        $params = unserialize($res_actlog['params']);
        $res_arr['param'] =  $res_actlog['params'];
        if ($res_act_award['act_type'] == 1){
            //办卡返现
            $award_money = $res_act_award['money'];
        } elseif ($res_act_award['act_type'] == 2) {
            //收款减手续费
            $mch_id = XbModule_Account_Users::getInstance()->getUserById($res_actlog['user_id'])['mch_id'];
            $res_order = XbModule_Account_Order::getInstance($mch_id)->getOrderByOrderid($res_actlog['order_id']);
            $rate = $res_order['rate'];
            $single_fee = $res_order['single_fee'];
            $sum = $params['free_for_amount'];
            $award_money = round(($sum * $rate) + $single_fee, 2);
        }
        if ($res_act_award['money_type'] == 1){
            //固定金额奖励
            $res_arr['money'] = $award_money;
        } elseif ($res_act_award['money_type'] == 2){
            //收款免费率红包
            $res_arr['money'] = $award_money;
        }
        if ($res_act_award['dead_type'] == 1){
            //统一过期时间
            $res_arr['deadline'] = $res_act_award['dead_time'];
        } elseif ($res_act_award['dead_type'] == 2){
            //几天后过期
            $res_arr['deadline'] = time() + $res_act_award['dead_day']*24*60*60;
        }

        $log_arr = array(array('state'=>'已获得','time'=>time()));
        $res_arr['log'] = json_encode($log_arr, JSON_UNESCAPED_UNICODE);

        return $res_arr;
    }

    /**
     * @desc 发奖励
     * @param    int       $award_id    奖励id
     * @param    int       $uid         uid
     * @param    int       $order_no    订单号
     * @param    int       $item_state  奖励状态
     * @param    int       $money       奖励金额
     * @param    string    $log         领取日志
     * @param    int       $deadline    到期时间
     * @return   array     $return      返回执行结果
     * */
    public function sendAward($act_log_id,$award_id, $uid, $order_no, $item_state, $money, $log, $deadline){
        $this->dao->conn(false)->beginTransaction();

        $sql = 'INSERT INTO  `award_item` (`award_id`,`uid`,`order_no`,`item_state`,`money`,`log`,`deadline`,`create_time`) values (:award_id,:uid,:order_no,:item_state,:money,:log,:deadline,:create_time)';
        $param = compact('award_id', 'uid', 'order_no', 'item_state', 'money', 'log', 'deadline');
        $param['create_time']   = time();
        $res = $this->dao->noCache()->preparedSql($sql,$param)->lastInsertId();
        if(!$res){
            $this->dao->rollback();
            XbFunc_Log::write('sendAward',"红包发送失败:".$sql." ".json_encode($param, JSON_UNESCAPED_UNICODE));
        }

        $sql_act_log = 'UPDATE `activity_log` SET `status`=2  WHERE `id`=:act_log_id';
        $param_act_log = array('act_log_id'=>$act_log_id);
        $res_act_log = $this->dao->noCache()->preparedSql($sql_act_log,$param_act_log)->affectedCount();
        if(!$res_act_log){
            $this->dao->rollback();
            XbFunc_Log::write('sendAward',"红包发送失败:".$sql_act_log." ".json_encode($param_act_log, JSON_UNESCAPED_UNICODE));
        }

        $res_commit = $this->dao->commit();

        if($res_commit){
            $this->dao->clearTag(self::$cache_tag);
            $this->dao->clearTag('Act_Award_Item_');
            XbFunc_Log::write('sendAward',"红包发送成功:".$sql." ".json_encode($param, JSON_UNESCAPED_UNICODE).$sql_act_log." ".json_encode($param_act_log, JSON_UNESCAPED_UNICODE));
            return $res;
        } else {
            return false;
        }
    }

    /**
     * @desc 用户领红包
     * @param    int       $uid             uid
     * @param    int       $award_item_id   用户领取记录id
     * @return   array     $return          返回执行结果
     * */
    public function gainAward($mch_id, $uid, $award_item_id){
        $sql_search = "select a.*,b.title,b.award_type,b.act_type from `award_item` a LEFT JOIN `award` b ON a.award_id = b.id  where a.id = $award_item_id";
        $res_search = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_search,array())->fetchOne();

        if (!$res_search){
            XbFunc_Log::write('gainAward',"红包领取失败:".$res_search['id']." 没有查询到红包");
            return false;
        }
        if ($res_search['uid'] != $uid){
            XbFunc_Log::write('gainAward',"红包领取失败:".$res_search['id']." 当前用户".$res_search['uid']."不可领取");
            return false;
        }
        if ($res_search['item_state'] != 1){
            XbFunc_Log::write('gainAward',"红包领取失败:".$res_search['id']." 红包状态为".$res_search['item_state']);
            return false;
        }
        if ($res_search['deadline'] < time()){
            XbFunc_Log::write('gainAward',"红包领取失败:".$res_search['id']." 红包已过期");
            return false;
        }

        $this->dao->conn(false)->beginTransaction();

        $log_arr = json_decode($res_search['log']);
        $log_arr[] = array('state'=>"已使用","time"=>time());
        $log = json_encode($log_arr, JSON_UNESCAPED_UNICODE);
        //修改红包领取记录状态
        $sql_award = "UPDATE `award_item` SET `item_state`=2,log=:log WHERE id = :id";
        $param_award = array('log'=>$log,'id'=>$res_search['id']);
        $res_award = $this->dao->noCache()->preparedSql($sql_award,$param_award)->affectedCount();
        if(!$res_award){
            $this->dao->rollback();
            XbFunc_Log::write('gainAward',"红包领取失败:修改award_item表失败".$sql_award." ".json_encode($param_award, JSON_UNESCAPED_UNICODE));
            return false;
        }

        //修改订单表状态
        if ($res_search['act_type'] == 1){
            $sql_order = 'UPDATE xb_account.`users_apply_bank` SET `award_state`=1 WHERE `order_id`=:order_id';
            $param_order = array('order_id'=>$res_search['order_no']);
            $res_order = $this->dao->noCache()->preparedSql($sql_order,$param_order)->affectedCount();
            $profit_type = 4;
        } elseif ($res_search['act_type'] == 2){
            $sql_order = 'UPDATE xb_account.`order_'.$mch_id.'` SET `act_fee`=`act_fee`+:act_fee WHERE `order_id`=:order_id';
            $param_order = array('act_fee'=>$res_search['money'],'order_id'=>$res_search['order_no']);
            $res_order = $this->dao->noCache()->preparedSql($sql_order,$param_order)->affectedCount();
            $profit_type = 3;
        }
        if(!$res_order){
            $this->dao->rollback();
            XbFunc_Log::write('gainAward',"红包领取失败:修改order表失败".$sql_order." ".json_encode($param_order, JSON_UNESCAPED_UNICODE));
            return false;
        }
        $order_id = XbModule_Account_OrderCode::getInstance()->getOrderCode();

        //插入返现表数据
        $sql_profit_search = "select surplus_amount from xb_account.`profit_".$mch_id."` where uid = $uid order by id desc limit 1";
        $res_profit_search = $this->dao->noCache()->preparedSql($sql_profit_search,array())->fetchOne();
        $surplus_amount = $res_profit_search['surplus_amount'] ? $res_profit_search['surplus_amount'] : 0;

        $sql_profit = 'INSERT INTO xb_account.`profit_'.$mch_id.'` (`uid`,`order_id`,`reference_no`,`amount`,`surplus_amount`,`type`,`title`,`created_at`,`create_time`) VALUES (:uid,:order_id,:reference_no,:amount,:surplus_amount,:type,:title,:created_at,:create_time)';
        $param_profit = array(
                            'uid'         => $uid,
                            'order_id'    => $order_id,
                            'reference_no'=> $res_search['order_no'],
                            'amount'      => $res_search['money'],
                            'surplus_amount' => $res_search['money'] + $surplus_amount,
                            'type'        => $profit_type,
                            'title'       => $res_search['title'],
                            'created_at'  => $res_search['create_time'],
                            'create_time' => time()
                        );
        try {
            $res_profit = $this->dao->noCache()->preparedSql($sql_profit,$param_profit)->affectedCount();
        } catch (Exception $e) {
            XbFunc_Log::write('gainAward',"红包领取失败:修改profit表失败".$e->getMessage());
        }
        if(!$res_profit){
            $this->dao->rollback();
            XbFunc_Log::write('gainAward',"红包领取失败:修改profit表失败".$sql_profit." ".json_encode($param_profit, JSON_UNESCAPED_UNICODE));
            return false;
        }

        //增加用户余额表用户余额
        $sql_wallet = 'UPDATE xb_account.`users_wallet` SET `profit_amount`=`profit_amount`+:money  WHERE `uid`=:uid';
        $param_wallet = array('money'=>$res_search['money'],'uid'=>$uid);
        $res_wallet = $this->dao->noCache()->preparedSql($sql_wallet,$param_wallet)->affectedCount();
        if(!$res_wallet){
            $this->dao->rollback();
            XbFunc_Log::write('gainAward',"红包领取失败:修改users_wallet表失败".$sql_wallet." ".json_encode($param_wallet, JSON_UNESCAPED_UNICODE));
            return false;
        }

        $res = $this->dao->commit();
        if ($res){
            $this->dao->clearTag(self::$cache_tag);
            $this->dao->clearTag('Act_Award_Item_');
            XbFunc_Log::write('gainAward',"红包领取成功:uid-{$uid} award_item_id-$award_item_id");
        } else {
            XbFunc_Log::write('gainAward',"红包领取失败:uid-{$uid} award_item_id-$award_item_id");
        }
        return $res;

    }

    /**
     * @desc 根据uid与act_id查询漏发红包用户
     * @param    int       $uid             uid
     * @param    int       $act_id          act_id
     * @return   array     $return          返回执行结果
     * */
    public function getReissue($uid,$act_id){
        $sql_search = "select * from `activity_log` where user_id = $uid and `activity_id` = $act_id";
        $res_search = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_search,array())->fetchAll();
        return $res_search;
    }

    /**
     * @desc 撤回红包
     * @param     int      $id         红包记录id
     * @return    array    $return     返回执行结果
     * */
    public function recallAward($item_id){
        $sql_search = "select * from `award_item` WHERE `id`=$item_id";
        $res_search = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_search,array())->fetchOne();

        $log_arr = json_decode($res_search['log']);

        if ($res_search['item_state'] == 1){
            //已获得
            $log_arr[] = array('state'=>"已撤回","time"=>time());
            $log = json_encode($log_arr, JSON_UNESCAPED_UNICODE);
            $sql_recall = "UPDATE `award_item` SET `item_state`=4,`log`=:log,`recall_state`=1  WHERE `id`=:id";
            $param_recall = array('id'=>$res_search['id'],'log'=>$log);
            $res_recall = $this->dao->noCache(false)->preparedSql($sql_recall,$param_recall)->affectedCount();
            if(!$res_recall){
                XbFunc_Log::write('recallAward',"已获得红包撤回失败:id-{$res_search['id']} uid-{$res_search['uid']}修改award_item表失败".$sql_recall." ".json_encode($param_recall, JSON_UNESCAPED_UNICODE));
                return false;
            } else {
                $this->dao->clearTag(self::$cache_tag);
                $this->dao->clearTag('Act_Award_Item_');
                XbFunc_Log::write('recallAward',"已获得红包撤回成功:id-{$res_search['id']} uid-{$res_search['uid']}修改award_item表成功".$sql_recall." ".json_encode($param_recall, JSON_UNESCAPED_UNICODE));
                return true;
            }
        } elseif ($res_search['item_state'] == 2){
            //已使用
            $sql_select_wallet = "select * from xb_account.`users_wallet` WHERE `uid`={$res_search['uid']}";
            $res_select_wallet = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_select_wallet,array())->fetchOne();

            $this->dao->conn(false)->beginTransaction();
            if ($res_select_wallet['profit_amount'] >= $res_search['money']){
                //余额足够撤回
                $sql_wallet = 'UPDATE xb_account.`users_wallet` SET `profit_amount`=`profit_amount`-:money  WHERE `uid`=:uid';
                $param_wallet = array('uid'=>$res_search['uid'],'money'=>$res_search['money']);
                $res_wallet = $this->dao->noCache()->preparedSql($sql_wallet,$param_wallet)->affectedCount();
                if(!$res_wallet){
                    $this->dao->rollback();
                }
                $recall_state = 1;
                $log_arr[] = array('state'=>"已撤回","time"=>time());
                $log = json_encode($log_arr, JSON_UNESCAPED_UNICODE);
            } else {
                //余额不足
                $recall_state = 2;
                $log_arr[] = array('state'=>"撤回失败,余额不足","time"=>time());
                $log = json_encode($log_arr, JSON_UNESCAPED_UNICODE);
            }
            $sql_recall = "UPDATE `award_item` SET `item_state`=4,`log`=:log,`recall_state`=:recall_state  WHERE `id`=:id";
            $param_recall = array('id'=>$res_search['id'],'log'=>$log,'recall_state'=>$recall_state);
            $res_recall = $this->dao->noCache()->preparedSql($sql_recall,$param_recall)->affectedCount();
            if(!$res_recall){
                $this->dao->rollback();
            }
            $res_commit = $this->dao->commit();
            if ($res_commit) {
                $this->dao->clearTag(self::$cache_tag);
                $this->dao->clearTag('Act_Award_Item_');
                XbFunc_Log::write('recallAward',"已使用红包撤回成功:id-{$res_search['id']} uid-{$res_search['uid']}修改award_item表".$sql_recall." ".json_encode($param_recall, JSON_UNESCAPED_UNICODE)."修改users_wallet表".$sql_wallet." ".json_encode($param_wallet, JSON_UNESCAPED_UNICODE));
                return true;
            } else {
                XbFunc_Log::write('recallAward',"已使用红包撤回失败:id-{$res_search['id']} uid-{$res_search['uid']}修改award_item表".$sql_recall." ".json_encode($param_recall, JSON_UNESCAPED_UNICODE)."修改users_wallet表".$sql_wallet." ".json_encode($param_wallet, JSON_UNESCAPED_UNICODE));
                return false;
            }
        } else {
            XbFunc_Log::write('recallAward',"红包撤回失败:id-{$res_search['id']} uid-{$res_search['uid']}红包记录状态不是已获得且不是已使用");
            return false;
        }
    }
}
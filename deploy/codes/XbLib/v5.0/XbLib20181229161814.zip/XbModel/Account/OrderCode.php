<?php
/**
 * Created by PhpStorm.
 * User: yurong
 * Date: 2018/5/14
 * Time: 下午3:20
 */
class XbModel_Account_OrderCode extends XbModel_BaseModel{
    public static $cache_tag = "Account_Order_Code";
    public static $cache_expire = 259200;
    function __construct() {
        parent::_init("xb_account");
    }
    //获取code码
    public function getOrderCode(){
        $now = time();
        $sql = "INSERT INTO order_serial (create_time) values ({$now})";
        $insertId = $this->dao->conn(false)->noCache()->preparedSql($sql,array())->lastInsertId();
        if(!$insertId){
            return false;
        }
        $sql = "SELECT * FROM order_code WHERE id={$insertId}";
        $order_code = $this->dao->conn(false)->noCache()->preparedSql($sql,array())->fetchOne();
        if(!$order_code){
            $order_id = $this->createOrder();
            return $order_id;
        }
        return $order_code['code'];
    }
    //创建单个订单号
    public function createOrder(){
        $build = true;
        $factory = new RandomLib\Factory();
        $generator = $factory->getGenerator(new SecurityLib\Strength());
        while ($build) {
            $order_id = $generator->generateString(19, "1234567890");            //检查是否重复
            //检查是否重复
            $getsql = "SELECT id FROM `order_code` WHERE `code`=:code ";
            $getdata = [
                ':code'  => $order_id
            ];
            $codedata = $this->dao->conn(false)->noCache()->preparedSql($getsql, $getdata)->fetchOne();
            if (empty($codedata)) {
                $build =false;
            }
        }
        $sql = "insert into order_code values (null,'{$order_id}')";
        $res =  $this->dao->conn(false)->noCache()->preparedSql($sql, array())->lastInsertId();
        if($res){
            return $order_id;
        }
    }
}
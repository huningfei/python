<?php
class XbModel_Account_Merchant extends XbModel_BaseModel{
    static $cache_tag = "Account_Merchant_";

    //链接库
    function __construct() {
        parent::_init("xb_account");
    }

    /**
     * @desc 获取所有地区
     * @return   array     $return      返回执行结果
     * */
    public function getDistrict(){
        $sql = "select * from `common_district`";
        $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,array())->fetchAll();
        return $res;
    }

    /**
     * @desc 获取所有商户类型
     * @return   array     $return      返回执行结果
     * */
    public function getMerchantType(){
        $sql = "select * from `common_merchant_type`";
        $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,array())->fetchAll();
        return $res;
    }

    /**
     * @desc 获取商户列表
     * @param    int       $aisle       通道
     * @param    int       $district_id 地区id
     * @param    int       $merchant_type_id  商户类型
     * @return   array     $return      返回执行结果
     * */
    public function getMerchant($aisle, $district_id, $merchant_type_id, $page){
        $sql_search = "select * from `common_merchant` WHERE 1=1";
        $sql = '';
        $param = [];
        if($aisle){
            $sql .= " AND `aisle` = :aisle";
            $param['aisle'] = $aisle;
        }
        if($district_id){
            $sql .= " AND `district_id` = :district_id";
            $param['district_id'] = $district_id;
        }
        if($merchant_type_id){
            $sql .= " AND `merchant_type_id` = :merchant_type_id";
            $param['merchant_type_id'] = $merchant_type_id;
        }
        if(isset($page['offset']) && isset($page['limit'])){
            $sql .=" limit :offset,:limit";
            $param[':offset'] = $page['offset'];
            $param[':limit']  = $page['limit'];
            $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_search.$sql,$param)->fetchAll();
        } else {
            $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_search.$sql,$param)->fetchAll();
        }
        return $res;
    }

    /**
     * @desc 获取商户
     * @param    int       $id          商户id
     * @return   array     $return      返回执行结果
     * */
    public function getMerchantById($id){
        $sql = "select * from `common_merchant` WHERE id=:id";
        $param[':id'] = $id;
        $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $param)->fetchOne();
        return $res;
    }

    /**
     * @desc 根据id获取商户
     * @param    int       $district_id  地区id
     * @return   array     $return      返回执行结果
     * */
    public function getMerchantByDistrict($district_id){
        $sql_count = "select count(*) as count_num from `common_merchant` WHERE district_id=:district_id";
        $param[':district_id'] = $district_id;
        $res_count = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_count, $param)->fetchOne()['count_num'];
        $num = rand(1, $res_count);

        $sql = "select * from `common_merchant` WHERE district_id=:district_id LIMIT :num,1";
        $param[':num'] = $num;
        $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $param)->fetchOne();
        return $res;
    }

    /**
     * @desc 脚本插入商户信息
     * @param    string    $sql         sql
     * @return   array     $return      返回执行结果
     * */
    public function addMerchantSql($sql){
        try{
            $res = $this->dao->conn(false)->noCache()->preparedSql($sql,array())->lastInsertId();
        }catch (Exception $e){
            XbFunc_Log::write('merchant_create','创建商户信息sql报错 ', $sql . ' ' . $e->getMessage());
        }

        return $res;
    }
}

<?php
/**
 * @desc    添加信用卡
 * @author  qien
 * @date    17.12.21
 */

class XbModel_Account_CreditCard extends XbModel_BaseModel{
    static $cache_tag = "Account_CreditCard_";

    //链接库
    function __construct() {
        parent::_init("xb_account");
    }
    /**
     * @desc    增加信用卡
     * @param   int     $uid        用户id
     * @param   string  $bank       银行名称
     * @param   string  $bankCode   银行编码
     * @param   string  $cardNumber 信用卡号
     * @param   string  $telephone  信用卡
     * @param   string  $mch_code   用户mch_code
     * @return  boolen  $return     返回执行结果
     */
    public function addCreditCard($uid, $bank, $bankCode, $cardNumber, $telephone){
        $time = time();
        $this->dao->conn(false)->beginTransaction();
        $sql = 'INSERT INTO `users_creditcard`(`uid`, `bank`, `bankCode`, `cardNumber`, `telephone`, `create_time`) VALUES(:uid, :bank, :bankCode, :cardNumber, :telephone, :create_time)';
        $data = array(
            ':uid'        => $uid,
            ':bank'       => $bank,
            ':bankCode'   => $bankCode,
            ':cardNumber' => $cardNumber,
            ':telephone'  => $telephone,
            ':create_time'=> $time
        );
        $res = $this->dao->noCache()->preparedSql($sql, $data)->lastInsertId();
        if(!$res){
            $this->dao->rollback();
            return false;
        }
        return $this->dao->commit();
    }

    /**
     * @desc    根据id查询信用卡信息
     * @param   int     $id
     * @return  array   $return
     */
    public function getInfoById($id){
        $sql = 'SELECT * FROM `users_creditcard` WHERE `id`=:id';
        $data = array(
            ':id' => $id
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    修改信用卡cvv与有效期
     * @param   int     $id
     * @param   int     $cvv
     * @param   int     $validDate
     * @return  array   $return
     */
    public function updateCardCvv($id, $uid, $cvv, $validDate){
        $sql = 'UPDATE `users_creditcard` SET `cvv`=:cvv, `validDate`=:validDate WHERE `uid`=:uid AND `id`=:cid';
        $data = array(
            ':cvv'         => $cvv,
            ':validDate'   => $validDate,
            ':uid'         => $uid,
            ':cid'         => $id
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /**
     * @desc    根据卡号查询信息
     * @param   string  $cardNumber     银行卡号
     * @return  array   $return         返回搜索结果
     */
    public function getInfoByCardNumber($cardNumber){
        $sql = "SELECT * FROM `users_creditcard` WHERE `cardNumber`=:cardNumber";
        $data = array(
            ':cardNumber' => $cardNumber
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    删除信用卡
     * @param   int     $uid    用户id
     * @param   string   $cardId 卡号id
     * @return  array   $return 返回执行结果
     */
    public function delCreditCard($uid, $cardId){
        $sql = 'DELETE FROM `users_creditcard` WHERE `uid`=:uid AND `id`=:id';
        $data = array(
            ':uid' => $uid,
            ':id'  => $cardId
        );
         $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
         if($res){
             $this->dao->clearTag(self::$cache_tag);
         }
         return $res;
    }

    /**
     * @desc    统计用户信用卡
     * @param   int     $uid    用户id
     * @return  int     $return
     */
    public function countCreditCard($uid){
        $sql = "SELECT COUNT(*) AS num FROM `users_creditcard` WHERE `uid`=:uid";
        $data = array(
            ':uid' => $uid
        );
        $res = $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
        return $res['num'];
    }

    /**
     * @desc    获取用户所有信用卡信息
     * @param   int     $uid      用户id
     * @param   int     $start    偏移量
     * @param   int     $limit    条数
     * @return  array   $return   返回搜索结果
     */
    public function getAllCreditCard($uid,$start,$limit,$type){
        $sql = "SELECT * FROM `users_creditcard` WHERE `uid`=:uid";
        $data=array(
            ':uid'   =>$uid
        );
        if($type){
            $sql .=' LIMIT :start,:limit';
            $data[':start'] = $start;
            $data[':limit'] = $limit;
        }

        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    获取用户未添加还款资料的信用卡
     * @param   int     $uid    用户uid
     * @param   int     $status 信用卡状态
     * @return  array   $return 用户信用卡信息
     */
    public function getRepaymentCreditCard($uid, $status){
        $sql = "SELECT * FROM `users_creditcard` WHERE `uid`=:uid AND `status`=:status";
        $data=array(
            ':uid'    => $uid,
            ':status' => $status
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    添加信用卡信息
     * @param   int     $cid            信用卡id
     * @param   int     $uid            用户uid
     * @param   int     $cardDate       信用卡日期
     * @param   int     $cvv            信用卡验证后三位
     * @param   int     $billDate       信用卡账单日
     * @param   int     $payDate        信用卡还款日
     * @param   int     $amountLimit    信用卡额度
     * @return  boolen  $return         返回执行情况
     */
    public function addRepaymentInfo($cid, $uid, $cardDate, $cvv, $billDate, $payDate, $amountLimit){
        $time = time();
        $sql = 'UPDATE `users_creditcard` SET `cvv`=:cvv, `validDate`=:validDate, `billDate`=:billDate, `payDate`=:payDate, `amountLimit`=:amountLimit, `status`=:status, `update_time`=:update_time, `repay_time`=:repay_time WHERE `uid`=:uid AND `id`=:cid';
        $data = array(
            ':cvv'         => $cvv,
            ':validDate'   => $cardDate,
            ':billDate'    => $billDate,
            ':payDate'     => $payDate,
            ':amountLimit' => $amountLimit,
            ':status'      => 1,
            ':update_time' => $time,
            ':repay_time'  => $time,
            ':uid'         => $uid,
            ':cid'         => $cid
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /**
     * @desc    删除还款信用卡信息
     */
    public function delRepaymentInfo($uid, $cid){
        $time = time();
        $sql = 'UPDATE `users_creditcard` SET `cvv`=:cvv, `validDate`=:validDate, `billDate`=:billDate, `payDate`=:payDate, `amountLimit`=:amountLimit, `status`=:status, `update_time`=:update_time WHERE `uid`=:uid AND `id`=:cid';
        $data = array(
            ':cvv'         => 0,
            ':validDate'   => 0,
            ':billDate'    => 0,
            ':payDate'     => 0,
            ':amountLimit' => 0,
            ':status'      => 0,
            ':update_time' => $time,
            ':uid'         => $uid,
            ':cid'         => $cid
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /**
     * @desc    添加信用卡信息
     * @param   int     $cid            信用卡id
     * @param   int     $uid            用户uid
     * @param   int     $billDate       信用卡账单日
     * @param   int     $payDate        信用卡还款日
     * @param   int     $amountLimit    信用卡额度
     * @return  boolen  $return         返回执行情况
     */
    public function updateRepaymentInfo($cid, $uid, $billDate, $payDate, $amountLimit){
        $time = time();
        $sql = 'UPDATE `users_creditcard` SET `billDate`=:billDate, `payDate`=:payDate, `amountLimit`=:amountLimit, `update_time`=:update_time WHERE `uid`=:uid AND `id`=:cid';
        $data = array(
            ':billDate'    => $billDate,
            ':payDate'     => $payDate,
            ':amountLimit' => $amountLimit,
            ':update_time' => $time,
            ':uid'         => $uid,
            ':cid'         => $cid
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /**
     * @desc    修改信用卡还款提醒
     */
    public function updateRepaymentWarn($cid, $uid, $status){
        $time = time();
        $sql = 'UPDATE `users_creditcard` SET `repaymentWarn`=:repaymentWarn, `update_time`=:update_time WHERE `uid`=:uid AND `id`=:cid';
        $data = array(
            ':repaymentWarn' => $status,
            ':update_time'   => $time,
            ':uid'           => $uid,
            ':cid'           => $cid
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /*
     * @desc    获取还款信用卡提醒用户
     */
    public function getAllRepaymentWarn($date, $type, $limit, $num){
        if($type == 1){
            $sql = 'SELECT * FROM `users_creditcard` WHERE `status`=:status AND `repaymentWarn`=:repaymentWarn AND `billDate`=:date LIMIT :limit, :num';
        }else{
            $sql = 'SELECT * FROM `users_creditcard` WHERE `status`=:status AND `repaymentWarn`=:repaymentWarn AND `payDate`=:date LIMIT :limit, :num';
        }
        $data = array(
            ':status'        => 1,
            ':repaymentWarn' => 1,
            ':date'          => $date,
            ':limit'         => $limit,
            ':num'           => $num
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }
}

<?php
/**
 * @desc    用户渠道相关信息，包括用户注册了那些通道，通道码等相关信息
 * @author  qien
 * @date    18.03.24
 */
class XbModel_Account_UsersChannel extends XbModel_BaseModel{
    public static $cache_tag    = "Account_Users_Channel_";
    public static $cache_expire = 86400;

    function __construct(){
        parent::_init("xb_account");
    }

    /**
     * @desc    创建用户通道身份标识
     * @param   int     $uid            用户id
     * @param   array   $channelInfo    通道标识信息
     * @return  boolen  $return         返回创建结果
     */
    public function createChannelCode($uid, $channelInfo){
        if(count($channelInfo) == 0) return false;
        $time = time();
        $sql = 'INSERT INTO `users_channel_code`(`uid`, `channel_id`, `channel_code`, `status`, `create_time`,`channel_key`) VALUES';
        $data = array(
            ':uid'         => $uid,
            ':status'      => 2,
            ':create_time' => $time
        );
        foreach($channelInfo as $k=>$v){
            if(!$v['channel_code']) continue;
            $sql .= "(:uid, :channel_id{$k}, :channel_code{$k}, :status, :create_time,:channel_key{$k}),";
            $data[":channel_id{$k}"]   = $v['channel_id'];
            $data[":channel_code{$k}"] = $v['channel_code'];
            $data[":channel_key{$k}"] = $v['channel_key'];
        }
        if(count($data) <= 3) return false;
        $sql = trim($sql, ',');
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /*
     * @desc    获取用户通道channel_code
     * */
    public function getUsersChannelCode($uid, $channel_id){
        $sql = 'SELECT * FROM `users_channel_code` WHERE `uid`=:uid AND `channel_id`=:channel_id';
        $data = array(
            ':uid'        => $uid,
            ':channel_id' => $channel_id
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    获取用户所有注册的通道
     * @param   int     $uid        用户id
     * @param   string  $status     通道状态
     * @return  array   $return     返回数据
     */
    public function getAllUserChannelByUid($uid, $status=''){
        $sql = 'SELECT * FROM `users_channel_code` WHERE `uid`=:uid';
        $data = array(
            ':uid'    => $uid
        );
        if(!empty($status)){
            $sql .= ' AND `status` IN ('.$status.')';
        }
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }
    /**
     * @desc   获取用户通道信息
     * @param    int     $uid            用户ID
     * @param    int     $channel_id     通道ID
     * @return   array   $return         返回查询结果
     * */
    public function getUserChannel($uid,$channel_id){
        $sql = "SELECT * FROM `users_channel_code` WHERE `uid` = :uid AND `channel_id` =:channel_id";
        $data = array(
            ':uid'        =>  $uid,
            ':channel_id'=>  $channel_id,
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }
    /**
     *@desc  通过channel_code 获取用户ID
     *@param   string      $channel_code     通道码
     *@return  return      $return           返回执行结果
     */
    public function getUserId($channel_code){
        $sql = "SELECT * FROM `users_channel_code` WHERE `channel_code` = :channel_code ";
        $data = array(
            ':channel_code'   =>  $channel_code,
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }

    /**
     * @desc    用户注册指定收款通道
     * @param   int     $channel_id 通道id
     * @param   int     $uid        用户id
     * @return  array   $return     返回注册情况
     */
    public function userSignUp($channel_id, $uid){
        $order_obj = XbLib_PaymentObjs_Order::getInstance()->userSignUp($channel_id, $uid);
        if (!$order_obj instanceof XbLib_PaymentObjs_Order) {
            return $order_obj;
        }
        $res_sign_up = XbLib_ChannelFunc_Channel::getInstance()->userSignUp($channel_id, $order_obj);

        if (!$res_sign_up['success']) {
            $param = array(
                'uid' => $uid,
                'channel_id' => $channel_id,
                'code' => $res_sign_up['data']['error_code'],
                'message' => $res_sign_up['data']['error_message'] ? $res_sign_up['data']['error_message'] : '小微商户入网失败',
                'create_time' => time());
            $res_channel_error = XbModule_Account_UsersProfile::getInstance()->userChannelError($param);
            return new XbLib_WebError(400,'通道进件失败');
        }

        $sql = 'INSERT INTO `users_channel_code`(`uid`, `channel_id`, `channel_code`, `channel_key`, `status`, `create_time`) VALUES (:uid, :channel_id, :channel_code, :channel_key, :status, :create_time)';
        $data = array(
            ':uid'         => $uid,
            ':channel_id'  => $channel_id,
            ':channel_code'=> $res_sign_up['data']['mimer_member_id'],
            ':channel_key' => '',
            ':status'      => 2,
            ':create_time' => time()
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }
}
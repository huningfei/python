<?php
/**
 * Created by PhpStorm.
 * User: yurong
 * Date: 2018/5/18
 * Time: 上午11:00
 */
class XbModel_Account_Flag extends XbModel_BaseModel{
    static $cache_tag = "Account_flag_";

    //链接库
    function __construct() {
        parent::_init("xb_account");
    }

    /**
     * @desc 获取列表
     * @param    int       $start       偏移量
     * @param    int       $limit       查询条数
     * @param    int       $type        查询类型（1:标识分类，2：标识）
     * @param    string    $flag_name   标识名称
     * @param    int       $flag_cate   标识分类
     * @return   array     $return      返回执行结果
     * */
    public  function getList($start,$limit,$type,$flag_name,$flag_cate){
        $sql = " select * from `common_flag` WHERE 1=1";
        $data=[];
        if($type){
            $sql .= " AND `pid`= 0";
        }else{
            $sql .= " AND `pid`> 0";
        }
        if($flag_name){
            $sql .= " AND `title`=:title";
            $data[':title'] = $flag_name;
        }
        if($flag_cate){
            $sql .= " AND `pid`=:flag_cate";
            $data[':flag_cate'] = $flag_cate;
        }
        if(($start || $start === 0) && $limit){
            $sql .=" limit :start,:limit";
            $data[':start'] = $start;
            $data[':limit'] = $limit;
        }

        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();

    }
    /**
     * @desc 获取条数
     * @param      int    $type       类型（true:标识分类；false:标识）
     * @param      string $flag_name  标识名称（true:标识分类；false:标识）
     * @param      int    $flag_cate  标识分类（true:标识分类；false:标识）
     * @return     array  $return     返回执行结果
     * */
    public function getListCount($type,$flag_name,$flag_cate){
        $sql = " select count(*) as num from `common_flag` WHERE 1=1";
        $data = [];
        if($type){
            $sql .= " AND `pid`= 0";
        }else{
            $sql .= " AND `pid`> 0";
        }
        if($flag_name){
            $sql .= " AND `title`=:title";
            $data[':title'] = $flag_name;
        }
        if($flag_cate){
            $sql .= " AND `pid`=:flag_cate";
            $data[':flag_cate'] = $flag_cate;
        }
        $res =  $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
        return $res?$res['num']:0;
    }
    /**
     * @desc 获取标识分类下总条数
     * @param   int   $pid    标识分类ID
     * @return  array $return 返回执行结果
     * */
    public function getTitleCount($pid){
        $sql = " select count(*) as num from `common_flag` WHERE  `pid`=:pid";
        $data = array(
            ':pid'=>$pid
        );
        $res =  $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
        return $res?$res['num']:0;
    }

    /**
     * @desc 获取标识信息
     * @param   int   $pid    标识分类ID
     * @return  array $return 返回执行结果
     * */
    public function getflagById($pid){
        $sql = " select * from `common_flag` where `id`=:pid";
        $data=array(
            ':pid'=>$pid
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }
    /**
     * @desc 获取所有标识分类
     * @param   int    $pid   标识分类ID
     * @return  array  $return返回执行结果
     * */
    public function getAllFlagCate($pid){
        $sql = " select *  from `common_flag` WHERE  `pid`=:pid";
        $data[':pid']=$pid?$pid:0;
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
    }
    /**
     * @desc 编辑标识
     * @param   int        $id             标识ID
     * @param   int        $pid            标识分类ID
     * @param   string     $title          标识名称
     * @param   string     $description    备注
     * @return  boolean    $return         返回执行结果
     * */
    public function edit($id,$pid,$title,$description){
        $info_sql = " SELECT * FROM `common_flag` WHERE id=:id";
        $info_data = array(':id'=>$id);
        $info = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($info_sql,$info_data)->fetchOne();
        if(!$info){
            return false;
        }
        $info_sql = "SELECT * FROM `common_flag` WHERE  `title`=:title";
        $info_data = array(
            ':title'=>$title
        );
        $info_res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($info_sql,$info_data)->fetchOne();
        if($info_res && $title != $info['title']){
            return 'fail';
        }
        $sql = 'UPDATE `common_flag` set `pid`=:pid,`title`=:title,`description`=:description where `id`=:id';
        $data =[
            ':pid'=> $pid,
            ':title'=> $title,
            ':description'=> $description,
            ':id'=> $id,
        ];
        $res =  $this->dao->conn(false)->noCache()->preparedSql($sql,$data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }
    /**
     * @desc 新增标识
     * @param   int        $pid            标识分类ID
     * @param   string     $title          标识名称
     * @param   string     $description    备注
     * @return  boolean    $return         返回执行结果
     * */
    public function add($pid,$title,$description){
        $time = time();
        $info_sql = "SELECT * FROM `common_flag` WHERE  `title`=:title";
        $info_data = array(
            ':title'=>$title
        );
        $info_res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($info_sql,$info_data)->fetchOne();
        if($info_res){
            return 'fail';
        }
        $sql = 'INSERT INTO  `common_flag`(`pid`,`title`,`description`,`create_time`) values(:pid,:title,:description,:create_time)';
        $data =[
            ':pid'=> $pid,
            ':title'=> $title,
            ':description'=> $description,
            ':create_time'=> $time,
        ];
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql,$data)->lastInsertId();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }
    /**
     * @desc 删除标识，标识分类
     * @param   int        $id             标识ID
     * @return  boolean    $return         返回执行结果
     * */
    public function delete($id){
        $sql = 'DELETE FROM   `common_flag` WHERE `id`=:id';
        $data[':id'] = $id;
        $res =  $this->dao->conn(false)->noCache()->preparedSql($sql,$data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }
}
<?php
/**
 * @desc 	用户等级相关
 * @author  yurong
 * @date    18.02.07
 */
class XbModel_Account_UsersInviteParentlist extends XbModel_BaseModel{
    public static $cache_tag = "Account_Users_invite_parentlist_";
    public static $cache_expire = 259200;
    function __construct() {
        parent::_init("xb_account");
    }

    /**
     * @desc    获取用户邀请人数
     * @param   int     $uid        用户ID
     * @param   int     $is_auth    是否统计已审核通过用户
     * @return  array   $return     返回结果
     */
    public  function getUserInviteCount($uid, $is_auth=false){
        if(!$is_auth){
            $sql = "SELECT count(*) as num FROM `users_invite_parentlist` WHERE `parentid` = :parentid";
        }else{
            $sql = 'SELECT COUNT(*) AS num FROM `users_invite_parentlist` u LEFT JOIN `users_profile` up ON up.uid=u.uid WHERE u.`parentid`=:parentid AND up.`status`=:status';
            $data[':status'] = 3;
        }
        $data[':parentid'] = $uid;
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc   获取用户邀请人
     * @param  int   $id   用户ID
     * @return  array  $return  返回结果
     */
    public  function getUserInvite($id){
        if($id){
            $sql = "SELECT uid FROM `users_invite_parentlist` WHERE `parentid` = :parentid";
            $data = array(
                ':parentid' => $id
            );
            return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();

        }
        return false;
    }

    //获取邀请记录列表
    public function getParentlist($uid = '',$phone = '',$nickname = '',$telphone = '',$be_invited ='',$invite='',$start_time = '',$end_time = '',$merchant_id = '',$m_id = '',$role_name = '',$page = '',$perpage = '')
    {
        $start_time = strtotime($start_time);
        $end_time = strtotime($end_time);
        if (!empty($end_time)) {
            $end_time = $end_time + 86400;
        }
//        $sql = 'select a.id aid,a.uid,a.parentid,a.create_time,b.id bid,b.phone bphone,b.nickname bnickname,b.mch_id bmch_id,c.realname brealname,p.id pid,p.phone pphone,p.nickname pnickname,e.realname prealname,f.uid fuid,f.level_id,g.fee,h.uid huid,h.level_id hlevel_id,i.fee hfee from users_invite a
//LEFT JOIN users b on a.uid = b.id
//LEFT JOIN users_profile c on b.id = c.uid
//LEFT JOIN users p on a.parentid = p.id
//LEFT JOIN users_profile e on p.id = e.uid
//LEFT JOIN users_level f on a.uid = f.uid
//LEFT JOIN common_level g on f.level_id = g.level
//LEFT JOIN users_level h on a.parentid = h.uid
//LEFT JOIN common_level i on h.level_id = i.level where 1=1';
        $sql = 'select a.id aid,a.uid,a.parentid,a.create_time,b.id bid,b.phone bphone,b.nickname bnickname,b.mch_id bmch_id,u.realname brealname from users_invite a LEFT JOIN users b on a.uid = b.id LEFT JOIN users_profile u on b.id = u.uid where 1=1';
        $data = array(
            ':page' => ($page - 1) * $perpage,
            ':perpage' => $perpage,
        );
        $sql .= ' and a.parentid != 0';
        //判断是否是代理
        if ($role_name == "商户") {
            $sql .= ' and b.`mch_id` = ' . $m_id;
        }
        if ($merchant_id != '') {
            $sql .= ' and b.`mch_id` = '.$merchant_id;
        }
        if ($phone != '') {
            $sql .= ' and b.`phone` = "'.$phone.'"';
        }
        if ($nickname != '') {
            $sql .= ' and b.`nickname` = "'.$nickname.'"';
        }
        if ($be_invited != '') {
            $sql .= ' and u.`realname` = "'.$be_invited.'"';
        }
        if ($uid != '') {
            $sql .= ' and a.`uid` = "'.$uid.'"';
        }
        if ($start_time != '') {
            $sql .= ' and a.`create_time` >= ' . $start_time;
        }
        if ($end_time != '') {
            $sql .= ' and a.`create_time` <= ' . $end_time;
        }
        if ($telphone != '') {
            $sql .= ' and a.`parentid` = "'.$telphone.'"';
        }
        if ($invite != '') {
            $invite_sql = 'select uid from users_profile where `realname` = "'.$invite.'"';
            $invite_arr = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($invite_sql, array())->fetchAll();
            $parentid_str = '';
            foreach($invite_arr as $val){
                $parentid_str.=$val['uid'].',';
            }
            $parentid_str = trim($parentid_str,',');
            $sql .= ' and a.`parentid` in ("'.$parentid_str.'")';
        }
        if ($page != '' && $perpage != '') {
            $sql .= ' order by a.id desc limit :page,:perpage ';
        }
        $str = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
        $mid = '';
        $parentid = '';
        $uid = '';
        foreach ($str as &$v) {
            if ($v['bmch_id'] != 0) {
                $mid .= $v['bmch_id'] . ',';
            }
            if ($v['parentid'] != 0) {
                $parentid .= $v['parentid'] . ',';
            }
            if ($v['uid'] != 0) {
                $uid .= $v['uid'] . ',';
            }
        }
        if(!empty($uid)){
            $uid = trim($uid, ',');
//            $sql = 'select f.uid fuid,f.level_id,g.fee,h.uid huid,h.level_id hlevel_id,i.fee hfee from users_level f LEFT JOIN common_level g on f.level_id = g.level LEFT JOIN users_level h on a.parentid = h.uid LEFT JOIN common_level i on h.level_id = i.level where f.uid in('.$uid.')';
            $sql = 'select f.uid fuid,f.level_id,g.fee from users_level f LEFT JOIN common_level g on f.level_id = g.level where f.uid in('.$uid.')';
            $data = array();
            $level = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
            $levelArray = array();
            foreach ($level as $k => $vel) {
                $levelArray[$vel['fuid']] = $vel;
            }
            foreach ($str as &$vel) {
                if (!empty($levelArray[$vel['uid']])) {
                    $vel['fuid'] = $levelArray[$vel['uid']]['fuid'];
                    $vel['level_id'] = $levelArray[$vel['uid']]['level_id'];
                    $vel['fee'] = $levelArray[$vel['uid']]['fee'];
                }
            }
        }
        if(!empty($parentid)){
            $parentid = trim($parentid, ',');
            $sql = 'select p.id pid,p.phone pphone,p.nickname pnickname,e.realname prealname from users p LEFT JOIN users_profile e on p.id = e.uid where p.id in('.$parentid.')';
            $data = array();
            $parent = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
            $sql2 = 'select h.uid huid,h.level_id hlevel_id,i.fee hfee from users_level h LEFT JOIN common_level i on h.level_id = i.level where h.uid in('.$parentid.')';
            $data = array();
            $parent2 = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql2, $data)->fetchAll();
            $parentArray = array();
            $parentArray2 = array();
            foreach ($parent2 as $k => $vels) {
                $parentArray2[$vels['huid']] = $vels;
            }
            foreach ($parent as $k => $velp) {
                $parentArray[$velp['pid']] = $velp;
            }
            foreach ($str as &$vl) {
                if (!empty($parentArray[$vl['parentid']])) {
                    $vl['pid'] = $parentArray[$vl['parentid']]['pid'];
                    $vl['pphone'] = $parentArray[$vl['parentid']]['pphone'];
                    $vl['pnickname'] = $parentArray[$vl['parentid']]['pnickname'];
                    $vl['prealname'] = $parentArray[$vl['parentid']]['prealname'];
                }
                if (!empty($parentArray2[$vl['parentid']])) {
                    $vl['huid'] = $parentArray2[$vl['parentid']]['huid'];
                    $vl['hlevel_id'] = $parentArray2[$vl['parentid']]['hlevel_id'];
                    $vl['hfee'] = $parentArray2[$vl['parentid']]['hfee'];
                }
            }
        }
        //查询代理名称
        if (!empty($mid)) {
            $mid = trim($mid, ',');
            $modify = XbModule_Merchant_Merchant::getInstance()->inMerchart($mid);
            $modifyArray = array();
            foreach ($modify as $k => $velm) {
                $modifyArray[$velm['id']] = $velm;
            }
            foreach ($str as &$velsm) {
                $velsm['m_name'] = 0;
                if (!empty($modifyArray[$velsm['bmch_id']])) {
                    $velsm['m_name'] = $modifyArray[$velsm['bmch_id']]['name'];
                }
            }
        }
        return $str;
    }

    /**
     * @desc   获取对应等级用户邀请人
     * @param    int     $id        用户ID
     * @param    int     $start     偏移量
     * @param    int     $limit     每页条数
     * @return   array   $return    返回结果
     */
    public  function getUserInviteLevel($id,$start,$limit,$level){
        if($id){
            $sql = "SELECT u.uid FROM `users_invite_parentlist` as u LEFT JOIN `users_level` as level ON u.uid = level.uid LEFT JOIN `common_level` as c ON level.level_id = c.level WHERE `parentid` = :parentid AND level.`level_id`=:level_id LIMIT :start,:limit";
            $data = array(
                ':parentid' => $id,
                ':level_id' => $level,
                ':start' => $start,
                ':limit' => $limit
            );
            return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
        }
        return false;
    }
}
<?php
/**
 * @desc  http2https
 * User: zq
 * Date: 29/6/18
 * Time: 16:32
 */
class XbModel_Account_Http2Https extends XbModel_BaseModel{
    static $cache_tag = "Account_Http2Https_";

    //链接库
    function __construct() {
        parent::_init("xb_account");
    }

    /**
     * @desc 统计表行数
     * @return    int    $return     返回执行结果
     * */
    public function tableCount($table_name) {
        $sql_count  = "select count(*) as count from {$table_name}";
        $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_count,array())->fetchOne()['count'];
        return $res;
    }

    /**
     * @desc 复制表表结构与数据
     * @param     int      $id         红包记录id
     * @return    array    $return     返回执行结果
     * */
    public function copyTable($old_table, $new_table) {
        $sql = "DROP TABLE IF EXISTS {$new_table}";
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, array())->excute();

        try {
            $sql = "create table {$new_table} like {$old_table}";
            $res = $this->dao->conn(false)->noCache()->preparedSql($sql, array())->excute();
        }catch (Exception $e){
            XbFunc_Log::write('http2HttpsCopy',"表结构复制失败：{$old_table}", $e);
        }

        try {
            $sql = "insert into {$new_table} select * from {$old_table}";
            $res_data = $this->dao->conn(false)->noCache()->preparedSql($sql, array())->excute();
        }catch (Exception $e){
            XbFunc_Log::write('http2HttpsCopy',"表数据复制失败：{$old_table}", $e);
        }
        return $res_data;
    }

    /**
     * @desc 使用https替换http
     * @param     int      $id         红包记录id
     * @return    array    $return     返回执行结果
     * */
    public function http2https($db, $table, $field, $fromStr='http', $toStr='https') {
        try {
            $sql = "UPDATE {$db}.{$table} SET {$field} = REPLACE({$db}.{$table}.{$field}, '".$fromStr."', '".$toStr."')";
            $res = $this->dao->conn(false)->noCache()->preparedSql($sql, array())->excute();
        }catch (Exception $e){
            XbFunc_Log::write('http2Https',"修改失败：{$db}.{$table} --- {$field}", $e);
        }
        return $res;
    }


}
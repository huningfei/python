<?php

/**
 *
 * Author: abel
 * Date: 2017/12/7
 * Time: 16:32
 */
class XbModel_Account_Token extends XbModel_BaseModel {

    function __construct() {
        parent::_init("xb_account");
    }

    /**
     * 创建token
     * @param $uid
     * @return bool|string
     */
    public function createToken($type, $uid) {
        //生成一个token
        $factory = new RandomLib\Factory();
        $generator = $factory->getGenerator(new SecurityLib\Strength());
        $build = true;
        $token = "";
        while ($build) {
            $token = $generator->generateString(32, "abcdefghijklmnopqrstuvwxyz1234567890");
            //检查是否重复
            $getsql = "SELECT * FROM `token` WHERE `type`=:type AND `token`=:token";
            $getdata = [
                ':type'  => $type,
                ':token' => $token
            ];
            $tokendata = $this->dao->conn(false)->noCache()->preparedSql($getsql, $getdata)->fetchOne();
            if (empty($tokendata)) {
                $build = false;
            }
        }

        $now = time();
        $sql = "INSERT INTO `token` (`type`,`uid`,`token`,`create_time`) VALUES (:type,:uid,:token,:create_time)";
        $data = [
            ":type"        => $type,
            ":uid"         => $uid,
            ":token"       => $token,
            ":create_time" => $now
        ];
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if (empty($res)) {
            return false;
        }
        return $token;

    }

    /**
     * @param $uid
     * @param bool $flush 刷新过期时间
     * @return mixed|null
     */
    public function getTokenByUid($type, $uid, $flush = false) {
        $sql = "SELECT `token`,`create_time` FROM `token` WHERE `type`=:type AND `uid`=:uid";
        $data = [
            ":type" => $type,
            ":uid"  => $uid
        ];
        $token = $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();

        if (empty($token)) {
            return null;
        }
        if ($flush) {
            $now = time();
            $update_sql = "UPDATE `token` SET `create_time`=:create_time WHERE `type`=:type AND `uid`=:uid";
            $update_data = [":create_time" => $now, ":type" => $type, ":uid" => $uid];
            $this->dao->conn(false)->noCache()->preparedSql($update_sql, $update_data)->affectedCount();
            $token['create_time'] = $now;
        }
        return $token;
    }

    /**
     * 根据Token获得UID
     * @param $token
     * @return mixed
     */
    public function getUidByToken($type, $token) {
        $sql = "SELECT `uid`,`create_time` FROM `token` WHERE `type`=:type AND `token`=:token";
        $data = [
            ":type"  => $type,
            ":token" => $token
        ];
        $uid = $this->dao->conn()->nocache()->preparedSql($sql, $data)->fetchOne();
        return $uid;
    }


    /**
     * 清除一个token
     * @param $token
     * @return bool
     */
    public function deleteToken($type, $token) {
        $sql = "DELETE FROM `token` WHERE `type`=:type AND `token`=:token";
        $data = [
            ":type"  => $type,
            ":token" => $token
        ];
        $count = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if (empty($count)) {
            return false;
        }
        return true;
    }
}
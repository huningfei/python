<?php
/**
 * @desc 	订单相关
 * @author  qien
 * @date    17.12.25
 */
class XbModel_Account_Order extends XbModel_BaseModel{
    public static $suffix;
    public static $cache_tag = "Account_Order_";
    public static $cache_expire = 259200;
    
    /**
     *  收款终端：iOSAPP，安卓APP，公众号
     * 
     * @var array
     */
    public static $clientChannelList = [
        'iOSAPP',
        '安卓APP',
        '公众号'
    ];

    function __construct() {
        parent::_init("xb_account");
    }
    /**
     * @desc    创建订单
     * @param   $uid            用户id
     * @param   $amount         刷卡金额
     * @param   $level          刷卡金额
     * @param   $rate           刷卡利率
     * @param   $creditBank     刷卡银行
     * @param   $cc             刷卡卡号
     * @param   $dc             收款卡号
     * @param   $channel_id     刷卡费率
     * @param   $channel_name   刷卡通道名称
     * @param   $channel_type   刷卡通道类型，1：内部通道，2：外部通道
     * @param   $channel_tag    刷卡通道标识，1：有积分，2：无积分
     * @param   $channel_data   内部刷卡通道下单信息
     * @param   $client_channel 收款终端：iOSAPP，安卓APP，公众号
     * @return  array           返回安心付订单信息
     */
    public function createOrder($uid, $amount, $level, $rate, $creditBank, $cc, $dc, $channel_id, $channel_name, $channel_type, $channel_data, $client_channel = ''){
        $time = time();
        $order_id = XbModule_Account_OrderCode::getInstance()->getOrderCode();
        $this->dao->conn(false)->beginTransaction();
        if($channel_type == 1){
            $channel_data['order_id'] = $order_id;
            $channel_data['time'] = date('YmdHis',$time);
            $res = XbLib_ChannelFunc_Channel::getInstance()->createOrder($channel_data['channel_id'], $channel_data);
            if(!$res){
                $this->dao->rollback();
                return false;
            }
            $channel_order = $res['order_id'];
            $pay_url       = $res['url'];
        }
        $sql = 'INSERT INTO `order_'.self::$suffix.'`(`order_id`, `uid`, `amount`, `level`, `rate`, `creditbank`, `creditcard`, `debitcard`, `channel_id`, `channel_name`, `axf_order_no`, `create_time`, `type`,`single_fee`, `client_channel`) VALUES(:order_id, :uid, :amount, :level, :rate, :creditBank, :creditcard, :debitcard, :channel_id, :channel_name, :axf_order_no, :create_time, :type,:single_fee,:client_channel)';
        $data = array(
            ':order_id'     => $order_id,
            ':uid'          => $uid,
            ':amount'       => $amount,
            ':level'        => $level,
            ':rate'         => $rate,
//            ':fee'         => $channel_data['fee'],
            ':single_fee'   => $channel_data['fee'],
            ':creditBank'   => $creditBank,
            ':creditcard'   => $cc,
            ':debitcard'    => $dc,
            ':channel_id'   => $channel_id,
            ':channel_name' => $channel_name,
            ':axf_order_no' => $channel_order,
            ':create_time'  => $time,
            ':type'         => $channel_type,
            ':client_channel' => $client_channel
        );
        $order = $this->dao->noCache()->preparedSql($sql, $data)->lastInsertId();
        if(!$order){
            $this->dao->rollback();
            return false;
        }
        $index_data = array(
            ':order_table_num'  => self::$suffix,
            ':order_table_id'   => $order,
            ':order_id'          => $order_id,
            ':uid'                => $uid,
            ':create_time'       => $time
        );
        $order_index = XbModule_Account_OrderIndex::getInstance()->createOrderIndex($index_data);
        if(!$order_index){
            $this->dao->rollback();
            return false;
        }

        $res = $this->dao->commit();

        $factory    = new RandomLib\Factory();
        $generator  = $factory->getGenerator(new SecurityLib\Strength());
        $build      = true;
        $orderCode = "";
        while ($build) {
            $orderCode = $generator->generateString(11, "abcdefghijklmnopqrstuvwxyz1234567890");
            //检查是否重复
            $inviteCodeData = $this->getRecirectByOrderCode($orderCode,false);
            if (empty($inviteCodeData)) {
                $build = false;
            }
        }

        $sql  = 'INSERT INTO `order_redirect`(`redirect`, `mch_id`, `oid`, `create_time`, `orderCode`) VALUES(:redirect, :mch_id, :oid, :create_time,:orderCode)';
        $data = array(
            ':redirect'    => $pay_url,
            ':mch_id'       => self::$suffix,
            ':oid'          => $order,
            ':create_time' => $time,
            ':orderCode' => $orderCode
        );
        $orderNo = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
        if(!$orderNo){
            return false;
        }
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res ? array('orderNo'=>$orderNo, 'channel' => $pay_url, 'orderId' => $order,'orderCode'=>$orderCode) : false;
    }

    //获取code码
    public function getOrderCode(){
        $now = time();
        $sql = "INSERT INTO order_serial (create_time) values ({$now})";
        $insertId = $this->dao->conn(false)->noCache()->preparedSql($sql,array())->lastInsertId();
        if(!$insertId){
            return false;
        }
        $sql = "SELECT * FROM order_code WHERE id={$insertId}";
        $order_code = $this->dao->conn(false)->noCache()->preparedSql($sql,array())->fetchOne();
        if(!$order_code){
            return false;
        }
        return $order_code['code'];
    }

    /**
     * @desc    获取所有订单
     * @param   int     $uid    用户id
     * @param   array   $where  搜索条件
     * @param   int     $start  开始条目
     * @param   int     $limit  搜索条目
     * @param   string  $order  排序方式
     * @return  array   $return 返回搜索数据
     */
    public function getAllOrderByUid($uid, $where, $start, $limit, $order){
        $sql  = 'SELECT * FROM `order_'.self::$suffix.'` WHERE `uid`=:uid';
        $data = array(
            ':uid' => $uid
        );
        if(count($where) > 0){
            foreach($where as $k=>$v){
                $sql .= ' AND `'.$k.'`=:'.$k;
                $data[':'.$k] = $v;
            }
        }
        $sql .= ' ORDER BY '.$order;
        if($limit){
            $sql .= ' LIMIT :start,:limit';
            $data[':start'] = $start;
            $data[':limit'] = $limit;
        }
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    统计用户订单
     * @param   int     $uid    用户id
     * @param   array   $where  搜索条件
     * @return  int     $return 返回搜索数量
     */
    public function countOrderByUid($uid, $where){
        $sql  = 'SELECT COUNT(*) AS num FROM `order_'.self::$suffix.'` WHERE `uid`=:uid';
        $data = array(
            ':uid' => $uid
        );
        if(count($where) > 0){
            foreach($where as $k=>$v){
                $sql .= ' AND `'.$k.'`=:'.$k;
                $data[':'.$k] = $v;
            }
        }
        $res = $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
        return $res['num'];
    }

    /**
     * @desc    统计一共刷卡多少钱
     * @param   int     $uid        用户id
     * @param   array   $where      搜索条件
     * @return  int     $return     返回搜索结果
     */
    public function countAmountByUid($uid, $where){
        $sql  = 'SELECT SUM(`amount`) AS amount FROM `order_'.self::$suffix.'` WHERE `uid`=:uid';
        $data = array(
            ':uid' => $uid
        );
        if(count($where) > 0){
            foreach($where as $k=>$v){
                $sql .= ' AND `'.$k.'`=:'.$k;
                $data[':'.$k] = $v;
            }
        }
        $res = $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
        return $res['amount'];
    }

    /**
     * @desc    根据订单号获取订单信息
     * @param   int     $order_id   订单号
     * @return  array   $return     返回订单信息
     */
    public function getOrderByOrderid($order_id){
        $sql = 'SELECT * FROM `order_'.self::$suffix.'` WHERE `order_id`=:order_id';
        $data = array(
            ':order_id' => $order_id
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    根据id获取订单信息
     * @param   int     $id         id
     * @return  array   $return     返回订单信息
     */
    public function getOrderById($id){
        $sql = 'SELECT * FROM `order_'.self::$suffix.'` WHERE `id`=:id';
        $data = array(
            ':id' => $id
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    更新订单状态
     * @param   string  $order_id   订单号
     * @param   int     $status     订单状态
     * @param   int     $fee        手续费
     * @param   string  $pay_time   支付时间
     * @return  boolen  $return     执行结果
     */
    public function updateOrderStatus($order_id, $status, $fee=0, $pay_time=''){
        $sql = 'UPDATE `order_'.self::$suffix.'` SET `status`=:status';
        $data[':status'] = $status;
        if($status == 1){
            $sql .= ', `fee`=:fee, `pay_time`=:pay_time';
            $data[':fee']      = $fee;
            $data[':pay_time'] = $pay_time;
        }
        $sql .= ' WHERE order_id=:order_id';
        $data[':order_id'] = $order_id;
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
    }

    /**
     * @desc    根据商户订单
     * @param   int     $order_id   订单号
     * @return  array   $return     返回订单信息
     */
    public function getOrderList($order_id,$start_time,$end_time,$start,$limit,$status){
        $time = strtotime(date('Y-m-d',time()));
        $sql  = 'SELECT * FROM `order_'.self::$suffix.'` WHERE 1=1 and create_time<'.$time;
        $data = array();
        if(!empty($order_id)){
            $sql .= ' and  order_id=:order_id';
            $data[':order_id'] = $order_id;
        }
        if(!empty($start_time)){
            $sql .= ' and  create_time>=:starttime';
            $data[':starttime'] = strtotime($start_time);
        }
        if(!empty($end_time)){
            $sql .= ' and  create_time<=:endtime';
            $data[':endtime'] = strtotime($end_time." 23:59:59");
        }
        if(!empty($status)){
            $sql .= ' and  status=:status';
            $data[':status'] = $status;
        }
        $sql .= ' ORDER BY `create_time` desc ';
        $sql .= ' LIMIT :start,:limit';
        $data[':start'] = $start;
        $data[':limit'] = $limit;
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    根据商户获取订单数量
     * @param   int     $order_id   订单号
     * @return  array   $return     返回订单信息
     */
    public function getOrderListCount($order_id,$start_time,$end_time,$status){
        $sql  = 'SELECT COUNT(*) AS num FROM `order_'.self::$suffix.'` WHERE 1=1 ';
        $data = array();
        if(!empty($order_id)){
            $sql .= ' and  order_id=:order_id';
            $data[':order_id'] = $order_id;
        }
        if(!empty($start_time)){
            $sql .= ' and  create_time>=:starttime';
            $data[':starttime'] =  strtotime($start_time);
        }
        if(!empty($end_time)){
            $sql .= ' and  create_time<=:endtime';
            $data[':endtime'] = strtotime($end_time." 23:59:59");
        }
        if(!empty($status)){
            $sql .= ' and  status<=:status';
            $data[':status'] = $status;
        }
        $res = $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
        return $res['num'];
    }

    /**
     * @desc    根据id获取跳转链接
     * @param   int     $order_id   订单号
     * @return  array   $return     返回订单信息
     */
    public function getOrderRecirect($order_id){
        $sql  = 'SELECT * FROM `order_redirect` WHERE `id`=:id';
        $data = array(
            ':id' => $order_id
        );

        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
    }

    //获取商户昨天的所有订单
    public function merchantGetOrder($start,$end){
        $sql  = 'SELECT amount,rate,id,is_profit,profit_rate from  order_'.self::$suffix.' where :start<create_time and :end>=create_time and status=1';
        $data = array(
            ':start' =>$start,
            ':end' =>$end,

        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    根据安心付订单号查询订单
     * @param   int     $axf_order_no   订单号
     * @return  array   $return         返回订单信息
     */
    public function getOrderByAnfOrderNo($axf_order_no){
        $sql  = 'SELECT * FROM `order_'.self::$suffix.'` WHERE `axf_order_no`=:axf_order_no';
        $data = array(
            ':axf_order_no' => $axf_order_no
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
    }

    //插入每条订单收益
    public function insertMoney($id,$profit_money){
        $sql = 'UPDATE `order_'.self::$suffix.'` SET `mch_money`=:money where id=:id';
        $data = array(
            //':m_id' => $m_id,
            ':id' => $id,
            ':money' => $profit_money
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
    }

    /**
     * @desc    同步订单反润，修改订单数据，transaction处理
     * @param   string      $order_id       订单号
     * @param   array       $profit         分润数据
     * @param   float       $profit_rate    分润最低费率
     * @param   int         $is_profit      是否更新分润订单，0未更新，1已更新，2没有分润信息
     * @return  boolen      $return         执行结果
     */
    public function synOrderProfit($order_id, $profit, $profit_rate, $is_profit){
        $time = time();
        $this->dao->conn(false)->beginTransaction();
        if($is_profit == 1){
            $sql = 'INSERT INTO `profit_'.self::$suffix.'`(`uid`, `order_id`, `reference_no`, `from_uid`, `rate`, `amount`, `created_at`, `create_time`) VALUES';
            $data = array();
            foreach($profit as $k=>$v){
                $sql .= "(:uid{$k}, :order_id{$k}, :reference_no{$k}, :from_uid{$k}, :rate{$k}, :amount{$k}, :created_at{$k}, :create_time{$k}),";
                $data[":uid{$k}"]          = $v['uid'];
                $data[":order_id{$k}"]     = $v['order_id'];
                $data[":reference_no{$k}"] = $v['reference_no'];
                $data[":from_uid{$k}"]     = $v['from_uid'];
                $data[":rate{$k}"]         = $v['rate'];
                $data[":amount{$k}"]       = $v['amount'];
                $data[":created_at{$k}"]   = $time;
                $data[":create_time{$k}"]  = $time;
            }
            $sql = trim($sql, ',');
            $res = $this->dao->noCache()->preparedSql($sql, $data)->lastInsertId();
            if(!$res){
                $this->dao->rollback();
                return false;
            }
        }

        $sql = 'UPDATE `order_'.self::$suffix.'` SET `profit_rate`=:profit_rate, `is_profit`=:is_profit WHERE `order_id`=:order_id';
        $data = array(
            ':profit_rate' => $profit_rate,
            ':is_profit'   => $is_profit,
            ':order_id'    => $order_id
        );
        $res = $this->dao->noCache()->preparedSql($sql, $data)->affectedCount();
        if(!$res){
            $this->dao->rollback();
            return false;
        }

        return $this->dao->commit();
    }

    /**
     * @desc    根据时间获取订单
     */
    public function getOrderByTime($start, $end){
        $sql = 'SELECT * FROM `order_'.self::$suffix.'` WHERE `create_time` > :start and `create_time` <= :end and status=0';
        $data = array(
            ':start' => $start,
            ':end'   => $end
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    创建订单号，脚本使用，勿用
     * @param   int     $num        创建订单号数量
     * @return  boolen  $return
     */
    public function createOrderCode($num){
        if($num < 1) return;
        $factory = new RandomLib\Factory();
        $generator = $factory->getGenerator(new SecurityLib\Strength());
        for($i=1; $i<=$num; $i++){
            $build = true;
            echo "{$i}/$num";
            while ($build){
                $order_id = $generator->generateString(19, "1234567890");
                //检查是否重复
                $getsql = "SELECT id FROM `order_code` WHERE `code`=:code ";
                $getdata = [
                    ':code'  => $order_id
                ];
                $codedata = $this->dao->conn(false)->noCache()->preparedSql($getsql, $getdata)->fetchOne();
                if (empty($codedata)) {
                    $build = false;
                    $sql = "insert into order_code values (null,'{$order_id}')";
                    $res = $this->dao->conn(false)->noCache()->preparedSql($sql, array())->lastInsertId();
                }
                $res = $res ? '成功' : '失败';
                echo "{$res}\n";
            }
        }
    }

    /**
     * @desc    创建订单分表，脚本使用，勿用
     * @param   int     $num    数量
     * @return  boolen  $return 执行结果
     */
    public function createOrderTable($num){
        if($num < 1) return;
        $sql = 'SHOW TABLES';
        $tableNameInfo = $this->dao->conn(false)->noCache()->preparedSql($sql, array())->fetchAll();
        if($tableNameInfo){
            $suffix = 0;
            foreach($tableNameInfo as $k=>$v){
                if(substr($v['Tables_in_xb_account'], 0, 6) == 'order_'){
                    $extend = explode('_', $v['Tables_in_xb_account']);
                    $suffixNum = intval($extend[1]);
                    if(!$suffix || $suffix < $suffixNum) $suffix = $suffixNum;
                }
            }
            if($suffix > 0){
                for($i=1; $i<=$num; $i++){
                    $tableName = 'order_'.($suffix + $i);
                    $sql = "CREATE TABLE `{$tableName}`  (
                      `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '订单id',
                      `order_id` varchar(32) NOT NULL,
                      `externalld` varchar(255) NOT NULL DEFAULT '' COMMENT '收款宝生成的唯一交易流水',
                      `uid` int(10) NOT NULL COMMENT '用户id',
                      `amount` int(11) NOT NULL COMMENT '刷卡金额',
                      `single_fee` decimal(11,2) DEFAULT NULL COMMENT '单笔手续费',
                      `fee` decimal(11,2) DEFAULT '0.00' COMMENT '手续费',
                      `act_fee` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '活动减免手续费',
                      `level` int(1) NOT NULL COMMENT '等级',
                      `rate` decimal(5,4) NOT NULL COMMENT '刷卡费率',
                      `creditbank` varchar(120) NOT NULL COMMENT '刷卡银行',
                      `creditcard` varchar(125) NOT NULL COMMENT '信用卡卡号',
                      `debitcard` varchar(125) NOT NULL COMMENT '收款银行卡卡号',
                      `channel_id` varchar(255) DEFAULT NULL COMMENT '刷卡通道id',
                      `channel_name` varchar(255) DEFAULT NULL COMMENT '刷卡通道名称',
                      `axf_order_no` varchar(32) NOT NULL,
                      `sett_transferway` tinyint(1) DEFAULT NULL COMMENT '结算方式（1：T0自助结算；2：T1自助结算）',
                      `sett_amount` decimal(11,2) NOT NULL COMMENT '结算金额',
                      `sett_fee` decimal(11,2) NOT NULL COMMENT 'T1 自助结算手续费 ',
                      `sett_basic_fee` decimal(11,2) NOT NULL COMMENT 'T0 自助结算基本手续费 ',
                      `sett_extarget_fee` decimal(11,2) NOT NULL COMMENT 'T0 自助结算额外手续费',
                      `actual_amount` decimal(11,2) NOT NULL COMMENT '实际到账金额',
                      `level6` varchar(225) NOT NULL COMMENT '第六上级',
                      `level7` varchar(225) NOT NULL COMMENT '第七上级',
                      `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '订单状态，0，未支付，1，支付成功，2，支付失败,3,结算中',
                      `pay_time` int(10) NOT NULL COMMENT '支付时间',
                      `profit_rate` decimal(5,4) NOT NULL DEFAULT '0.0000' COMMENT '分润最低费率',
                      `is_profit` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否更新分润订单，0未更新，1已更新，2没有分润信息',
                      `create_time` int(10) NOT NULL COMMENT '刷卡时间',
                      `mch_money` decimal(10,2) NOT NULL COMMENT '每笔订单的分润',
                      `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '通道类型：1：内部通道，2：安心付通道',
                      `reason` varchar(255) DEFAULT NULL COMMENT '失败原因',
                      `client_channel` varchar(12) NOT NULL DEFAULT '' COMMENT '提交订单客户端：iOSAPP，安卓APP，公众号',
                      `act_fee1` decimal(11,2) NOT NULL,
                      PRIMARY KEY (`id`),
                      KEY `order_id` (`order_id`) USING BTREE
                    ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;";
                    $res = $this->dao->conn(false)->noCache()->preparedSql($sql, array())->excute();
                    $res = $res ? '成功' : '失败';
                    echo "{$tableName}创建{$res}\n";

                    $tableName = 'profit_'.($suffix + $i);
                    $sql = "CREATE TABLE `$tableName` (
                      `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
                      `uid` int(11) NOT NULL COMMENT '用户id',
                      `order_id` varchar(32) COLLATE utf8_unicode_ci NOT NULL COMMENT '订单id',
                      `reference_no` varchar(32) COLLATE utf8_unicode_ci NOT NULL COMMENT '参考订单号',
                      `from_uid` int(11) NOT NULL COMMENT '刷卡人id',
                      `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '刷卡人姓名',
                      `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL COMMENT '刷卡人手机号',
                      `rate` decimal(5,4) NOT NULL DEFAULT '0.0000' COMMENT '分润费率',
                      `amount` decimal(10,2) NOT NULL COMMENT '返现金额',
                      `surplus_amount` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '变动后账户余额',
                      `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '类型，1为分润，2为提现，3收款红包，4办卡红包....',
                      `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '明细标题（type为3|4时候需要该标题）',
                      `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '提现状态，0：提现中，1：提现失败，2：提现成功',
                      `created_at` varchar(15) COLLATE utf8_unicode_ci NOT NULL COMMENT '返利时间',
                      `create_time` varchar(15) COLLATE utf8_unicode_ci NOT NULL COMMENT '插入时间',
                      PRIMARY KEY (`id`),
                      UNIQUE KEY `uid` (`uid`,`order_id`) USING BTREE
                    ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
                    ";
                    $res = $this->dao->conn(false)->noCache()->preparedSql($sql, array())->excute();
                    $res = $res ? '成功' : '失败';
                    echo "{$tableName}创建{$res}\n";
                }
            }
        }
    }

    /**
     *@desc  订单支付回调处理订单状态 除失败以外创建打款订单
     *@param
     *@return
     */
    public function callBackField($data,$type){
        $time = time();
        //如果支付失败 不创建打款订单  直接修改订单状态 反之创建
        if($data['status'] == 2){
            $sql = "UPDATE `order_".self::$suffix."` set `status` =:status,`reason`=:reason WHERE `axf_order_no` = :axf_order_no";
            $data = array(
                ':status'        =>$data['status'],
                ':axf_order_no' =>$data['axf_order_no'],
                ':reason'        =>$data['msg'],
            );
            $result = $this->dao->conn(false)->noCache()->preparedSql($sql,$data)->affectedCount();
            return $result;
        }else{
            $status = $type == 1 ? 3 : 1;//type=1（推过结算接口） 状态为结算中 反之支付成功
            $this->dao->conn(false)->beginTransaction();
            $play_status = $type==1?0:3;//（推过结算接口）状态为新添加 反之 打款成功
            $play_money_sql = "INSERT INTO `order_play_money` (`channel_id`,`play_money_no`,`order_no`,`uid`,`amount`,`status`,`collection_time`,`create_time`,`rate`,`after_amount`) VALUES(:channel_id,:play_money_no,:order_no,:uid,:amount,:status,:collection_time,:create_time,:rate,:after_amount)";
            $play_data = array(
                ':channel_id'      => $data['channel_id'],
                ':play_money_no'   => $data['order_id'],
                ':order_no'        => $data['axf_order_no'],
                ':uid'             => $data['uid'],
                ':amount'          => $data['amount'],
                ':after_amount'    => $data['after_amount'],
                ':rate'            => $data['rate'],
                ':collection_time' => strtotime($data['paytime']),
                ':create_time'     => $time,
                ':status'          => $play_status,
            );

            $play_result = $this->dao->noCache()->preparedSql($play_money_sql, $play_data)->lastInsertId();
            if(!$play_result){
                $this->dao->rollback();
                return false;
            }

            $sql = "UPDATE `order_".self::$suffix."` set `fee`=:fee ,`externalld`=:externalld,`status`=:status,`actual_amount`=:actual_amount,`pay_time`=:pay_time WHERE `axf_order_no`=:axf_order_no";
            $order_data=array(
                ':fee'           => $data['fee'],
                ':axf_order_no'  => $data['axf_order_no'],
                ':externalld'    => $data['externalld'],
                ':actual_amount' => $data['after_amount'],
                ':pay_time'      => $data['paytime'],
                ':status'        => $status,
            );
            $result = $this->dao->noCache()->preparedSql($sql, $order_data)->affectedCount();
            if(!$result){
                $this->dao->rollback();
                return false;
            }
            $res = $this->dao->commit();
            if($res){
                $this->dao->clearTag(self::$cache_tag);
                return $res;
            }
            return false;
        }
    }
    /*#
     * @desc  结算回调处理订单状态
     * */
    public function  callBackSettlement($data){
        //根据结算请求号获取订单ID
        if($data['status'] == 3){
            $status = 1;
        }elseif(in_array($data['status'],array(4,5,6))){
            $status = 2;
        }else{
            $status = 3;
        }
        $axf_order_no = $this->getOrderByPlayOrderNo($data['play_money_no'])['order_no'];
        $this->dao->conn(false)->beginTransaction();
        $sql = "UPDATE `order_".self::$suffix."` set `status`=:status,`pay_time`=:pay_time,`sett_transferway`=:sett_transferway,`sett_amount`=:sett_amount,`sett_fee`=:sett_fee,`sett_basic_fee`=:sett_basic_fee,`sett_extarget_fee`=:sett_extarget_fee,`actual_amount`=:actual_amount,`reason`=:reason WHERE `axf_order_no`=:axf_order_no";
        $order_data = array(
            ':status'              => $status,
            ':pay_time'            => strtotime($data['pay_time']),
            ':sett_transferway'   => $data['sett_transferway'],
            ':sett_amount'        => $data['sett_amount'],
            ':sett_fee'            => $data['sett_fee'],
            ':sett_basic_fee'      => $data['sett_basic_fee'],
            ':sett_extarget_fee'  => $data['sett_extarget_fee'],
            ':actual_amount'       => $data['actual_amount'],
            ':reason'               => $data['reason'],
            ':axf_order_no'        => $axf_order_no,
        );
        $res = $this->dao->noCache()->preparedSql($sql,$order_data)->affectedCount();
        if(!$res){
            $this->dao->rollback();
            return false;
        }
        $play_money_sql = "UPDATE `order_play_money` set `serial_no`=:serial_no,`uid`=:uid,`status`=:status,`receiver_bank`=:receiver_bank,`receiver_bankcard_no`=:receiver_bankcard_no,`receiver`=:receiver, `pay_time`=:pay_time,`desc`=:desc WHERE `play_money_no`=:play_money_no";
        $play_data = array(
            ':serial_no'              => $data['serial_no'],
            ':uid'                    => $data['uid'],
            ':status'                 => $data['status'],
            ':receiver_bank'         => $data['receiver_bank'],
            ':receiver_bankcard_no'=> $data['receiver_bank_card_no'],
            ':receiver'              => $data['receiver'],
            ':pay_time'              => strtotime($data['pay_time']),
            ':desc'                  => $data['desc'],
            ':play_money_no'        => $data['play_money_no'],
        );
        $play_res = $this->dao->noCache()->preparedSql($play_money_sql,$play_data)->affectedCount();
        if(!$play_res){
            $this->dao->rollback();
            return false;
        }
        $res= $this->dao->commit();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
            return $res;
        }
        return false;
    }
    /**
     * @desc 根据打款订单号获取订单ID
     * */
    public function getOrderByPlayOrderNo($play_money_no){
        $sql = "SELECT * FROM `order_play_money` WHERE `play_money_no`=:play_money_no";
        $data = array(
            ':play_money_no' =>$play_money_no
        );
        return $this->dao->conn()->noCache()->preparedSql($sql,$data)->fetchOne();
    }

    public function createPlayMoneyOrderCode(){
        $factory = new RandomLib\Factory();
        $generator = $factory->getGenerator(new SecurityLib\Strength());
        $order_id = $generator->generateString(19, "1234567890");
        $res = $this->getOrderByPlayOrderNo($order_id);
        if($res){
            $this->createPlayMoneyOrderCode();
        }
        return $order_id;
    }

    /**
     * @desc    根据用户id,信用卡号获取用户刷卡金额
     * @param   int     $uid            用户id
     * @param   string  $creditCard     信用卡卡号
     * @param   string  $status         查询订单状态
     * @return  array   $return         返回搜索信息
     */
    public function countAllAmountByUid($uid, $status, $channel_id, $type, $creditCard, $startTime, $endTime){
        $sql = "SELECT SUM(amount) AS amount FROM `order_".self::$suffix."` WHERE `uid`=:uid AND `status`=:status AND `channel_id`=:channel_id AND `type`=:type AND `creditcard`=:creditcard AND `create_time`>=:startTime AND `create_time`<:endTime";
        $data = array(
            ':uid'        => $uid,
            ':status'     => $status,
            ':channel_id' => $channel_id,
            ':type'       => $type,
            ':creditcard' => $creditCard,
            ':startTime'  => $startTime,
            ':endTime'    => $endTime
        );
        return $this->dao->conn()->noCache(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }
    /**
     * @desc 脚本 获取未支付订单
     * */
    public function getOrderByStatus($status){
        $sql = "SELECT * FROM `order_".self::$suffix."` WHERE `status`=:status AND `create_time`>=:start_time AND `create_time`<=:end_time";
        $start_time = date("Y-m-d",strtotime("-1 day")).' 00:00:00';
        $end_time   = date("Y-m-d",strtotime("-1 day")).' 23:59:59';
        $data = array(
            ':status'=>$status,
            ':start_time'=>strtotime($start_time),
            ':end_time'=>strtotime($end_time),
        );
        return $this->dao->conn()->noCache()->preparedSql($sql,$data)->fetchAll();
    }
    /**
     * @desc 根据订单号获取结算信息
     * */
    public  function getOrderPlayData($order_id){
        $sql = "SELECT * FROM `order_play_money` WHERE `order_no`=:order_no";
        $data = array(
            ':order_no' => $order_id
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }
    /**
     * @desc    根据OrderCode获取跳转链接
     * @param   string     $order_code   订单code码
     * @param   boolean        $is_check     是否检验时间
     * @return  array   $return     返回订单信息
     */
    public function getRecirectByOrderCode($orderCode,$is_check){
        $time = time();
        $sql  = 'SELECT * FROM `order_redirect` WHERE `orderCode`=:orderCode';
        $data = array(
            ':orderCode' => $orderCode
        );

        $res =  $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
        if($res){
            if($is_check){
                $check =  $time - $res['create_time'];
                if($check > 1800){
                    return false;
                }
            }
            return $res;
        }else{
            return false;
        }

    }

    /**
     * 获取最后一次取款时间
     *
     * @param unknown $uid
     * @return string
     */
    public function getLastPlayTime($uid) {
        $uid = (int)$uid;
        $sql = "SELECT MAX(create_time) FROM `order_".self::$suffix."` WHERE uid = {$uid} AND `status` = 1";
        return $this->dao->conn()->noCache()->preparedSql($sql, [])->fetchColumn(0);
    }

    /**
     * 获取第一次取款时间
     *
     * @param unknown $uid
     * @return string
     */
    public function getFirstPlayTime($uid) {
        $uid = (int)$uid;
        $sql = "SELECT MIN(create_time) FROM `order_".self::$suffix."` WHERE uid = {$uid} AND `status` = 1";
        return $this->dao->conn()->noCache()->preparedSql($sql, [])->fetchColumn(0);
    }

    /**
     * 获取所有订单
     *
     * @param
     * @return array    订单列表
     */
    public function getAllOrder() {
        $sql  = 'SELECT * FROM `order_'.self::$suffix.'` ';
        $res = $this->dao->conn()->noCache()->preparedSql($sql, array())->fetchAll();
        return $res;
    }
    /**
     * @desc 获取用户最后一条取款成功的订单
     */
    public function getUserLastOrder($uid,$status){
        $sql = "SELECT * FROM `order_".self::$suffix."` WHERE uid=:uid AND status=:status ORDER BY id desc";
        $data = array(':uid'=>$uid,':status'=>$status);
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }
    /**
     * @desc 获取通道一天的订单数量
     *
     * @param    int     $channel_id       通道ID
     * @param    string  $start_time       开始时间
     * @param    string  $end_time         结束时间
     * @return   array
     */
    public function getTodayOrderBychannelId($channel_id,$start_time,$end_time){
        $sql = "SELECT count(*) as num FROM `order_".self::$suffix."` WHERE `channel_id` in ({$channel_id})  AND `create_time`>=:start_time AND `create_time`<=:end_time";
        $data = array(
            ':start_time'=>$start_time,
            ':end_time'=>$end_time,
        );
        return $this->dao->conn()->noCache()->preparedSql($sql,$data)->fetchOne();
    }
    /**
     * @desc 脚本调用 获取支付成功未分润的订单
     *
     */
    public function getIsProfitOrder($start,$is_profit,$status){
        $sql = 'SELECT * FROM `order_'.self::$suffix.'` WHERE `create_time` >= :start and `is_profit` = :is_profit and status=:status';
        $data = array(
            ':start' => $start,
            ":is_profit"=>$is_profit,
            ':status'=>$status
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc 雅酷收款创建订单
     * */
    public function createCommonOrder($uid, $cid, $amount, $channel_id, $channel_level_id, $channel_type, $merchant_id, $client_channel='', $card_info=array()){
        $order_obj = XbLib_PaymentObjs_Order::getInstance()->userCreateOrder($channel_id, $uid, $cid, $amount, $channel_level_id, $merchant_id, $card_info);
        if (!$order_obj instanceof XbLib_PaymentObjs_Order) {
            return $order_obj;
        }

        $this->dao->conn(false)->beginTransaction();
        if($channel_type == 1){
            $channel_data['order_id'] = $order_obj->param['order_id'];
            $channel_data['time'] = date('YmdHis', $order_obj->param['time']);
            $res_trans = XbLib_ChannelFunc_Channel::getInstance()->createOrder($order_obj->channel->channel_id, $order_obj);
            if(!$res_trans['success']){
                $this->dao->rollback();
                return new XbLib_WebError(400,'通道支付失败');
            }
        }

        $sql = 'INSERT INTO `order_'.self::$suffix.'`(`order_id`, `uid`, `amount`, `level`, `rate`, `creditbank`, `creditcard`, `debitcard`, `channel_id`, `channel_name`, `axf_order_no`, `create_time`, `type`,`single_fee`, `client_channel`) VALUES(:order_id, :uid, :amount, :level, :rate, :creditBank, :creditcard, :debitcard, :channel_id, :channel_name, :axf_order_no, :create_time, :type,:single_fee,:client_channel)';
        $data = array(
            ':order_id'     => $order_obj->param['order_id'],
            ':uid'          => $order_obj->user->uid,
            ':amount'       => $order_obj->param['pay_amount'],
            ':level'        => $order_obj->user->level['level'],
            ':rate'         => $order_obj->param['rate'],
            ':single_fee'   => $order_obj->user->channel_level['fee'],
            ':creditBank'   => $order_obj->user->card['bank'],
            ':creditcard'   => $order_obj->user->card['cardNumber'],
            ':debitcard'    => $order_obj->user->info['bankcardNumber'],
            ':channel_id'   => $order_obj->channel->info['channel_id'],
            ':channel_name' => $order_obj->channel->info['channel_name'],
            ':axf_order_no' => $order_obj->param['order_id'],
            ':create_time'  => $order_obj->param['time'],
            ':type'         => $channel_type,
            ':client_channel' => $client_channel
        );
        $order = $this->dao->noCache()->preparedSql($sql, $data)->lastInsertId();
        if(!$order){
            $this->dao->rollback();
            return new XbLib_WebError(400,'创建订单失败');
        }

        $index_data = array(
            ':order_table_num'  => self::$suffix,
            ':order_table_id'   => $order,
            ':order_id'          => $order_obj->param['order_id'],
            ':uid'                => $order_obj->user->uid,
            ':create_time'       => $order_obj->param['time']
        );
        $order_index = XbModule_Account_OrderIndex::getInstance()->createOrderIndex($index_data);
        if(!$order_index){
            $this->dao->rollback();
            return new XbLib_WebError(400,'创建订单索引失败');
        }

        $res = $this->dao->commit();

        if($res){
            if($order_obj->user->info['mch_id'] == 1 ){
                //收款下单创建分润
                $profit_channel_id = $channel_type==1 ? $order_obj->channel->channel_id : $channel_id;
                $profitUsers = XbModule_Account_UsersInvite::getInstance()->getProfitInfoByUid($uid, $order_obj->user->level['level'], $profit_channel_id, $channel_type);
                if(count($profitUsers) > 0){
                    $profitRes = XbModule_Account_OrderProfit::getInstance()->createProfit($profitUsers, $order, XbModel_Account_Order::$suffix);
                    if(!$profitRes){
                        $log = json_encode($profitUsers);
                        XbFunc_Log::write('profitUserError','创建订单分润信息（分润用户）失败，订单表：'.XbModel_Account_Order::$suffix.'，订单id：'.$res['orderId'], '用户信息：'.$log);
                    }
                }
            }

            $this->dao->clearTag(self::$cache_tag);
            return array('order_id'=>$order_obj->param['order_id']);
        }
        return new XbLib_WebError(400, '下单失败');
    }


    /**
     * @desc 雅酷收款支付回调
     * */
    public function yakuCallBackField($status, $order_index, $callback_data){
        $order_obj = XbLib_PaymentObjs_Order::getInstance()->userCreatePayOrder($order_index);
        if (!$order_obj instanceof XbLib_PaymentObjs_Order) {
            return $order_obj;
        }

        if($status == 1){
            //支付成功
            if ($order_obj->order['status'] != 0){
                //已调用代付

            }else{
                //发起代付
                $res_withdraw = XbLib_ChannelFunc_Channel::getInstance()->settlement($order_obj->channel->channel_id,$order_obj);

                if ($res_withdraw['success']){
                    $play_money_sql = "INSERT INTO `order_play_money` (`channel_id`,`play_money_no`,`order_no`,`uid`,`amount`,`status`,`collection_time`,`create_time`,`rate`,`after_amount`) VALUES(:channel_id,:play_money_no,:order_no,:uid,:amount,:status,:collection_time,:create_time,:rate,:after_amount)";
                    $play_data = array(
                        ':channel_id'      => $order_obj->channel->channel_id,
                        ':play_money_no'   => $order_obj->param['order_id'],
                        ':order_no'        => $order_obj->order['order_id'],
                        ':uid'             => $order_obj->user->uid,
                        ':amount'          => $order_obj->order['amount'],
                        ':after_amount'    => $order_obj->param['custom_amount'],
                        ':rate'            => $order_obj->param['single_fee'],
                        ':status'          => 0,
                        ':collection_time' => $callback_data['pay_time'],
                        ':create_time'     => $order_obj->param['time'],
                    );
                    $play_result= $this->dao->conn(false)->noCache()->preparedSql($play_money_sql, $play_data)->lastInsertId();
                    $order_data=array(
                        ':externalld'    => $callback_data['serial_no'],
                        ':fee'           => $order_obj->param['fee'],
                        ':actual_amount' => $order_obj->param['custom_amount'],
                        ':status'        => 3,
                        ':pay_time'      => $callback_data['pay_time'],
                        ':reason'        => $callback_data['msg'],
                        ':order_id'      => $order_obj->order['order_id'],
                    );
                }
            }
        }else{
            //支付失败
            $order_data=array(
                ':externalld'    => $callback_data['serial_no'],
                ':fee'           => '',
                ':actual_amount' => '',
                ':status'        => 2,
                ':pay_time'      => $callback_data['pay_time'],
                ':reason'        => $callback_data['msg'],
                ':order_id'      => $order_obj->order['order_id'],
            );
        }

        if ($order_data) {
            $sql = "UPDATE `order_".self::$suffix."` set `fee`=:fee ,`externalld`=:externalld,`status`=:status,`actual_amount`=:actual_amount,`pay_time`=:pay_time,`reason`=:reason WHERE `order_id`=:order_id";
            $this->dao->conn(false)->noCache()->preparedSql($sql, $order_data)->affectedCount();
            $this->dao->clearTag(self::$cache_tag);
        }

        return $play_result;
    }
    /**
     * @desc 雅酷收款代付回调
     * */
    public function yakuCallBackSettlement($status, $order_index, $order_play, $callback_data){
        $order_obj = XbLib_PaymentObjs_Order::getInstance()->userFinishOrder($status, $order_index, $order_play);
        if (!$order_obj instanceof XbLib_PaymentObjs_Order) {
            return $order_obj;
        }

        $order_sql = "UPDATE `order_" . self::$suffix . "` SET `status`=:status  WHERE `order_id`=:order_id ";
        $order_param[':status'] = $order_obj->param['order_data']['status'];
        $order_param[':order_id'] = $order_obj->order['order_id'];
        $res_order = $this->dao->conn(false)->noCache()->preparedSql($order_sql, $order_param)->affectedCount();

        $play_sql = "UPDATE `order_play_money` SET `status`=:status,`serial_no`=:serial_no  WHERE `play_money_no`=:play_money_no ";
        $play_param[':status'] = $order_obj->param['play_data']['status'];
        $play_param[':serial_no'] = $callback_data['serial_no'];
        $play_param[':play_money_no'] = $order_play['play_money_no'];
        $res_play = $this->dao->conn(false)->noCache()->preparedSql($play_sql, $play_param)->affectedCount();

        $this->dao->clearTag(self::$cache_tag);

        if ($order_obj->user->info['mch_id'] == 1 ){
            //收款成功修改分润
            $res_profit = XbModule_Account_Order::getInstance(self::$suffix)->synOrderProfit($order_obj->order['order_id'], $order_obj->user->uid, $order_obj->order['rate'], $order_obj->order['amount'], $order_obj->order['id']);
        }

        return $res_play;
    }

}
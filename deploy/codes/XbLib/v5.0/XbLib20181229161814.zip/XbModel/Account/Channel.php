<?php
/**
 * @desc 	渠道相关
 * @author  yurong
 * @date    18.03.12
 */
class XbModel_Account_Channel extends XbModel_BaseModel{
    public static $cache_tag = "Account_Common_Channel_";
    public static $cache_expire = 259200;
    function __construct() {
        parent::_init("xb_account");
    }

    /**
     * @desc    获取渠道列表
     * @param   int     $channel_tag      有无积分（1：有积分；2：无积分）
     * @param   int     $type             通道类型
     * @param   int     $start            偏移量
     * @param   int     $limit            每页显示条数
     * @return  array   $return           返回执行结果
     */
    public function getChannelList($channel_tag,$type,$start,$limit){
        $time = time();
        $sql = 'SELECT * FROM `common_channel` WHERE create_time<'.$time;
        $data=[];
        if(!empty($channel_tag) && $channel_tag==1){
            $sql .= ' AND with_integral=:with_integral';
            $data[':with_integral'] = $channel_tag;
        }
        if(is_numeric($channel_tag) &&  $channel_tag==0){
            $sql .= ' AND with_integral=:with_integral';
            $data[':with_integral'] = 2;
        }
        if(!empty($type)){
            $sql .= ' AND type=:type';
            $data[':type'] = $type;
        }
        $sql .=' LIMIT :start,:limit';
        $data[':start'] = $start;
        $data[':limit'] = $limit;
        $res =  $this->dao->conn()->expire(self::$cache_expire)->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
        if($res){
            return $res;
        }
        return false;
    }
    /**
     * @desc  获取渠道数量
     * @param   int     $channel_tag      有无积分（1：有积分；2：无积分）
     * @param   int     $type             通道类型
     */
    public function getChannelCount($channel_tag,$type){
        $time = time();
        $sql = 'SELECT count(*) as num FROM `common_channel` WHERE create_time<'.$time;
        $data=[];
        if(!empty($channel_tag) && $channel_tag==1){
            $sql .= ' AND with_integral=:with_integral';
            $data[':with_integral'] = $channel_tag;
        }
        if(is_numeric($channel_tag) &&  $channel_tag==0){
            $sql .= ' AND without_integral=:without_integral';
            $data[':without_integral'] = $channel_tag;
        }
        if(!empty($type)){
            $sql .= ' AND type=:type';
            $data[':type'] = $type;
        }
        return $this->dao->conn()->expire(self::$cache_expire)->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    public function getChannelDetail($id){
        $sql = 'SELECT * FROM `common_channel` WHERE id = :id';
        $data[':id'] = $id;
        return $this->dao->conn()->expire(self::$cache_expire)->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();

    }
    /**
     * @desc  编辑通道信息
     * @param    array       $data      存储信息
     * @return   boolean     $return    返回执行结果
     */
    public function edit($id,$channel_id,$channel_name,$timelines,$type,$with_integral,$without_integral,$is_settlement,$time,$week,$rate_cost,$without_rate_cost,$service_cost,$status,$desc,$channel_day_max_charge){
        $update_time = time();
        $sql = "UPDATE `common_channel` set channel_id = :channel_id,channel_name=:channel_name,timelines=:timelines,type=:type,with_integral=:with_integral,without_integral=:without_integral,time=:time,week=:week,rate_cost=:rate_cost,without_rate_cost=:without_rate_cost,service_cost=:service_cost,status=:status,`desc`=:desc,update_time=:update_time,`channel_day_max_charge`=:channel_day_max_charge WHERE id =:id";
        $data=array(
            ':channel_id'=>$channel_id,
            ':channel_name'=>$channel_name,
            ':timelines'=>$timelines,
            ':type'=>$type,
            ':with_integral'=>$with_integral,
            ':without_integral'=>$without_integral,
//            ':is_settlement'=>$is_settlement,
            ':time'=>$time,
            ':week'=>$week,
            ':rate_cost'=>$rate_cost,
            ':without_rate_cost'=>$without_rate_cost,
            ':service_cost'=>$service_cost,
            ':status'=>$status,
            ':desc'=>$desc,
            ':id'=>$id,
            ':update_time'=>$update_time,
            ':channel_day_max_charge'=>$channel_day_max_charge,
        );
        $res =  $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
            return $res;
        }
        return false;
    }

    /**
     * @desc    根据channel_id获取渠道信息
     * @param   int     $channel_id     渠道channnel_id
     * @return  array   $return         返回渠道信息
     */
    public function getChannelByChannelid($channel_id){
        $sql = 'SELECT * FROM `common_channel` WHERE `channel_id`=:channel_id';
        $data = array(
            ':channel_id' => $channel_id
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    根据等级获取相关通道
     * @param   int     $level_id       用户等级
     * @param   int     $status         状态|默认开启状态
     * @param   string  $channel_id         状态|默认开启状态
     * @return  array   $return         返回搜索结果
     */
    public function getChannelInfoByLevel($level_id, $status=1, $channel_id=''){
        $sql = 'SELECT ccl.id as cclid, ccl.type AS ccltype, ccl.level_id, ccl.rate, ccl.fee, cc.* FROM `common_channel_level` ccl LEFT JOIN `common_channel` cc ON cc.channel_id=ccl.channel_id WHERE `ccl`.`level_id`=:level_id AND `cc`.`status`=:status';
        $data = array(
            ':level_id' => $level_id,
            ':status'   => $status
        );
        if(!empty($channel_id)){
            $sql .= ' AND `cc`.`channel_id` IN ('.$channel_id.')';
        }
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    根据channel_level_id获取渠道信息
     * @param   int     $channel        channel_level_id
     * @param   int     $status         通道状态
     * @return  array   $return         返回渠道信息
     */
    public function getChannelInfoByChannelLevel($channel, $status=''){
        $sql = 'SELECT ccl.id AS cclid, ccl.type AS ccltype, ccl.level_id, ccl.rate, ccl.fee, cc.*  FROM `common_channel_level` ccl LEFT JOIN `common_channel` cc ON cc.channel_id=ccl.channel_id WHERE `ccl`.`id`=:id';
        $data = array(
            ':id' => $channel
        );
        if(!empty($status)){
            $sql .= ' AND `cc`.`status`=:status';
            $data[':status'] = $status;
        }
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    根据channel_id获取渠道信息
     * @param   int     $channel_id     渠道channnel_id
     * @param   int     $level          相关等级
     * @return  array   $return         返回渠道信息
     */
    public function getChannelByChannelidLevel($channel_id, $level){
        $sql = 'SELECT * FROM `common_channel_level` WHERE `channel_id`=:channel_id AND `level_id`=:level_id';
        $data = array(
            ':channel_id' => $channel_id,
            ':level_id'   => $level
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }
    /**
     * @desc 获取可用通道
     * @param  int    $status   通道状态
     * @return  array $return   返回执行结果
     * */
    public function getChannel($status){
        $sql = "SELECT * FROM  `common_channel` WHERE `status`=:status";
        $data = array(
            ':status'=>$status
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
    }
    /**
     * @desc 获取通道支持银行卡列表
     * @param   int     $channel_id   通道ID
     * @param   int     $type         银行卡类型：1：信用；2：储蓄卡
     * */
    public  function getChannelBankList($channel_id,$type){
        $sql = "SELECT * FROM `common_channel_bank` WHERE `channel_id` = :channel_id AND `type`=:type AND `status`=:status";
        $data = array(
            ':channel_id' => $channel_id,
            ':type'        =>$type,
            ':status'        =>1
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
    }
    /**
     * @desc 编辑通道开关状态
     * @param     int     $channel_id   通道ID
     * @param     int     $end_time     结束时间
     * @return    boolean $return       返回执行结果
     * */
    public function changeChannelStatus($channel_id,$end_time){
        $time = time();
        $sql = " select * from `common_channel` where `channel_id`=:channel_id ";
        $data = array(
            ':channel_id' => $channel_id
        );
        $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
        if($res){
            $end_time = $end_time ? $end_time :date('H:i',$time);
            $res_time = explode('-',$res['time']);
            $end_time = $res_time[0].'-'.$end_time;
            $sql = ' UPDATE `common_channel` set `time` = :time,`update_time`=:update_time where `channel_id`=:channel_id';
            $up_data = array(
                ':time'  => $end_time,
                ':update_time'  => $time,
                ':channel_id'=>$channel_id
            );
            $result =  $this->dao->conn(false)->noCache()->preparedSql($sql,$up_data)->affectedCount();
            if($result){
                $this->dao->clearTag(self::$cache_tag);
            }
            return $result;
        }
        return false;
    }
    /**
     * @desc 获取前一天关闭的通道
     * @param     string   $start_time  开始时间
     * @param     string   $end_time    结束时间
     * @return    array    $return      返回执行结果
     * */
    public function getChannelByUpdateTime($start_time,$end_time,$channel_id){
        $sql = "select * from `common_channel` WHERE channel_id in ($channel_id) AND `update_time`>= '$start_time'  AND `update_time`<= '$end_time' ";
        $data = [];
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
    }

    /**
     * @desc 获取开启的通道支持的银行卡
     * @return    array    $return      返回执行结果
     */
    public function getChannelBank(){
        $res_channel = XbModule_Account_Channel::getInstance()->getChannel(1);

        //是否是第一次取值
        $is_first = 0;
        //支持的银行卡
        $res_bank = array();

        foreach ($res_channel as $k => $v) {
            //获取当前通道支持的银行卡
            $res_cannel_bank = XbModule_Account_Channel::getInstance()->getChannelBankList($v['id'], 2);
            if ( empty($res_cannel_bank) ) {
                continue;
            }
            //将通道支持的银行卡表的bankCode组装为数组
            $bank_arr = array();
            foreach ($res_cannel_bank as $key => $val){
                $bank_arr[$val['bankCode']] = $val['bank'];
            }

            if ($is_first == 0) {
                $res_bank = $bank_arr;//第一次取值,直接赋值
            } else {
                $res_bank = array_intersect_key($res_bank, $bank_arr);//取所有通道支持银行卡的交集
            }
            $is_first = 1;
        }

        return $res_bank;

    }

    /**
     * @desc 获取所有通道支持的银行卡
     * @return    array    $return      返回执行结果
     */
    public function getChannelAllBank(){
        $sql = "select * from `common_channel_bank` where `type` = 2 group by `bankCode` ";
        $data = [];
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
    }
}
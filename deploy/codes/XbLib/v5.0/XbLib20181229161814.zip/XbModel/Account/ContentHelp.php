<?php
/**
 * @desc  内容管理-帮助中心
 * User: zq
 * Date: 19/6/18
 * Time: 12:03
 */
class XbModel_Account_ContentHelp extends XbModel_BaseModel{
    static $cache_tag = "Account_Content_Help_";

    //链接库
    function __construct() {
        parent::_init("xb_account");
//        self::$cache_tag = time();
    }

    /**
     * @desc 获取奖励策略管理列表
     * @param    int       $id          id
     * @param    string    $title       奖励名称
     * @param    int       $award_type  奖励类型
     * @return   array     $return      返回执行结果
     * */
    public  function getList($help_type, $title, $page,$mch_id){
        $sql_search = "select * from `content_help` WHERE 1=1";
        $sql_count  = "select count(*) as count from `content_help` where  1=1";
        $sql = '';
        $param = [];
        if($help_type){
            $sql .= " AND `help_type` = :help_type";
            $param['help_type'] = $help_type;
        }
        if($title){
            $sql .= " AND `title` LIKE :title";
            $param[':title'] = "%{$title}%";
        }
        if($mch_id){
            $sql .= " AND `mch_id` = :mch_id";
            $param['mch_id'] = $mch_id;
        }
        if(isset($page['offset']) && isset($page['limit'])){
            $sql .= " ORDER BY `sort` desc ";
            $sql .=" limit :offset,:limit";
            $param[':offset'] = $page['offset'];
            $param[':limit']  = $page['limit'];
            $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_search.$sql,$param)->fetchAll();
        } else {
            $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_count.$sql,$param)->fetchOne()['count'];
        }
        return $res;
    }

    /**
     * @desc 获取帮助中心一条问题
     * @param    int       $id          id
     * @return   array     $return      返回执行结果
     * */
    public function getHelpById($id){
        $sql_search = "select * from `content_help` WHERE id=$id";
        $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_search,array())->fetchOne();
        return $res;
    }

    /**
     * @desc 修改问题与内容
     * @param    int       $id          id
     * @param    int       $help_type   问题类型
     * @param    string    $title       问题标题
     * @param    int       $content_type内容类型
     * @param    string    $text        文本
     * @param    string    $image       图片地址
     * @param    int       $sort        排序
     * @param    int       $is_use      是否启用
     * @param    int       $is_hot      是否热门推荐
     * @return   array     $return      返回执行结果
     * */
    public function editHelp($id, $help_type, $title, $content_type, $text, $image, $sort, $is_use, $is_hot){
        $param = compact('id','help_type', 'title', 'content_type', 'text', 'image', 'sort', 'is_use', 'is_hot');
        $sql = 'UPDATE `content_help` SET `help_type`=:help_type,`title`=:title,`content_type`=:content_type,`text`=:text,`image`=:image,`sort`=:sort,`is_use`=:is_use,`is_hot`=:is_hot  WHERE `id`=:id';
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql,$param)->affectedCount();

        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }

        return $res;
    }

    /**
     * @desc 添加问题与内容
     * @param    int       $help_type   问题类型
     * @param    string    $title       问题标题
     * @param    int       $content_type内容类型
     * @param    string    $text        文本
     * @param    string    $image       图片地址
     * @param    int       $sort        排序
     * @param    int       $is_use      是否启用
     * @param    int       $is_hot      是否热门推荐
     * @return   array     $return      返回执行结果
     * */
    public function addHelp($help_type, $title, $content_type, $text, $image, $sort, $is_use, $is_hot,$mch_id){
        $param = compact('help_type', 'title', 'content_type', 'text', 'image', 'sort', 'is_use', 'is_hot','mch_id');
        $param['create_time']   = time();
        $sql = 'INSERT INTO  `content_help` (`help_type`,`title`,`content_type`,`text`,`image`,`sort`,`is_use`,`is_hot`,`create_time`,`mch_id`) values(:help_type,:title,:content_type,:text,:image,:sort,:is_use,:is_hot,:create_time,:mch_id)';
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql,$param)->lastInsertId();

        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /**
     * @desc 设置是否推荐问题
     * @param    int       $id          id
     * @param    string    $is_hot      是否推荐
     * @return   array     $return      返回执行结果
     * */
    public function editHelpHot($id, $is_hot){
        $sql = 'UPDATE `content_help` SET `is_hot`=:is_hot  WHERE `id`=:id';
        $param = array('id'=>$id,'is_hot'=>$is_hot);
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql,$param)->affectedCount();

        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }

        return $res;
    }

    /**
     * @desc 删除问题
     * @param    int       $id          id
     * @return   array     $return      返回执行结果
     * */
    public function deleteHelp($id){
        $sql = 'DELETE FROM `content_help` WHERE `id`=:id';
        $param = array('id'=>$id);
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql,$param)->affectedCount();

        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }

        return $res;
    }

    /**
     * @desc 获取热门问题
     * @return   array     $return      返回执行结果
     * */
    public function getHotHelp($mch_id){
        $sql_search = "select * from `content_help` WHERE `is_hot` = 1 AND `is_use` = 1 and mch_id = :mch_id order by sort desc";
        $data = array(
            ':mch_id' => $mch_id
        );
        $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_search,$data)->fetchAll();
        return $res;
    }

    /**
     * @desc 获取指定问题类型的问题列表
     * @param    int       $help_type    问题类型
     * @return   array     $return      返回执行结果
     * */
    public function getHelpByHelpType($help_type,$mch_id){
        $sql_search = "select * from `content_help` WHERE `help_type` = $help_type AND `is_use` = 1 AND mch_id=:mch_id order by sort desc";
        $data = array(
            ':mch_id'=>$mch_id
        );
        $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_search,$data)->fetchAll();
        return $res;
    }

    /**
     * @desc 判断sort是否已经存在
     * @param    int       $id          问题id
     * @param    int       $sort        输入的sort 值
     * @return   array     $return      返回执行结果
     * */
    public function getSortIsHave($id, $sort){
        if ($sort == 0){
            return true;
        }
        $sql = "select sort from `content_help` WHERE sort=:sort";
        $param['sort'] = $sort;
        if($id){
            $sql .= " AND `id` != :id";
            $param['id'] = $id;
        }
        $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$param)->fetchOne();
        if (!empty($res)){
            return true;
        } else {
            return false;
        }
    }

    /**
     * @desc 获取排序值
     * @param    int       $id          问题id
     * @param    int       $sort        输入的sort 值
     * @return   array     $return      返回执行结果
     * */
    public function getNewSort($id, $sort){
        $sql = "select sort from `content_help` order by `sort` desc ";
        $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,array())->fetchOne();
        return $res['sort'] + 1;
    }
}

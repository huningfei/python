<?php

/*
 * common_channel_bank 表模型
 * 
 */


class XbModel_Account_CommonChannelBank extends XbModel_BaseModel{
    //链接库
    public function __construct() {
        parent::_init("xb_account");
    }
    
    public static $typeList = [
        '1' => '信用卡',
        '2' => '储蓄卡'
    ];
    
    public static $statusList = [
        '1' => '可用',
        '2' => '不可用'
    ];
    
    /**
     * 查询通道银行列表
     * 
     * @param string $channel_id
     * @param string $type
     * @param string $bank_code
     * @param string $status
     * @param number $limit
     * @param number $offset
     * @return array
     */
    public function listBank($channel_id = '', $type = '', $bank_code = '', $status = '', $offset = 0, $limit = 30) {
        $where = [];
        if ($channel_id !== '') $where['channel_id'] = $channel_id;
        
        if ($type !== '') $where['type'] = $type;
        
        if ($bank_code !== '') $where['bankCode'] = $bank_code;
        
        if ($status != '') $where['status'] = $status;
        
        $sql = 'SELECT * FROM common_channel_bank ';
        
        $data = [];
        $whereSql = [];
        foreach ($where as $column => $value) {
            $data[':' . $column] = $value;
            $whereSql[] = "`{$column}` = :{$column}";
        }
        
        if ($whereSql) $sql .= ' WHERE ' . implode(' AND ', $whereSql);
 
        $sql .= " LIMIT {$offset},{$limit}";

        $bank = $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
        
        return $bank ? $bank : [];
    }
    
    /**
     * 统计通道银行设置
     *
     * @param string $channel_id 通道id
     * @param string $type 银行卡类型（1：信用卡；2：储蓄卡）
     * @param string $bank_code 银行编号
     * @param string $status 状态（1：可用;0;不可用）
     * @return string
     */
    public function countBank($channel_id = '', $type = '', $bank_code = '', $status = '') {
        $where = [];
        if ($channel_id !== '') $where['channel_id'] = $channel_id;
        
        if ($type !== '') $where['type'] = $type;
        
        if ($bank_code !== '') $where['bankCode'] = $bank_code;
        
        if ($status != '') $where['status'] = $status;
        
        $sql = 'SELECT COUNT(*) FROM common_channel_bank ';
        
        $data = [];
        $whereSql = [];
        foreach ($where as $column => $value) {
            $data[':' . $column] = $value;
            $whereSql[] = "`{$column}` = :{$column}";
        }
        
        if ($whereSql) $sql .= ' WHERE ' . implode(' AND ', $whereSql);
        
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchColumn(0);
    }
    
    /**
     * 获取全部通道
     *
     * @return multitype:[]
     */
    public function getChannelList() {
        $sql = 'SELECT channel_id, channel_name FROM common_channel';
        $data =  $this->dao->conn()->noCache()->preparedSql($sql, [])->fetchAll();
        $rtn = [];
        foreach ($data as $item)
        {
            $rtn[$item['channel_id']] = $item['channel_name'];
        }
        
        return $rtn;
    }
    
    /**
     * 创建通道银行设置
     *
     * @param unknown $channe_id 通道id
     * @param unknown $type 银行卡类型（1：信用卡；2：储蓄卡）
     * @param unknown $bank_code 银行编号
     * @param unknown $min_charge 单笔最小交易额度
     * @param unknown $max_charge 单笔最大交易额度
     * @param unknown $day_max_charge 单日单卡最大交易额度
     * @param unknown $month_max_charge 单月单卡最大交易额度
     * @param unknown $status 状态（1：可用;0;不可用）
     * @return boolean|string
     */
    public function createChannelBank($channel_id, $type, $bank_code, $min_charge, $max_charge, $day_max_charge, $month_max_charge, $status) {
        $bank = XbLib_Bank::$bankType[$bank_code];
 
        if (!$channel_id || !$type || !$bank) return false;
        
        $sql = 'INSERT INTO `common_channel_bank` '; 
        $sql .= '(`channel_id`, `type`, `bankCode`, `bank`, `mininum_charge`, `maxnum_charge`, `card_day_max_charge`, `card_month_max_charge`, `status`, `create_time`) ';
        $sql .= ' VALUES (:channel_id, :type, :bankCode, :bank, :mininum_charge, :maxnum_charge, :card_day_max_charge, :card_month_max_charge, :status, :create_time)';
        
        $data = [
            ':channel_id' => $channel_id, 
            ':type' => $type, 
            ':bankCode' => $bank_code, 
            ':bank' => $bank, 
            ':mininum_charge' => $min_charge, 
            ':maxnum_charge' => $max_charge, 
            ':card_day_max_charge' => $day_max_charge, 
            ':card_month_max_charge' => $month_max_charge, 
            ':status' => $status, 
            ':create_time' => time()
        ];
        
        
        
        $rtn = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
        
        return $rtn ? $rtn : false;
    }
    
    /**
     * 更新银行通道设置
     *
     * @param unknown $id 记录id
     * @param unknown $channe_id 通道id
     * @param unknown $type 银行卡类型（1：信用卡；2：储蓄卡）
     * @param unknown $bank_code 银行编号
     * @param unknown $min_charge 单笔最小交易额度
     * @param unknown $max_charge 单笔最大交易额度
     * @param unknown $day_max_charge 单日单卡最大交易额度
     * @param unknown $month_max_charge 单月单卡最大交易额度
     * @param unknown $status 状态（1：可用;0;不可用）
     * @return boolean|number
     */
    public function updateChannelBank($id, $channel_id, $type, $bank_code, $min_charge, $max_charge, $day_max_charge, $month_max_charge, $status) {
        $bank = XbLib_Bank::$bankType[$bank_code];
       
        if (!$channel_id || !$type || !$bank) return false;
        
        $sql = 'UPDATE `common_channel_bank` ';
        $sql .= ' SET `channel_id` = :channel_id, `type` = :type, `bankCode` = :bankCode, `bank` = :bank, `mininum_charge` = :mininum_charge, `maxnum_charge` = :maxnum_charge, `card_day_max_charge` = :card_day_max_charge, `card_month_max_charge` = :card_month_max_charge, `status` = :status ';
        $sql .= ' WHERE `id` = :id';
        
        $data = [
            ':id' => $id,
            ':channel_id' => $channel_id,
            ':type' => $type,
            ':bankCode' => $bank_code,
            ':bank' => $bank,
            ':mininum_charge' => $min_charge,
            ':maxnum_charge' => $max_charge,
            ':card_day_max_charge' => $day_max_charge,
            ':card_month_max_charge' => $month_max_charge,
            ':status' => $status,
        ];

        $rtn = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        
        return $rtn ? $rtn : false;
    }
    
    /**
     * 获取单个银行设置
     *
     * @param unknown $id
     * @return mixed|multitype:|unknown
     */
    public function getChannelBank($id) {
        $sql = 'SELECT * FROM common_channel_bank WHERE id = :id';
        $data = ['id' => $id];
        $rtn = $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
        
        return $rtn;
    }
    
    /**
     * 删除设置记录
     *
     * @param unknown $id
     * @return number
     */
    public function deleteChannelBank($id) {
        $sql = 'DELETE FROM common_channel_bank WHERE id = :id';
        $data = ['id' => $id];
        $rtn = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        
        return $rtn;
    }
}
    
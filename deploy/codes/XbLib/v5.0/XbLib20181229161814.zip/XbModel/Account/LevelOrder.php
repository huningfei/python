<?php
/**
* @desc     购买等级订单
* @author   qien
* @date     18.01.22
*/
class XbModel_Account_LevelOrder extends XbModel_BaseModel{
    public static $cache_tag = "Account_Level_Order_";
    public static $cache_expire = 259200;
    function __construct() {
        parent::_init("xb_account");
    }

    /**
     * @desc    创建购买等级订单，用户升级
     * @return  boolen  $return     返回执行结果
     */
    public function createLevelOrder($order_id, $payId, $payType, $uid, $mch_id, $oldLevel, $oldLevelName, $buyLevel, $buyLevelName, $amount, $profit, $paytime, $status, $description, $authorName){
        $time = time();
        $sql  = 'INSERT INTO `level_order`(`order_id`, `pay_id`, `pay_type`, `uid`, `mchId`, `oldLevel`, `oldLevelName`, `buyLevel`, `buyLevelName`, `amount`, `profit`, `pay_time`, `status`, `description`, `create_time`) VALUES(:order_id, :pay_id, :pay_type, :uid, :mchId, :oldLevel, :oldLevelName, :buyLevel, :buyLevelName, :amount, :profit, :pay_time, :status, :description, :create_time)';
        $data = array(
            ':order_id'     => $order_id,
            ':pay_id'       => $payId,
            ':pay_type'     => $payType,
            ':uid'          => $uid,
            ':mchId'        => $mch_id,
            ':oldLevel'     => $oldLevel,
            ':oldLevelName' => $oldLevelName,
            ':buyLevel'     => $buyLevel,
            ':buyLevelName' => $buyLevelName,
            ':amount'       => $amount,
            ':profit'       => $profit,
            ':pay_time'     => $paytime,
            ':status'       => $status,
            ':description'  => $description,
            ':create_time'  => $time
        );
        $lastId = $this->dao->conn(false)->noCache()->preparedSql($sql,$data)->lastInsertId();
        if($lastId){
            $this->dao->clearTag(self::$cache_tag);
            $this->createLevelOrderLog($lastId, 1, array('创建购买等级订单'), $authorName);
        }
        return $lastId;
    }

    public function updateLevelOrder($id, $payId, $payType, $buyLevel, $buyLevelName, $amount, $profit, $paytime, $description, $updateField, $authorName){
        $time = time();
        $sql  = 'UPDATE `level_order` SET ';
        if($updateField['level']){
            $sql .= ' `buyLevel`=:buyLevel, `buyLevelName`=:buyLevelName, `amount`=:amount, `profit`=:profit,';
            $data[':buyLevel']     = $buyLevel;
            $data[':buyLevelName'] = $buyLevelName;
            $data[':amount']       = $amount;
            $data[':profit']       = $profit;
        }
        if($updateField['payId']){
            $sql .= ' `pay_id`=:pay_id,';
            $data[':pay_id'] = $payId;
        }
        if($updateField['payTime']){
            $sql .= ' `pay_time`=:pay_time,';
            $data[':pay_time'] = $paytime;
        }
        if($updateField['description']){
            $sql .= ' `description`=:description,';
            $data[':description'] = $description;
        }
        $sql .= ' `update_time`=:update_time WHERE `id`=:id';
        $data[':update_time'] = $time;
        $data[':id']          = $id;
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql,$data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
            $this->createLevelOrderLog($id, 2, $updateField, $authorName);
        }
        return $res;
    }

    /**
     * @desc    根据uid获取购买等级记录
     * @param   int     $uid    用户id
     * @return  array   $return 返回记录
     */
    public function getLevelOrderByUid($uid, $status=''){
        $sql  = 'SELECT * FROM `level_order` WHERE `uid`=:uid';
        $data = array(
            ':uid' => $uid
        );
        if($status !== ''){
            $sql .= ' AND `status`=:status';
            $data[':status'] = $status;
        }
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
    }

    /**
     * @desc    获取等级购买页面
     * @param   int     $mchId      商户id
     * @param   string  $telephone  商户手机号
     * @param   int     $buyLevel   购买等级
     * @param   string  $startTime  搜索开始时间
     * @param   string  $endTime    搜索结束时间
     * @param   int     $status     订单状态
     * @return  array   $return     返回搜索信息
     */
    public function getAllLevelOrder($realname='',$start='', $limit='', $count=false, $status='', $mchId='', $uid='', $buyLevel='', $startTime='', $endTime=''){
        if($count){
            $sql  = 'SELECT COUNT(*) AS num FROM `level_order` WHERE 1';
        }else{
            $sql  = 'SELECT * FROM `level_order` WHERE 1';
        }
        $data =array();
        if($realname !=''){
            $user_id = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql("SELECT uid FROM users_profile WHERE realname = :realname", array(':realname' => $realname))->fetchAll();
            if (!$user_id)
            {
                if($count) {
                    return array(0 => array('num' => 0));
                }else{
                    return array();
                }
            }

            foreach ($user_id as $item)
            {
                $in_uid[] = $item['uid'];
            }
        }
        if ($in_uid)
        {
            $sql .= ' AND uid in (' . implode(',', $in_uid) . ')';
        }
        if($mchId !== ''){
            $sql .= ' AND `mchId`=:mchId';
            $data[':mchId'] = $mchId;
        }
        if($uid !== ''){
            $sql .= ' AND `uid`=:uid';
            $data[':uid'] = $uid;
        }
        if($buyLevel !== ''){
            $sql .= ' AND `buyLevel`=:buyLevel';
            $data[':buyLevel'] = $buyLevel;
        }
        if($startTime !== ''){
            $sql .= ' AND `pay_time`>=:startTime';
            $data[':startTime'] = $buyLevel;
        }
        if($endTime !== ''){
            $sql .= ' AND `pay_time`<=:endTime';
            $data[':endTime'] = $endTime;
        }
        if($status !== ''){
            $sql .= ' AND `status`=:status';
            $data[':status'] = $status;
        }
        $sql .= ' ORDER BY pay_time DESC';
        if($start !== ''){
            $sql .= ' LIMIT :start,:limit';
            $data[':start'] = $start;
            $data[':limit'] = $limit;
        }
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
    }

    /**
     * @desc    获取订单|订单分润总金额
     */
    public function getTotalAmount($realname,$profit=false, $status='', $mchId='', $uid='', $buyLevel='', $startTime='', $endTime=''){
        if(!$profit){
            $sql  = 'SELECT SUM(`amount`) AS num FROM `level_order` WHERE 1';
        }else{
            $sql  = 'SELECT SUM(`profit`) AS num FROM `level_order` WHERE 1';
        }
        $data = array();
        if($realname !=''){
            $user_id =$this->dao->conn()->setTag(self::$cache_tag)->preparedSql("SELECT uid FROM users_profile WHERE realname = :realname", array(':realname' => $realname))->fetchAll();

            if (!$user_id)
            {
                return array();
            }

            foreach ($user_id as $item)
            {
                $in_uid[] = $item['uid'];
            }
        }
        if ($in_uid)
        {
            $sql .= ' AND uid in (' . implode(',', $in_uid) . ')';
        }
        if($mchId !== ''){
            $sql .= ' AND `mchId`=:mchId';
            $data[':mchId'] = $mchId;
        }
        if($uid !== ''){
            $sql .= ' AND `uid`=:uid';
            $data[':uid'] = $uid;
        }
        if($buyLevel !== ''){
            $sql .= ' AND `buyLevel`=:buyLevel';
            $data[':buyLevel'] = $buyLevel;
        }
        if($startTime !== ''){
            $sql .= ' AND `pay_time`>=:startTime';
            $data[':startTime'] = $buyLevel;
        }
        if($endTime !== ''){
            $sql .= ' AND `pay_time`<=:endTime';
            $data[':endTime'] = $endTime;
        }
        if($status !== ''){
            $sql .= ' AND `status`=:status';
            $data[':status'] = $status;
        }
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }

    /**
     * @desc    根据id获取订单
     * @param   int     $id     id
     * @return  array   $return
     */
    public function getLevelOrderById($id){
        $sql  = 'SELECT * FROM `level_order` WHERE `id`=:id';
        $data = array(
            ':id' => $id
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }

    /**
     * @desc    根据pay_id获取订单
     * @param   int     $payId     支付id
     * @return  array   $return
     */
    public function getLevelOrderByPayId($payId){
        $sql  = 'SELECT * FROM `level_order` WHERE `pay_id`=:pay_id';
        $data = array(
            ':pay_id' => $payId
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }

    /**
     * @desc    创建操作日志
     * @param   int     $order_id   订单id
     * @param   int     $type       类型
     * @param   array   $data       修改的类型
     * @return  boolen  $return     返回执行结果
     */
    public function createLevelOrderLog($order_id, $type, $data, $authorName){
        $time = time();
        $data = json_encode($data);
        $sql  = 'INSERT INTO `level_order_log`(`author_name`, `order_id`, `type`, `updateField`, `create_time`) VALUES(:author_name, :order_id, :type, :updateField, :create_time)';
        $data = array(
            ':author_name' => $authorName,
            ':order_id'    => $order_id,
            ':type'        => $type,
            ':updateField' => $data,
            ':create_time' => $time
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql,$data)->lastInsertId();
    }

    /**
     * @desc    创建操作日志
     * @param   int     $order_id   订单id
     * @return  boolen  $return     返回执行结果
     */
    public function getLevelOrderLogByOrderId($order_id){
        $sql  = 'SELECT * FROM `level_order_log` WHERE `order_id`=:order_id';
        $data = array(
            ':order_id' => $order_id
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
    }

    /**
     * @desc    删除订单
     * @param   int     $id         订单id
     * @param   string  $authorName 操作人
     * @return  boolen  $return     返回执行结果
     */
    public function delLevelOrder($id, $authorName, $levelOrderInfo, $updateLevel){
        $sql  = 'DELETE FROM `level_order` WHERE `id`=:id';
        $data = array(
            ':id' => $id
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql,$data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
            $this->createLevelOrderLog($id, 3, $levelOrderInfo, $authorName);
        }
        return $res;
    }
}
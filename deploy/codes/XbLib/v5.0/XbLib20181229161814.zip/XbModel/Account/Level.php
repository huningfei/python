<?php
/**
 * @desc 	等级相关
 * @author  qien
 * @date    18.01.22
 */
class XbModel_Account_Level extends XbModel_BaseModel{
    public static $cache_tag = "Account_Common_Level_";
    public static $cache_expire = 259200;
    function __construct() {
        parent::_init("xb_account");
    }

    /**
     * @desc    根据等级获取相关信息
     * @param   int     $level      等级
     * @return  array   $info       返回等级信息
     */
    public function getLevelByLevel($level){
        $sql = 'SELECT * FROM `common_level` WHERE `level`=:level';
        $data = array(
            ':level' => $level
        );
        return $this->dao->conn()->expire(self::$cache_expire)->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    获取所有等级信息
     * @param   boolen   $cost       购买所需支付money
     * @return  array   $return     返回等级信息
     */
    public function getAllLevel($cost=false, $type = 0,$mch_id=1){
        $sql = 'SELECT * FROM `common_level` WHERE 1';
        if($cost){
            $sql .= ' AND `cost` > 0';
        }
        
        $type = (int)$type;
        if ($type) {
            $sql .= ' AND `type` = ' . $type;
        }
        if($mch_id){
            $sql .= ' AND `mch_id` = '.$mch_id;
        }
        $sql .= ' ORDER BY `level` ASC';
        return $this->dao->conn()->expire(self::$cache_expire)->setTag(self::$cache_tag)->preparedSql($sql, array())->fetchAll();
    }
    
    /**
     * 获取指定等级的用户数量
     *
     * @param unknown $level
     * @return unknown
     */
    public function getUsersNumByLevel($level) {
        $level = (int)$level;
        $sql = "SELECT COUNT(DISTINCT uid) FROM users_level WHERE level_id = {$level}";
        $num = $this->dao->conn()->noCache()->preparedSql($sql, [])->fetchColumn(0);
        return $num ? $num : 0;
    }

    /**
     * @desc    根据id获取等级
     * @param   int     $id     id
     * @return  array   $return
     */
    public function getLevel($id){
        $sql  = 'SELECT * FROM `common_level` WHERE `id`=:id';
        $data = array(
            ':id' => $id
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }

    /**
     * @desc    删除等级
     * @param   int     $id    id
     * @return  boolen  $return  返回执行结果
     */
    public function delLevel($id){
        $sql  = 'DELETE FROM `common_level` WHERE `id`=:id';
        $data = array(
            ':id' => $id
        );
        $res = $this->dao->noCache()->preparedSql($sql,$data)->affectedCount();
        if(!$res){
            return false;
        }
        $this->dao->clearTag(self::$cache_tag);

        return $res;
    }


    /**
     * @desc 创建等级
     * @param    string  $levelName   等级名称
     * @param    int     $level       等级
     * @param    float   $fee         费率
     * @param    float   $cost        升级花费
     * @param    int     $inviteNum   邀请升级所需人数
     * @param    int     $is_redirect 升级是否包含间接用户
     * @param    int     $type        等级类型  1 普通 2 加盟商
     * @return  boolen  $return     返回执行结果
     */
    public function createLevel($levelName,$level,$fee,$cost,$inviteNum,$is_redirect,$type,$integralfee,$repaymentfee,$mch_id){
        $time = time();
        $sql  = 'INSERT INTO `common_level`(`levelName`,`level`, `fee`, `cost`, `inviteNum`, `is_redirect`, `create_time`,`update_time`,`type`,`integralfee`, `repaymentfee`, `icon`,`mch_id`) VALUES(:levelName,:level, :fee, :cost, :inviteNum, :is_redirect, :create_time, :update_time, :type, :integralfee, :repaymentfee, :icon,:mch_id)';
        $data = array(
            ':levelName'     => $levelName,
            ':level'       => $level,
            ':fee'     => $fee,
            ':cost'          => $cost,
            ':inviteNum'        => $inviteNum,
            ':is_redirect'     => $is_redirect,
            ':create_time' => $time,
            ':update_time'     => $time,
            ':type' => $type,
            ':integralfee' => $integralfee,
            ':repaymentfee' => $repaymentfee,
            ':icon' => $level,
            ':mch_id'=>$mch_id
        );
        $lastId = $this->dao->conn(false)->noCache()->preparedSql($sql,$data)->lastInsertId();
        if(!$lastId){
            return false;
        }
        $this->dao->clearTag(self::$cache_tag);
        return $lastId;
    }

    /**
     * @desc 编辑等级
     * @param    int     $id   等级ID
     * @param    string  $levelName   等级名称
     * @param    int     $level       等级
     * @param    float   $fee         费率
     * @param    float   $cost        升级花费
     * @param    int     $inviteNum   邀请升级所需人数
     * @param    int     $is_redirect 升级是否包含间接用户
     * @param    int     $type        等级类型  1 普通 2 加盟商
     * @return  boolen  $return     返回执行结果
     */
    public function updateLevel($id,$levelName,$level,$fee,$cost,$inviteNum,$is_redirect,$type,$integralfee,$repaymentfee){
        $time = time();
        $sql = "UPDATE `common_level` set `levelName`=:levelName,`level`=:level,`fee`=:fee,`cost`=:cost,`inviteNum`=:inviteNum,`is_redirect`=:is_redirect,`update_time`=:update_time,`type` = :type, `integralfee` = :integralfee, `repaymentfee` = :repaymentfee, `icon` = :icon WHERE `id`=:id";
        $data = array(
            ':id'     => $id,
            ':levelName'     => $levelName,
            ':level'       => $level,
            ':fee'     => $fee,
            ':cost'          => $cost,
            ':inviteNum'        => $inviteNum,
            ':is_redirect'     => $is_redirect,
            ':update_time'     => $time,
            ':type' => $type,
            ':integralfee' => $integralfee,
            ':repaymentfee' => $repaymentfee,
            ':icon' => $level
        );
        $res =$this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if(!$res){
            return false;
        }

        $this->dao->clearTag(self::$cache_tag);
        return $res;
    }
    
    /**
     * 更新等级最低还款费率
     * 
     * @param unknown $level_id
     * @param unknown $rate
     * @return boolean
     */
    public function updateLevelRepaymentRate($level_id, $rate) {
        $sql = "UPDATE common_level SET repaymentfee = {$rate} WHERE id = {$level_id}";
        
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, [])->excute();
        $this->dao->clearTag(self::$cache_tag);
        
        return $res;
    }
    
    /**
     * 更新收款费率
     * 
     * @param unknown $level_id
     * @param unknown $fee
     * @param unknown $integral_fee
     * @return boolean
     */
    public function updateFee($level_id, $fee, $integral_fee) {
        $level_id = (int)$level_id;
        $fee = (float)$fee;
        $integral_fee = (float)$integral_fee;
        $sql = "UPDATE common_level SET fee = {$fee}, integralfee = {$integral_fee} WHERE id = {$level_id}";
        
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, [])->excute();
        $this->dao->clearTag(self::$cache_tag);
        
        return $res;
    }
    /**
     * 根据mch_id获取和level获取等级
     * @param unknown $mch_id
     * @param unknown $level
     * @return array
     */
    public function  getLeveByMchId($mch_id,$level){
        $sql = "select * from common_level where mch_id=:mch_id and `level` = :level";
        $data = array(
            ':mch_id'=>$mch_id,
            ':level'=>$level
        );
        return $this->dao->conn()->noCache()->preparedSql($sql,$data)->fetchOne();
    }

}
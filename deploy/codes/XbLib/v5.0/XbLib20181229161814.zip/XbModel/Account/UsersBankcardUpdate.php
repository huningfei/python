<?php

/**
 * 
 *
 */
class XbModel_Account_UsersBankcardUpdate extends XbModel_BaseModel {
    
    function __construct() {
        parent::_init("xb_account");
    }
    
    /**
     * 获取最新的一个修改状态
     *
     * @param unknown $uid
     * @return array
     */
    public function getLastChange($uid) {
        $sql = 'SELECT * FROM `users_bankcard_update` WHERE `uid`=:uid ORDER BY `id` DESC LIMIT 1';
        $data = array(
            ':uid'        => $uid,
        );
        
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->fetchOne();
    }
    
    /**
     * 添加一个修改
     * 
     * @param unknown $uid
     * @param unknown $bankcard
     * @param unknown $bank_code
     * @param unknown $bank
     * @param unknown $phone
     * @param unknown $origin_card
     * @param unknown $origin_phone
     * @param unknown $origin_bankcode
     * @param unknown $origin_bank
     * @param unknown $checkId
     * @return boolean
     */
    public function add($uid, $bankcard, $bank_code, $bank, $phone, $origin_card, $origin_phone, $origin_bankcode, $origin_bank, $checkId) {
        $sql = 'INSERT INTO `users_bankcard_update` 
            (uid, bankcard_number, phone, origin_bankcard_number, origin_phone, create_time, bank_code, bank, origin_bank_code, origin_bank, check_bank_id) VALUES 
            (:uid, :bankcard_number, :phone, :origin_bankcard_number, :origin_phone, :create_time, :bank_code, :bank, :origin_bank_code, :origin_bank, :check_bank_id)';
        
        $data = [
            ':uid' => $uid, 
            ':bankcard_number' => $bankcard, 
            ':phone' => $phone, 
            ':origin_bankcard_number' => $origin_card, 
            ':origin_phone' => $origin_phone, 
            ':create_time' => time(),
            ':bank_code' => $bank_code,
            ':bank' => $bank,
            ':origin_bank_code' => $origin_bankcode,
            ':origin_bank' => $origin_bank,
            ':check_bank_id' => $checkId
        ];
        
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->excute();
    }
    
    /**
     * 更新编辑状态
     * 
     * @param unknown $id
     * @param unknown $status 1 新提交 2 处理中 3 处理失败 4 处理成功 
     * @return boolean
     */
    public function updateStatus($id, $status, $msg = '', $result = '') {
        $sql = 'UPDATE `users_bankcard_update` SET `status` = :status, `update_time` = :update_time, `reason` = :reason, `result` = :result WHERE `id` = :id';
           
        $data = [
            ':id' => $id,
            ':status' => $status,
            ':update_time' => time(),
            ':reason' => $msg,
            ':result' => $result
        ];
        
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->excute();
    }
    
    /**
     * 获取用户修改历史列表
     * 
     * @param unknown $uid
     * @param unknown $mch_id
     * @param unknown $phone
     * @param unknown $realname
     * @param unknown $card
     * @param unknown $origin_card
     * @param number $status
     * @param number $offset
     * @param number $limit
     */
    public function listHistory($uid, $mch_id, $phone, $realname, $card, $origin_card, $start_time, $end_time, $status = 4, $offset = 0, $limit = 10) {
        $sql = 'SELECT u.nickname, u.mch_id, u.phone as user_phone, b.* FROM users u JOIN users_bankcard_update b ON u.id = b.uid WHERE ';
        
        $data = [];
        if ($uid) $data['uid'] = $uid;
        if ($mch_id) $data['mch_id'] = $mch_id;
        
        if ($realname) {
            $user = XbModule_Account_UsersProfile::getInstance()->getUserProfile('', $realname, '', '', 0, 9999, '', '');
            $user_id_list = [];
            foreach ($user as $item) {
                $user_id_list[] = $item['id'];
            }
            
            if ($user_id_list) {
                $sql .= ' u.id in (' . implode(',', $user_id_list) . ') AND ';
            }
            else {
                $sql .= ' 0 AND ';
            }
        }

        if ($card) $data['bankcard_number'] = $card;
        if ($origin_card) $data['origin_bankcard_number'] = $origin_card;
        if ($status) $data['status'] = $status;

        $where = [];
        foreach ($data as $field => $val) {
            $sql .= " `{$field}` = :{$field} AND ";
            $where[':' . $field] = $val;
        }
        
        if ($phone) {
            $sql .= " u.`phone` = :phone AND ";
            $where['phone'] = $phone;
        }
        
        $start_time = (int)$start_time;
        if ($start_time) $sql .= " b.`create_time` >= {$start_time} AND ";
        
        $end_time = (int)$end_time;
        if ($end_time) $sql .= " b.`create_time` <= {$end_time} AND ";
        
        $offset = (int)$offset;
        $sql .= " 1=1 ORDER BY b.id DESC LIMIT {$offset},{$limit}";

        return $this->dao->conn(false)->noCache()->preparedSql($sql, $where)->fetchAll();
    }
    
    /**
     * 统计用户修改历史
     *
     * @param unknown $uid
     * @param unknown $mch_id
     * @param unknown $phone
     * @param unknown $realname
     * @param unknown $card
     * @param unknown $origin_card
     * @param number $status
     */
    public function countHistory($uid, $mch_id, $phone, $realname, $card, $origin_card, $start_time, $end_time, $status = 4) {
        $sql = 'SELECT COUNT(*) FROM users u JOIN users_bankcard_update b ON u.id = b.uid WHERE ';
        
        $data = [];
        if ($uid) $data['uid'] = $uid;
        if ($mch_id) $data['mch_id'] = $mch_id;
        if ($realname) {
            $user = XbModule_Account_UsersProfile::getInstance()->getUserProfile('', $realname, '', '', 0, 9999, '', '');
           
            $user_id_list = [];
            foreach ($user as $item) {
                $user_id_list[] = $item['id'];
            }
            
            if ($user_id_list) {
                $sql .= ' u.id in (' . implode(',', $user_id_list) . ') AND ';
            }
            else {
                $sql .= ' 0 AND ';
            }

        }
        if ($card) $data['bankcard_number'] = $card;
        if ($origin_card) $data['origin_bankcard_number'] = $origin_card;
        if ($status) $data['status'] = $status;
        
        $fields = array_keys($data);
        $where = [];
        foreach ($data as $field => $val) {
            $sql .= " `{$field}` = :{$field} AND ";
            $where[':' . $field] = $val;
        }
        
        if ($phone) {
            $sql .= " u.`phone` = :phone AND ";
            $where['phone'] = $phone;
        }
        
        $start_time = (int)$start_time;
        if ($start_time) $sql .= " b.`create_time` >= {$start_time} AND ";
        
        $end_time = (int)$end_time;
        if ($end_time) $sql .= " b.`create_time` <= {$end_time} AND ";
        
        $sql .= " 1=1";
        
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $where)->fetchColumn(0);
    }
    
    /**
     * 将用户未处理的重复更新请求标记为放弃
     *
     * @param unknown $uid
     * @param unknown $maxId
     * @return boolean
     */
    public function rejectReduplicatedUpdate($uid, $max_id) {
        $uid = (int)$uid;
        $max_id = (int)$max_id;
        $sql = "UPDATE users_bankcard_update SET status = 9 WHERE uid = {$uid} AND id < {$max_id} AND status = 1";
        
        return $this->dao->conn(false)->noCache()->preparedSql($sql, [])->excute();
    }
    
    public function getUpdateById($id) {
        $sql = "SELECT * FROM users_bankcard_update WHERE id =:id";
        return $this->dao->conn(false)->noCache()->preparedSql($sql, ['id' => $id])->fetchOne();
    }
    
}
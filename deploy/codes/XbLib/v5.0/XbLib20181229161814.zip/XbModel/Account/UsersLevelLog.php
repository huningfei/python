<?php
/**
 * @desc 	用户等级
 * @author  qien
 * @date    18.03.08
 */
class XbModel_Account_UsersLevelLog extends XbModel_BaseModel{
    public static $cache_tag = "Account_Users_Level_Log";
    public static $cache_expire = 259200;
    function __construct() {
        parent::_init("xb_account");
    }

    /**
     * @desc    增加用户等级变更日志
     * @return  boolen  $return     返回执行结果
     */
    public function addLevelChangeLog($uid, $oldLevel, $oldLevelName, $newLevel, $newLevelName, $type, $desc){
        $sql = "INSERT INTO `users_level_log` (`uid`,`old_level`,`old_name`,`change_level`,`change_name`,`type`,`desc`,`create_time`) VALUES (:uid,:old_level,:old_name,:change_level,:change_name,:type,:desc,:create_time)";
        $data = array(
            ':uid'          => $uid,
            ':old_level'    => $oldLevel,
            ':old_name'     => $oldLevelName,
            ':change_level' => $newLevel,
            ':change_name'  => $newLevelName,
            ':type'         => $type,
            ':desc'         => $desc,
            ':create_time'  => time()
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
    }

    //查询用户等级日志
    public function getLevelAll($phone = '',$realname= '',$merchant_id = '',$start_time = '',$end_time = '',$cause = '',$page = '',$perpage = ''){
        if($phone !='' || $merchant_id !=''){
            $where = '1=1';
            if($phone !=''){
                $where .= " and `phone` = $phone";
            }
            if($merchant_id !=''){
                $where .=' and `mch_id` = '.$merchant_id;
            }
            $filed = 'id,phone,mch_id';
            $res = $this->queryData('users',$filed,$where,'id',self::$cache_tag,1);
            $users_arr = $res['res'];
            $users_str = $res['str'];
        }
        if($realname !=''){
            $filed = 'uid,realname';
            $where = "`realname` = '".$realname."'";
            $res = $this->queryData('users_profile',$filed,$where,'uid',self::$cache_tag,1);
            $users_profile_arr = $res['res'];
            $users_profile_str = $res['str'];
        }
        $sql = "select a.* from users_level_log a where 1=1";
        $start_time = strtotime($start_time);
        $end_time = strtotime($end_time);
        if(!empty($end_time)){
            $end_time = $end_time + 86400;
        }
        $data = array(
            ':page' => ($page-1)*$perpage,
            ':perpage' => $perpage,
        );
        if($realname !='' || $phone !='' || $merchant_id !=''){
            $query_id = array();
            if ($realname != '' && $phone == '' && $merchant_id == ''){
                $query_id = $users_profile_str;
            }else if ($realname == '' && ($phone !='' || $merchant_id !='')){
                $query_id = $users_str;
            }else if($realname != '' && ($phone !='' || $merchant_id !='')){
                $query_id = array_intersect($users_profile_str,$users_str);
            }
            if(empty($query_id)){
                $query_id = 0;
            }else{
                $query_id = implode(',',$query_id);
            }
            $sql .=' and a.`uid` in ('.$query_id.')';
        }
        if($start_time !=''){
            $sql .=' and a.`create_time` >= '.$start_time;
        }
        if($end_time !=''){
            $sql .=' and a.`create_time` < '.$end_time;
        }
        if($cause !=''){
            $sql .=' and a.`type` = '.$cause;
        }
        if($page!='' && $perpage!=''){
            $sql .=' order by a.id desc limit :page,:perpage ';
        }
        $str =  $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
        $mid = '';
        $uid = '';
        foreach($str as &$v){
            if($v['uid'] != 0){
                $uid.= $v['uid'].',';
            }
        }
        //查询商户真是姓名以及状态
        if($realname =='' && !empty($uid)){
            $filed = 'uid,realname';
            $uid = trim($uid,',');
            $where = "uid in ($uid)";
            $users_profile_arr = $this->queryData('users_profile',$filed,$where,'uid',self::$cache_tag,0);
        }
        //查询mch_id
        if($merchant_id == '' && !empty($uid)){
            $uid = trim($uid,',');
            $where = "id in ($uid)";
            $filed = 'id,phone,mch_id';
            $users_arr = $this->queryData('users',$filed,$where,'id',self::$cache_tag,0);
        }
        if ($users_arr){
            $mid = '';
            foreach ($users_arr as $value){
                $mid .=','.$value['mch_id'];
            }
        }
        //查询代理名称
        if(!empty($mid)){
            $mid = trim($mid,',');
            $modify = XbModule_Merchant_Merchant::getInstance()->inMerchart($mid);
            $modifyArray = array();
            foreach($modify as $k=>$vel){
                $modifyArray[$vel['id']] = $vel;
            }
        }

        foreach($str as &$v){
            $v['m_name'] = '';
            if(!empty($modifyArray[$users_arr[$v['uid']]['mch_id']])){
                $v['m_name'] = $modifyArray[$users_arr[$v['uid']]['mch_id']]['name'];
            }
            $v['phone'] = '';
            if(!empty($users_arr[$v['uid']])){
                $v['phone'] = $users_arr[$v['uid']]['phone'];
            }
            $v['realname'] = '';
            if(!empty($users_profile_arr[$v['uid']])){
                $v['realname'] = $users_profile_arr[$v['uid']]['realname'];
            }
        }
        return $str;
    }
}
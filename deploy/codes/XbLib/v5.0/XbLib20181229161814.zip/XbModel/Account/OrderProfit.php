<?php
/**
 * @desc 	订单相关
 * @author  qien
 * @date    18.3.5
 */
class XbModel_Account_OrderProfit extends XbModel_BaseModel{
    function __construct() {
        parent::_init("xb_account");
    }

    /**
     * @desc    创建反润列表
     * @param   array   $profitInfo     反润信息
     * @param   array   $orderid        订单id
     * @param   array   $table          订单表
     * @return  boolen  $return         返回结果
     */
    public function createProfit($profitInfo, $orderid, $table){
        $time = time();
        $sql = 'INSERT INTO `order_profit`(`table`, `order_id`, `uid`, `level`, `rate`, `create_time`) VALUES';
        $data = array(
            ':table'        => $table,
            ':order_id'     => $orderid,
            ':create_time'  => $time
        );
        foreach($profitInfo as $k=>$v){
            $sql .= "(:table, :order_id, :uid{$k}, :level{$k}, :rate{$k}, :create_time),";
            $data[":uid{$k}"]   = $v['uid'];
            $data[":level{$k}"] = $v['level'];
            $data[":rate{$k}"]  = $v['rate'];
        }
        $sql = trim($sql, ',');
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
    }

    /**
     * @desc    根据订单表，订单id获取下单时分润信息
     * @param   int     $table      订单表
     * @param   int     $orderid    订单id
     * @return  array   $return     返回搜索结果
     */
    public function getOrderProfit($table, $orderid){
        $sql = 'SELECT * FROM `order_profit` WHERE `table`=:table AND `order_id`=:order_id';
        $data = array(
            ':table'    => $table,
            ':order_id' => $orderid
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }
}
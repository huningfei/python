<?php
/**
 * @desc 	用户资料信息
 * @author  qien
 * @date    17.12.18
 */
class XbModel_Account_UsersProfile extends XbModel_BaseModel {
    public static $cache_tag = "Account_Users_Profile";

    function __construct() {
        parent::_init("xb_account");

    }

    /**
     * @desc    添加用户身份信息
     * @param   string  $uid        用户
     * @param   string  $realname   真实姓名
     * @param   string  $idcard     身份证号
     * @param   string  $cardNumber 银行卡号
     * @param   string  $bank       银行名称
     * @param   string  $bankCode   银行简码
     * @param   string  $cardType   银行卡类型
     * @return  boolen  $return     返回执行结果
     */
    public function addProfile($uid, $realname, $idcard, $cardNumber, $bank, $bankCode, $image1, $image2, $image3, $image4){
        $time = time();
        $sql = 'INSERT INTO `users_profile` (`uid`, `realname`, `idcardNumber`, `bank`, `bankCode`, `bankcardNumber`, `idcardImage1`, `idcardImage2`, `bankcardImage1`, `bankcardImage2`, `status`, `axf_status`, `create_time`) VALUES(:uid, :realname, :idcardNumber, :bank, :bankCode, :bankcardNumber, :idcardImage1, :idcardImage2, :bankcardImage1, :bankcardImage2, :status, :axf_status, :create_time)';
        $data = array(
            ':uid'            => $uid,
            ':realname'       => $realname,
            ':idcardNumber'   => $idcard,
            ':bank'           => $bank,
            ':bankCode'       => $bankCode,
            ':bankcardNumber' => $cardNumber,
            ':idcardImage1'   => $image1,
            ':idcardImage2'   => $image2,
            ':bankcardImage1' => $image3,
            ':bankcardImage2' => $image4,
            ':status'         => 2,
            ':axf_status'     => 0,
            ':create_time'    => $time
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
    }

    /**
     * @desc    修改用户身份信息
     * @param   string  $uid        用户
     * @param   string  $realname   真实姓名
     * @param   string  $idcard     身份证号
     * @param   string  $cardNumber 银行卡号
     * @param   string  $bank       银行名称
     * @param   string  $bankCode   银行简码
     * @param   string  $cardType   银行卡类型
     * @return  boolen  $return     返回执行结果
     */
    public function editProfile($uid, $realname, $idcard, $cardNumber, $bank, $bankCode, $image1, $image2, $image3, $image4){
        $time = time();
        $sql = 'UPDATE `users_profile` SET `realname`=:realname, `idcardNumber`=:idcardNumber, `bank`=:bank, `bankCode`=:bankCode, `bankcardNumber`=:bankcardNumber, `idcardImage1`=:idcardImage1, `idcardImage2`=:idcardImage2, `bankcardImage1`=:bankcardImage1, `bankcardImage2`=:bankcardImage2, `status`=:status, `axf_status`=:axf_status, `update_time`=:update_time WHERE uid=:uid';
        $data = array(
            ':realname'       => $realname,
            ':idcardNumber'   => $idcard,
            ':bank'           => $bank,
            ':bankCode'       => $bankCode,
            ':bankcardNumber' => $cardNumber,
            ':idcardImage1'   => $image1,
            ':idcardImage2'   => $image2,
            ':bankcardImage1' => $image3,
            ':bankcardImage2' => $image4,
            ':status'         => 2,
            ':axf_status'     => 0,
            ':update_time'    => $time,
            ':uid'            => $uid
        );
        return  $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
    }
    
    /**
     * 编辑用户储蓄卡信息
     * 
     * @param unknown $uid
     * @param unknown $cardNumber
     * @param unknown $bank
     * @param unknown $bankCode
     * @param unknown $phone
     * @param unknown $checkId
     * @return number
     */
    public function editBankcardInfo($uid, $cardNumber, $bank, $bankCode, $phone, $checkId) {
        $time = time();
        $sql = 'UPDATE `users_profile` SET  `bank`=:bank, `bankCode`=:bankCode, `bankcardNumber`=:bankcardNumber, `bankcard_phone`=:bankcard_phone, `axf_status`=:axf_status, `update_time`=:update_time, `check_bank_id`=:check_bank_id WHERE uid=:uid';
        $data = array(
            ':bank'           => $bank,
            ':bankCode'       => $bankCode,
            ':bankcardNumber' => $cardNumber,
            ':axf_status'     => 0,
            ':update_time'    => $time,
            ':uid'            => $uid,
            ':bankcard_phone' => $phone,
            ':check_bank_id'  => $checkId
        );
        return  $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
    }

    /**
     * @desc    修改身份证图片
     * @param   int     $uid    用户id
     * @param   string  $image1 身份证图片正面
     * @param   string  $image2 身份证图片反面
     * @return  string  $return 返回执行结果
     */
    public function updateIdCardImage($uid, $image1, $image2){
        $sql = 'UPDATE `users_profile` SET `idcardImage1`=:idcardImage1, `idcardImage2`=:idcardImage2 WHERE uid=:uid';
        $data = array(
            ':idcardImage1' => $image1,
            ':idcardImage2' => $image2,
            ':uid'          => $uid
        );
        return  $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
    }

    /**
     * @desc    修改储蓄卡图片
     * @param   int     $uid    用户id
     * @param   string  $image1 储蓄卡图片正面
     * @param   string  $image2 手持储蓄卡图片
     * @return  string  $return 返回执行结果
     */
    public function updateBankCardImage($uid, $image1, $image2){
        $sql = 'UPDATE `users_profile` SET `bankcardImage1`=:bankcardImage1, `bankcardImage2`=:bankcardImage2 WHERE uid=:uid';
        $data = array(
            ':bankcardImage1' => $image1,
            ':bankcardImage2' => $image2,
            ':uid'            => $uid
        );
        return  $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
    }

    /**
     * @desc    根据uid获取用户资料profile
     * @param   $uid    用户id
     * @return  array   返回搜索结果
     */
    public function getProfileByUid($uid){
        $sql  = 'SELECT * FROM `users_profile` WHERE uid=:uid';
        $data = array(
            ':uid' => $uid
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    更新用户资料状态
     * @param   int     $uid        用户id
     * @param   int     $status     更改的状态
     * @return  boolen  $return     返回执行结果
     */
    public function updateStatus($uid, $status){
        $sql = 'UPDATE `users_profile` SET `status`=:status WHERE uid=:uid';
        $data = array(
            ':status' => $status,
            ':uid'    => $uid
        );
        return  $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
    }

    /**
     * @desc    存储用户信息-临时
     * @param   string  $uid        用户
     * @param   string  $realname   真实姓名
     * @param   string  $idcard     身份证号
     * @param   string  $cardNumber 银行卡号
     */
    public function addProfileTemp($uid, $realname, $idcard, $cardNumber, $phone = ''){
        $time = time();
        $sql = 'INSERT INTO `users_profile` (`uid`, `realname`, `idcardNumber`, `bankcardNumber`, `create_time`,  `bankcard_phone`) VALUES(:uid, :realname, :idcardNumber, :bankcardNumber, :create_time, :phone)';
        $data = array(
            ':uid'            => $uid,
            ':realname'       => $realname,
            ':idcardNumber'   => $idcard,
            ':bankcardNumber' => $cardNumber,
            ':create_time'    => $time,
            ':phone'          => $phone
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
    }

    /**
     * @desc    修改用户信息-临时
     * @param   string  $uid        用户
     * @param   string  $realname   真实姓名
     * @param   string  $idcard     身份证号
     * @param   string  $cardNumber 银行卡号
     */
    public function editProfileTemp($uid, $realname, $idcard, $cardNumber, $phone = ''){
        $time = time();
        $sql = 'UPDATE `users_profile` SET `bankcard_phone` = :phone, `realname`=:realname, `idcardNumber`=:idcardNumber, `bankcardNumber`=:bankcardNumber, `update_time`=:update_time WHERE uid=:uid';
        $data = array(
            ':realname'       => $realname,
            ':idcardNumber'   => $idcard,
            ':bankcardNumber' => $cardNumber,
            ':update_time'    => $time,
            ':uid'            => $uid,
            ':phone'          => $phone
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
    }

    /**
     * @desc    增加用户图片-临时
     * @param   int     $uid    用户图片
     * @param   array   $image  图片
     * @param   string  $type   类型 idcard,bankcard
     * @return  boolen  $return 返回执行结果
     */
    public function addProfileImageTemp($uid, $image, $type){
        $time = time();
        if($type == 'idcard'){
            $sql = 'INSERT INTO `users_profile` (`uid`, `idcardImage1`, `idcardImage2`, `create_time`) VALUES(:uid, :image1, :image2, :create_time)';
        }elseif($type == 'bankcard'){
            $sql = 'INSERT INTO `users_profile` (`uid`, `bankcardImage1`, `bankcardImage2`, `create_time`) VALUES(:uid, :image1, :image2, :create_time)';
        }

        $data = array(
            ':uid'         => $uid,
            ':image1'      => $image['image1'],
            ':image2'      => $image['image2'],
            ':create_time' => $time
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
    }

    /**
     * @desc    修改用户图片-临时
     * @param   int     $uid    用户图片
     * @param   array   $image  图片
     * @param   string  $type   类型 idcard,bankcard
     * @return  boolen  $return 返回执行结果
     */
    public function editProfileImageTemp($uid, $image, $type){
        if($type == 'idcard'){
            $sql = 'UPDATE `users_profile` SET `idcardImage1`=:image1, `idcardImage2`=:image2 WHERE uid=:uid';
        }elseif($type == 'bankcard'){
            $sql = 'UPDATE `users_profile` SET `bankcardImage1`=:image1, `bankcardImage2`=:image2 WHERE uid=:uid';
        }

        $data = array(
            ':image1' => $image['image1'],
            ':image2' => $image['image2'],
            ':uid'    => $uid
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res || $res === 0){
            return true;
        }
        return false;
    }

    /**
     * @desc    根据商户获取实名认证信息
     * @param   string   $phone          手机号
     * @param   string   $start_time     时间区间
     * @param   string   $end_time       时间区间
     * @param   string   $start          页数
     * @param   string   $limit          每页条数
     * @param   string   $status         审核状态
     * @param   int      $mch_id         商户ID
     * @return  array   $return          返回实名信息
     */
    public function getUserProfile($phone,$realname,$start_time,$end_time,$page,$perpage,$status,$mch_id){
        $sql = "SELECT u.id,u.mch_id,u.phone,p.* ,p.create_time as c_time FROM `users` as u INNER JOIN `users_profile` as p ON u.id = p.uid WHERE 1=1 ";
        $data = array(
            ':page' => $page,
            ':perpage' => $perpage,
        );
        if(!empty($mch_id)){
            $sql .= ' and  u.mch_id=:mch_id';
            $data[':mch_id'] = $mch_id;
        }
        if(!empty($phone)){
            $sql .= ' and  u.phone=:phone';
            $data[':phone'] = $phone;
        }
        if(is_numeric($status) && (!empty($status) || $status == 0)){
            $sql .= ' and  p.status=:status';
            $data[':status'] = $status;
        }
        if(!empty($start_time)){
            $sql .= ' and  p.create_time>=:starttime';
            $data[':starttime'] = strtotime($start_time);
        }
        if(!empty($end_time)){
            $sql .= ' and  p.create_time<=:endtime';
            $data[':endtime'] = strtotime($end_time.' 23:59:59');
        }
        if(!empty($realname)){
            $sql .= ' and  p.realname=:realname';
            $data[':realname'] = $realname;
        }
        $sql .=' order by c_time desc limit :page,:perpage ';
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    根据商户获取实名认证信息
     * @param   string   $phone          手机号
     * @param   string   $start_time     时间区间
     * @param   string   $end_time       时间区间
     * @param   string   $status         审核状态
     * @param   int      $mch_id         商户ID
     * @return  array   $return          返回实名信息
     */
    public function getUserProfileCount($phone,$realname,$start_time,$end_time,$status,$mch_id){
        $sql = "SELECT count(*) as num FROM `users` as u INNER JOIN `users_profile` as p ON u.id = p.uid WHERE 1=1 ";
        $data = array();
        if(!empty($mch_id)){
            $sql .= ' and  u.mch_id=:mch_id';
            $data[':mch_id'] = $mch_id;
        }
        if(!empty($phone)){
            $sql .= ' and  u.phone=:phone';
            $data[':phone'] = $phone;
        }
        if(!empty($start_time)){
            $sql .= ' and  p.create_time>=:starttime';
            $data[':starttime'] = strtotime($start_time);
        }
        if(is_numeric($status) && (!empty($status) || $status == 0)){
            $sql .= ' and  p.status=:status';
            $data[':status'] = $status;
        }
        if(!empty($end_time)){
            $sql .= ' and  p.create_time<=:endtime';
            $data[':endtime'] = strtotime($end_time.' 23:59:59');
        }
        if(!empty($realname)){
            $sql .= ' and  p.realname=:realname';
            $data[':realname'] = $realname;
        }
        $res = $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
        return $res['num'];
    }

    /*
     * @desc   删除实名信息
     * @param       int      $uid      用户ID
     * @return      boolean  $return   返回执行结果
     * */
    public function delProfile($uid){
        //先查询是否有此ID信息
        $sql = "SELECT uid FROM `users_profile` WHERE `uid`=:uid";
        $data = array(
            ':uid'=>$uid
        );
        $res = $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
        if($res){
            $del_sql = "DELETE FROM `users_profile` WHERE `uid`=:uid ";
            $del_data = array(
                ':uid'=>$uid
            );
            $del_res = $this->dao->conn(false)->noCache()->preparedSql($del_sql, $del_data)->affectedCount();
            if($del_res){
                $this->dao->clearTag(self::$cache_tag);
                return $del_res;
            }
            return false;
        }
        return false;
    }

    /**
     * @desc 更改审核状态
     * @param      int       $uid         用户ID
     * @param      int       $status      状态
     * @param      string    $reason      原因
     */
    public function changeStatus($uid, $status, $reason){
        //先查询是否有此ID信息
        $sql = "SELECT u.phone,p.*,u.mch_id FROM `users` u  INNER JOIN `users_profile` p ON u.id = p.uid  WHERE p.`uid`=:uid and p.`status` =:status";
        $data = array(
            ':uid' => $uid,
            ':status' => 2
        );
        $res = $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
        if ($res) {
            if($status == 3){
                $data = [
                    'uid'            => $uid,
                    'order_id'       => XbModule_Account_OrderCode::getInstance()->getOrderCode(),
                    'phone'          => $res['bankcard_phone'],
                    'realname'       => $res['realname'],
                    'bank'           => $res['bank'],
                    'bankCardCode'   => $res['bankCode'],
                    'idcardNumber'   => $res['idcardNumber'],
                    'bankcardNumber' => $res['bankcardNumber'],
                    'bankcardImage1' => $res['bankcardImage1'],
                    'bankcardImage2' => $res['bankcardImage2'],
                    'idcardImage1'   => $res['idcardImage1'],
                    'idcardImage2'   => $res['idcardImage2'],
                    'rate'           => '0.0052',
                    'fee'            => '2',
                    'mininum_charge' => '0',
                    'maxnum_charge'  => '9999',
                ];
                $signup_res = XbLib_ChannelFunc_Channel::getInstance()->signUp($data);
                $channel_stauts = 2;//通过审核通过
                if($signup_res && $signup_res['code'] == 200){
                    if(count($signup_res['channelInfo'])>0){
                        foreach($signup_res['channelInfo'] as $key => $val){
                            $this->updateChannelStatus($uid,$channel_stauts,$val['channel_id'],$val['channel_code'],$val['channel_key']);
                        }
                    }else{
                        if(count($signup_res['error']['list']) >0  && !$signup_res['error']['is_succ'] ){
                            $res = XbModule_Account_Channel::getInstance()->getChannel(1);
                            if($res){
                                foreach($res as $k => $v){
                                    foreach($signup_res['error']['list'] as $key => $val){
                                        if($v['channel_id'] == $val['channel_id']){
                                            XbFunc_Log::write('首次进件失败',$val['channel_name'],'用户ID【'.$uid.'】--'.$val['message'],16);
                                        }
                                    }
                                }
                            }

                        }
                        XbFunc_Log::write('changeStatus','易宝通道审核--结果：',json_encode($signup_res));
                    }
                }else{
                    XbFunc_Log::write('changeStatus','易宝通道审核审核失败：',json_encode($signup_res));
                }
            }

            $up_sql = 'UPDATE `users_profile` SET `status`=:status, `reason`=:reason,`check_bank_id`=:check_bank_id, `check_success_time`=:check_success_time WHERE uid=:uid';
            $up_data = array(
                ':uid'                => $uid,
                ':status'             => $status,
                ':reason'             => $reason,
                ':check_bank_id'      => '',
                ':check_success_time' => $status == 3 ? time() : 0
            );

            $up_res = $this->dao->conn(false)->noCache()->preparedSql($up_sql, $up_data)->affectedCount();
            if ($up_res ) {
                $this->dao->clearTag(self::$cache_tag);
                if($status == 3){
                    //邀请上级判断是否可以自动升级
                    XbModule_Account_UsersLevel::getInstance()->autoUpLevelHook($uid);

                    $userInvite = XbModule_Account_UsersInvite::getInstance()->getInviteInfoByUid($uid);
                    if($userInvite && $userInvite['parentid'] != 0){
//                        try{
//                            XbLib_Jpushappxiaoxi::getInstance()->send_notification_single($userInvite['parentid'], $uid, 'inviteAuth');
//                        }catch (Exception $e){
//                            XbFunc_Log::write('JPushappxiaoxi','推送消息失败：修改用户状态。type:inviteAuth', $uid);
//                        }
                        //优化推送消息
                        $res = XbLib_PushMsg::getInstance()->inviteAuth($userInvite['parentid'], array('bid'=>$uid));

                    }
                }
                if($status == 1 || $status == 3){
                    //推送
//                    if($status == 1){
//                        $type = 'authFail';
//                    }else{
//                        $type = 'authSuccess';
//                    }
//                    try{
//                        XbLib_Jpushappxiaoxi::getInstance()->send_notification_single($uid, 0, $type);
//                    }catch (Exception $e){
//                        XbFunc_Log::write('JPushappxiaoxi','推送消息失败：修改用户状态。type:'.$type, $uid);
//                    }
                    //优化推送消息
                    if($status == 1){
                        $res = XbLib_PushMsg::getInstance()->authFail($uid);
                    }else{
                        $res = XbLib_PushMsg::getInstance()->authSuccess($uid);
                    }

                }
                return $up_res;
            }
            return false;
        }
        return false;
    }

    /**
     * @desc    根据list用户id，筛选出审核通过的用户
     * @param   string      $list_uid       用户列表
     * @return  array       $return         返回审核通过的用户
     */
    public function getCheckedByListUid($list_uid)
    {
        $sql = 'SELECT uid FROM `users_profile` WHERE uid IN (' . $list_uid . ') AND status=:status';
        $data = array(
            ':status' => 3
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();

    }

    //获取储蓄卡列表
    public function getBankcard($phone = '',$realname='',$start_time = '',$end_time = '',$status = '',$merchant_id = '',$role_name = '',$m_id= '',$page = '',$perpage = '',$bankcard_number=''){
        $start_time = strtotime($start_time);
        $end_time = strtotime($end_time);
        if(!empty($end_time)){
            $end_time = $end_time + 86400;
        }
        $sql = 'select a.id,a.phone,a.mch_id,b.realname,b.idcardNumber,b.bank,b.bankcardNumber,b.bankcard_phone,b.status,b.create_time from users a LEFT JOIN users_profile b on a.id = b.uid where 1=1';
        $data = array(
            ':page' => ($page-1)*$perpage,
            ':perpage' => $perpage,
        );
        $sql .= ' and a.phone != "" and b.status != ""';
        //判断是否是代理
        if($role_name == "商户"){
            $sql .=' and a.`mch_id` = '.$m_id;
        }
        if($phone != ''){
            $sql .=' and a.phone = "'.$phone.'"';
        }
        if($merchant_id !=''){
            $sql .=' and a.`mch_id` = '.$merchant_id;
        }
        if($start_time !=''){
            $sql .=' and b.`create_time` >= '.$start_time;
        }
        if($realname !=''){
            $sql .=' and b.realname = "'.$realname.'"';
        }
        if($end_time !=''){
            $sql .=' and b.`create_time` < '.$end_time;
        }
        if ($bankcard_number) {
            $sql .= ' and b.`bankcardNumber` = :bankcard_number ';
            $data[':bankcard_number'] = $bankcard_number;
        }
        if($status !=''){
            if($status == 1){//已实名
                $sql .=' and b.`status` = 3';
            }elseif($status == 2){//未实名
                $sql .=' and b.`status` = 0 or b.`status` is null';
            }elseif($status == 3){//待审核
                $sql .=' and b.`status` = 2';
            }elseif($status == 4){//审核失败
                $sql .=' and b.`status` = 1';
            }
        }
        if($page!='' && $perpage!=''){
            $sql .=' order by a.id desc limit :page,:perpage ';
        }
        $str = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
        $mid = '';
        foreach($str as &$v){
            if($v['mch_id'] != 0){
                $mid.= $v['mch_id'].',';
            }
        }
        //查询代理名称
        if(!empty($mid)){
            $mid = trim($mid,',');
            $modify = XbModule_Merchant_Merchant::getInstance()->inMerchart($mid);
            $modifyArray = array();
            foreach($modify as $k=>$vel){
                $modifyArray[$vel['id']] = $vel;
            }
            foreach($str as &$v){
                $v['m_name'] = 0;
                if(!empty($modifyArray[$v['mch_id']])){
                    $v['m_name'] = $modifyArray[$v['mch_id']]['name'];
                }
            }
        }
        return $str;
    }
    
    //获取储蓄卡列表数量
    public function getBankcardCount($phone = '',$realname='',$start_time = '',$end_time = '',$status = '',$merchant_id = '',$role_name = '',$m_id= '',$bankcard_number=''){
        $start_time = strtotime($start_time);
        $end_time = strtotime($end_time);
        if(!empty($end_time)){
            $end_time = $end_time + 86400;
        }
        $sql = 'select count(*) from users a LEFT JOIN users_profile b on a.id = b.uid where 1=1';
        $data = array(
        );
        $sql .= ' and a.phone != "" and b.status != ""';
        //判断是否是代理
        if($role_name == "商户"){
            $sql .=' and a.`mch_id` = '.$m_id;
        }
        if($phone != ''){
            $sql .=' and a.phone = "'.$phone.'"';
        }
        if($merchant_id !=''){
            $sql .=' and a.`mch_id` = '.$merchant_id;
        }
        if($start_time !=''){
            $sql .=' and b.`create_time` >= '.$start_time;
        }
        if($realname !=''){
            $sql .=' and b.realname = "'.$realname.'"';
        }
        if($end_time !=''){
            $sql .=' and b.`create_time` < '.$end_time;
        }
        if ($bankcard_number) {
            $sql .= ' and b.`bankcardNumber` = :bankcard_number ';
            $data[':bankcard_number'] = $bankcard_number;
        }
        if($status !=''){
            if($status == 1){//已实名
                $sql .=' and b.`status` = 3';
            }elseif($status == 2){//未实名
                $sql .=' and b.`status` = 0 or b.`status` is null';
            }elseif($status == 3){//待审核
                $sql .=' and b.`status` = 2';
            }elseif($status == 4){//审核失败
                $sql .=' and b.`status` = 1';
            }
        }

        $str = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchColumn(0);
        
        return $str;
    }

    //获取信用卡列表
    public function getCreditcard($card = '',$name = '',$bank = '',$merchant_id = '',$role_name = '',$m_id = '',$page = '',$perpage = '',$phone = ''){
        $sql = 'select a.bank,a.cardNumber,a.telephone,a.create_time,b.id,b.phone,b.mch_id,c.idcardNumber,c.realname from users b LEFT JOIN users_creditcard a on b.id = a.uid LEFT JOIN users_profile c on b.id = c.uid where 1=1';
        $data = array(
            ':page' => ($page-1)*$perpage,
            ':perpage' => $perpage,
        );
        $sql .= ' and b.phone != ""';
        //判断是否是代理
        if($role_name == "商户"){
            $sql .=' and b.`mch_id` = '.$m_id;
        }
        if($name != ''){
            $sql .=' and c.realname = "'.$name.'"';
        }
        if($merchant_id !=''){
            $sql .=' and b.`mch_id` = '.$merchant_id;
        }
        if($card !=''){
            $sql .=' and a.`cardNumber` = "'.$card.'"';
        }
        if($bank !=''){
            $sql .=' and a.`bank` = "'.$bank.'"';
        }
        if ($phone) {
            $sql .=' and b.`phone` = :phone';
            $data[':phone'] = $phone;
        }
        if($page!='' && $perpage!=''){
            $sql .=' order by b.id desc limit :page,:perpage ';
        }
        
        $str = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
        $mid = '';
        foreach($str as &$v){
            if($v['mch_id'] != 0){
                $mid.= $v['mch_id'].',';
            }
        }
        //查询代理名称
        if(!empty($mid)){
            $mid = trim($mid,',');
            $modify = XbModule_Merchant_Merchant::getInstance()->inMerchart($mid);
            $modifyArray = array();
            foreach($modify as $k=>$vel){
                $modifyArray[$vel['id']] = $vel;
            }
            foreach($str as &$v){
                $v['m_name'] = 0;
                if(!empty($modifyArray[$v['mch_id']])){
                    $v['m_name'] = $modifyArray[$v['mch_id']]['name'];
                }
            }
        }
        return $str;
    }
    
    //获取信用卡列表
    public function getCreditcardCount($card = '',$name = '',$bank = '',$merchant_id = '',$role_name = '',$m_id = '',$phone = ''){
        $sql = 'select count(*) from users b LEFT JOIN users_creditcard a on b.id = a.uid LEFT JOIN users_profile c on b.id = c.uid where 1=1';
        $data = array(
        );
        $sql .= ' and b.phone != ""';
        //判断是否是代理
        if($role_name == "商户"){
            $sql .=' and b.`mch_id` = '.$m_id;
        }
        if($name != ''){
            $sql .=' and c.realname = "'.$name.'"';
        }
        if($merchant_id !=''){
            $sql .=' and b.`mch_id` = '.$merchant_id;
        }
        if($card !=''){
            $sql .=' and a.`cardNumber` = "'.$card.'"';
        }
        if($bank !=''){
            $sql .=' and a.`bank` = "'.$bank.'"';
        }
        if ($phone) {
            $sql .=' and b.`phone` = :phone';
            $data[':phone'] = $phone;
        }
        
        $str = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchColumn(0);

        return $str;
    }

    /**
     *@desc 修改用户通道状态
     */
    public function updateChannelStatus($uid,$status,$channel_id,$channel_code,$channel_key){
        //获取用户通道信息
        $user_channel_sql = "SELECT `id`,`uid` FROM `users_channel_code` WHERE `uid` = :uid AND `channel_id` = :channel_id";
        $user_channel_data = array(
            ':uid'          => $uid,
            ':channel_id'  => $channel_id
        );
        $user_channel_res = $this->dao->conn()->noCache()->preparedSql($user_channel_sql, $user_channel_data)->fetchOne();
        if($user_channel_res){
            if($status != $user_channel_res['status']){
                $up_channel_sql ='UPDATE `users_channel_code` set `status`=:status WHERE `id`=:id';
                $up_channel_data = array(
                    ':id'       =>   $user_channel_res['id'],
                    ':status'   =>   $status
                );
                $channel_res = $this->dao->conn(false)->noCache()->preparedSql($up_channel_sql, $up_channel_data)->affectedCount();

            }
        }else{
            $channel_sql = 'INSERT INTO `users_channel_code` (`uid`,`channel_id`,`channel_code`,`status`,`create_time`,`channel_key`) VALUES (:uid,:channel_id,:channel_code,:status,:create_time,:channel_key)';
            $channel_data = array(
                ':uid'           => $uid,
                ':channel_id'   => $channel_id,
                ':channel_code' =>$channel_code,
                ':create_time'  => time(),
                ':status'       => $status,
                ':channel_key'       => $channel_key,
            );
            $channel_res = $this->dao->conn(false)->noCache()->preparedSql($channel_sql, $channel_data)->affectedCount();
        }
        if(!$channel_res){
            XbFunc_Log::write('changeStatus','用户【'.$uid.'】通道ID【'.$channel_id.'】users_channel_code执行结果:'.json_encode($channel_res));
            return false;
        }
    return true;
    }
    
    
    
    /**
     *@用户四要素校验
     */
    public function checkBank($uid,$bankCardNumber,$phone,$idcardNumber,$realname,$type){
        $time = time();
        $order_id = XbModule_Account_OrderCode::getInstance()->getOrderCode();
        $sql = " INSERT INTO `users_check_bank` (`uid`,`order_id`,`acct_no`,`phone_no`,`id_no`,`name`,`card_type`,`create_time`) VALUES (:uid,:order_id,:acct_no,:phone_no,:id_no,:name,:card_type,:create_time)";
        $data = array(
            ':uid'           => $uid,
            ':order_id'      => $order_id,
            ':acct_no'       => $bankCardNumber,
            ':phone_no'         => $phone,
            ':id_no'         => $idcardNumber,
            ':name'          => $realname,
            ':card_type'     => $type,
            ':create_time'   => $time,
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql,$data)->lastInsertId();
        if($res){
            $checkData['bankcardNumber'] = $bankCardNumber;
            $checkData['phone'] = $phone;
            $checkData['idcardNumber'] = $idcardNumber;
            $checkData['realname'] = $realname;
            $check = XbLib_CardBin::getInstance($checkData)->cardBin();
//            var_dump($check);die;
            if($check){
                $changeCheck['id'] = $res;
                $changeCheck['code'] = $check['code'];
                $changeCheck['reason'] = $check['msg'];
                $this->dao->conn(false)->beginTransaction();
                $changeSql = "UPDATE `users_check_bank` set `code`=:code,`reason`=:reason WHERE `id`=:id";
                $changeRes = $this->dao->noCache()->preparedSql($changeSql,$changeCheck)->affectedCount();
                if(!$changeRes){
                    $this->dao->rollback();
                    XbFunc_Log::write('checkBank',"用户ID【".$res."】四要素检验--修改校验状态失败，".json_encode($changeRes),'SQL:'.$changeSql,'参数:'.json_encode($changeCheck));
                    return false;
                }
                $updata_profile_sql = "UPDATE `users_profile` set `reason`=:reason,`check_bank_id`=:check_bank_id WHERE `uid`=:uid";
                $updata_profile_data = array(
                    ':reason'=>$check['msg'],
                    ':check_bank_id'=>$res,
                    ':uid'=>$uid
                );
                $updata_profile_res = $this->dao->noCache()->preparedSql($updata_profile_sql,$updata_profile_data)->affectedCount();
                if(!$updata_profile_res){
                    $this->dao->rollback();
                    XbFunc_Log::write('checkBank',"用户ID【".$res."】四要素检验--修改用户profile表失败，".json_encode($updata_profile_res),'SQL:'.$updata_profile_sql.'参数:'.json_encode($updata_profile_data));
                    return false;
                }
                return $this->dao->commit();
            }else{
                XbFunc_Log::write('checkBank',"用户ID【".$res."】四要素检验失败，".json_encode($check));
                return false;
            }
        }else{
            XbFunc_Log::write('checkBank',"用户ID【".$res."】四要素入库失败，".json_encode($res).'参数：'.json_encode($data).'SQL:'.$sql);
            return false;
        }
    }
    
    /**
     * 调用 四要素 校验(不同步更新到用户数据)
     * 
     * @param unknown $uid
     * @param unknown $bankCardNumber
     * @param unknown $phone
     * @param unknown $idcardNumber
     * @param unknown $realname
     * @param unknown $type
     * @return boolean|string 调用成功返回user_check_bank表记录
     */
    public function check4ys($uid,$bankCardNumber,$phone,$idcardNumber,$realname,$type) {
        $time = time();
        $order_id = XbModule_Account_Order::getInstance(1)->getOrderCode();
        $sql = " INSERT INTO `users_check_bank` (`uid`,`order_id`,`acct_no`,`phone_no`,`id_no`,`name`,`card_type`,`create_time`) VALUES (:uid,:order_id,:acct_no,:phone_no,:id_no,:name,:card_type,:create_time)";
        $data = array(
            ':uid'           => $uid,
            ':order_id'      => $order_id,
            ':acct_no'       => $bankCardNumber,
            ':phone_no'         => $phone,
            ':id_no'         => $idcardNumber,
            ':name'          => $realname,
            ':card_type'     => $type,
            ':create_time'   => $time,
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql,$data)->lastInsertId();
        if($res){
            $checkData['bankcardNumber'] = $bankCardNumber;
            $checkData['phone'] = $phone;
            $checkData['idcardNumber'] = $idcardNumber;
            $checkData['realname'] = $realname;
            $check = XbLib_CardBin::getInstance($checkData)->cardBin();

            if($check){
                $changeCheck['id'] = $res;
                $changeCheck['code'] = $check['code'];
                $changeCheck['reason'] = $check['msg'];

                $changeSql = "UPDATE `users_check_bank` set `code`=:code,`reason`=:reason WHERE `id`=:id";
                $changeRes = $this->dao->noCache()->preparedSql($changeSql,$changeCheck)->affectedCount();
                if(!$changeRes){
                    XbFunc_Log::write('checkBank',"用户ID【".$res."】四要素检验--修改校验状态失败，".json_encode($changeRes),'SQL:'.$changeSql,'参数:'.json_encode($changeCheck));
                    return false;
                }
                
                return  $res;
            }else{
                XbFunc_Log::write('checkBank',"用户ID【".$res."】四要素检验失败，".json_encode($check));
                return false;
            }
        }else{
            XbFunc_Log::write('checkBank',"用户ID【".$res."】四要素入库失败，".json_encode($res).'参数：'.json_encode($data).'SQL:'.$sql);
            return false;
        }
    }
    
    /**
     * @desc 获取用户四要素校验结果
     * */
    public function getCheckBankResult($id){
        $sql = "SELECT * FROM `users_check_bank` WHERE `id`=:id";
        $data = array(
            ':id' => $id
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }
    /**
     * @ desc 根据状态获取用户信息
     * */
    public function getUserByStatus($status, $limit=false, $num=false){
        $sql = 'SELECT * FROM `users_profile` WHERE `status`=:status';
        $data = array(
            ':status' => $status
        );
        if($limit !== false){
            $sql .= ' LIMIT :limit, :num';
            $data[':limit'] = $limit;
            $data[':num']   = $num;
        }
        return $this->dao->conn()->noCache()->preparedSql($sql,$data)->fetchAll();
    }
    /**
     * @ desc 记录用户进件失败日志
     * */
    public function userChannelError($param){
        $sql = 'INSERT INTO `users_channel_log` VALUES (null, :uid, :channel_id, :code, :message, :create_time);';
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $param)->lastInsertId();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }
    
     /**
     * @ desc 获取用户进件信息
     * */
    public function getUserChannelInfo($uid)
    {
        $channel = XbLib_ChannelFunc_Channel::getInstance()->channel;
        $sql_channel = 'SELECT c.channel_id,c.channel_name,s.channel_code FROM `common_channel` c LEFT JOIN `users_channel_code` s ON c.channel_id = s.channel_id AND s.uid = :uid WHERE c.channel_id in (' . join(',', array_keys($channel)) . ')';
        $data = array(
            ':uid' => $uid,
        );
        $channel_arr = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_channel, $data)->fetchAll();

        foreach ($channel_arr as $key => $value) {
            $log_arr = '';
            if (empty($value['channel_code'])) {
                //进件失败的通道
                $sql = 'SELECT `code`,`message` FROM `users_channel_log` WHERE `uid` = :uid AND `channel_id` = :channel_id ORDER BY id desc ';
                $data = array(
                    ':uid' => $uid,
                    ':channel_id' => $value['channel_id']
                );
                $log_arr = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
            }
            $channel_arr[$key]['channel_log'] = $log_arr;
        }

        return $channel_arr;
    }
}
<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/12/23
 * Time: 18:12
 */
class XbModel_Comment_Collect extends XbModel_BaseModel{
    static $cache_tag = "Comment_Collect_";
    //链接库
    function __construct() {
        parent::_init("xb_comment");
    }
    //获取收藏
    public function getAll($uid,$start,$limit){
        $sql = 'select * from `collect` where 1=1 ';
        $data = array();
        if(!empty($uid)){
            $sql .=' and `uid`=:uid ';
            $data[':uid']=$uid;
        }
        $sql .= ' ORDER BY `id` desc ';
        $sql .= ' LIMIT :start,:limit';
        $data[':start'] = $start;
        $data[':limit'] = $limit;
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }
    
    /**
     * 取消收藏
     * @param $uid
     * @param $nid
     * @param $type
     * @return array|XbLib_WebError
     */
    public function cancel($uid,$tid,$type){
        $sql = 'delete from `collect` where `tid`=:tid and `uid`=:uid and `type`=:type';
        $data = array(
            ':tid'        => $tid,
            ':uid'       => $uid,
            ':type'  => $type
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
    }
    
    /**
     * 根据uid查询收藏
     * @param $id
     * @return mixed|XbLib_WebError
     */
    public function getDetail($uid,$tid,$type) {
        $sql = 'select * from `collect` where 1=1 ';
        $data = array();
        if(!empty($uid)){
            $sql .=' and `uid`=:uid ';
            $data[':uid']=$uid;
        }
        if(!empty($tid)){
            $sql .=' and `tid`=:tid ';
            $data[':tid']=$tid;
        }
        if(!empty($type)){
            $sql .=' and `type`=:type ';
            $data[':type']=$type;
        }

        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }
    
    //添加
    public function insert($uid, $tid, $type){
        $sql = 'INSERT INTO `collect` (`tid`, `uid`,`type`,`create_time`) VALUES (:tid,:uid,:type,:create_time)';
        $data = array(
            ':tid'        => $tid,
            ':uid'       => $uid,
            ':type'  => $type,
            ':create_time'      => time()
        );
       return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
       
    }
    
}
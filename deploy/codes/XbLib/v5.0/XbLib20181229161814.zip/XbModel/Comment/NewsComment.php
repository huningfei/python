<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/12/23
 * Time: 18:12
 */
class XbModel_Comment_NewsComment extends XbModel_BaseModel{
    static $cache_tag = "Comment_NewsComment_";
    //链接库
    function __construct() {
        parent::_init("xb_comment");
    }
    //获取评论
    public function getAll($nid){
        $sql = 'select * from `news_comment` where 1=1 ';
        $data = array();
        if(!empty($nid)){
            $sql .=' and `nid`=:nid ';
            $data[':nid']=$nid;
        }
        $sql .= ' ORDER BY `id` desc ';
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }
    
    
    //添加
    public function insert($uid, $nid, $content){
        $sql = 'INSERT INTO `news_comment` (`nid`, `uid`,`content`,`create_time`) VALUES (:nid,:uid,:content,:create_time)';
        $data = array(
            ':nid'        => $nid,
            ':uid'       => $uid,
            ':content'  => $content,
            ':create_time'      => time()
        );
       return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
       
    }
    
}
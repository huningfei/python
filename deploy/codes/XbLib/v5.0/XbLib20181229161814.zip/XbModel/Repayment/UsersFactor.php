<?php
/**
 * @desc 	用户还款渠道注册
 * @author  qien
 * @date    18.04.14
 */
class XbModel_Repayment_UsersFactor extends XbModel_BaseModel{
    public static $cache_tag = "Repayment_UsersFactor_";
    public static $cache_expire = 259200;
    function __construct() {
        parent::_init("xb_repayment");
    }

    /**
    * @desc    创建用户随机因子
    * @param   int     $uid        用户id
    * @param   int     $type       类型（根据每次平均还款区间定）
    * @param   string  $factor     随机因子
    * @return  boolen  $return     返回创建结果
    */
    public function createFactor($uid, $type, $factor){
        $sql = 'INSERT INTO `users_rand_factor`(`uid`, `type`, `factor`, `create_time`) VALUES(:uid, :type, :factor, :create_time)';
        $data = array(
            ':uid'         => $uid,
            ':type'        => $type,
            ':factor'      => $factor,
            ':create_time' => time()
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /**
     * @desc    获取用户随机因子
     * @param   int     $uid        用户id
     * @param   int     $type       类型
     * @return  boolen  $return     返回创建结果
     */
    public function getUsersFactor($uid, $type){
        $sql = 'SELECT * FROM `users_rand_factor` WHERE `uid`=:uid AND `type`=:type';
        $data = array(
            ':uid'  => $uid,
            ':type' => $type
        );
        return $this->dao->conn(false)->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }
}
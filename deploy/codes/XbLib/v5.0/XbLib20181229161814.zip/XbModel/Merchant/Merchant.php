<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/12/23
 * Time: 18:12
 */
class XbModel_Merchant_Merchant extends XbModel_BaseModel{
    static $cache_tag = "Merchant_Merchant_";
    //链接库
    function __construct() {
        parent::_init("xb_mis");
    }
    //商户列表
    public function index($name='',$telphone='',$start_time='',$end_time='',$page='',$perpage='', $app=''){
        $start_time = strtotime($start_time);
        $end_time = strtotime($end_time);
        $sql = 'select * from `merchant` as m LEFT JOIN  `merchant_app` as a on m.`id`=a.`id` LEFT JOIN `level` as l on m.level=l.level LEFT JOIN `by_level` as b on m.by_level=b.by_level where 1=1 ';
        $data = array(
            ':page' => ($page-1)*$perpage,
            ':perpage' => $perpage,
        );
        if($name !=''){
          $sql .=' and m.`name` like "%'.$name.'%"';
        }
        if($telphone !=''){
            $sql .=' and m.`telphone` = "'.$telphone.'"';
        }
        if($start_time !=''){
            $sql .=' and m.`creattime` >= '.$start_time;
        }
        if($end_time !=''){
            $sql .=' and m.`creattime` <= '.$end_time;
        }
        if($app != ''){
            $sql .=' and a.`app` = '.$app;
        }
        if($page!=''&&$perpage!=''){
            $sql .=' order by m.id desc limit :page,:perpage ';
        }
        $res =  $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->fetchAll();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }
    //添加商户
    public function addMerchant($name,$email,$telphone,$type,$source,$level,$key,$creattime,$app,$by_level,$start_page,$log,$and_number,$ios_number,$ios_description,$and_description,$ios_download,$and_download){
        $sql = 'INSERT INTO `merchant` (`name`, `email`, `telphone`, `type`, `source`, `level`,`key`,`creattime`,`by_level`,`log`) VALUES (:name,:email,:telphone,:type,:source,:level,:key,:creattime,:by_level,:log)';
        $data = array(
            ':name'        => $name,
            ':email'       => $email,
            ':telphone'    => $telphone,
            ':type'        => $type,
            ':source'      => $source,
            ':level'       => $level,
            ':key'         => $key,
            ':creattime'   => $creattime,
            ':by_level'   => $by_level,
            ':log'   => $log
        );
        $res =$this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
        if($res){
            $sql_app = 'INSERT INTO `merchant_app` (`id`,`app`,`start_page`,`and_number`,`ios_number`,`ios_description`,`and_description`,`ios_download`,`and_download`) VALUES (:id,:app,:start_page,:and_number,:ios_number,:ios_description,:and_description,:ios_download,:and_download)';
            $data_app = array(
                ':id'        => $res,
                ':app'        => $app,
                ':start_page' => $start_page,
                ':and_number' => $and_number,
                ':ios_number' => $ios_number,
                ':ios_description' => $ios_description,
                ':and_description' => $and_description,
                ':ios_download' => $ios_download,
                ':and_download' => $and_download,
            );
            $res = $this->dao->conn(false)->noCache()->preparedSql($sql_app, $data_app)->affectedCount();
            if($res){
                $this->dao->clearTag(self::$cache_tag);
            }
            return $res;
        }
    }
    //修改商户信息
    public function updateMerchant($name,$email,$telphone,$type,$source,$level,$app,$by_level,$start_page,$id,$log,$and_number,$ios_number,$ios_description,$and_description,$ios_download,$and_download){
        $sql = 'UPDATE `merchant` SET  `name`=:name,`email`=:email,`telphone`=:telphone,`type`=:type,`source`=:source,`level`=:level,`by_level`=:by_level,`log`=:log WHERE id=:id';
        $data = array(
            ':id'          => $id,
            ':name'        => $name,
            ':email'       => $email,
            ':telphone'    => $telphone,
            ':type'        => $type,
            ':source'      => $source,
            ':level'       => $level,
            ':by_level'    => $by_level,
            ':log'    => $log
        );
        $res =$this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        $sql_app = 'UPDATE `merchant_app` SET `app`=:app,`start_page`=:start_page ,`and_number`=:and_number,`ios_number`=:ios_number,`ios_description`=:ios_description,`and_description`=:and_description,`ios_download`=:ios_download,`and_download`=:and_download where id=:id';
        $data_app = array(
            ':id'        => $id,
            ':app'        => $app,
            ':start_page' => $start_page,
            ':and_number' => $and_number,
            ':ios_number' => $ios_number,
            ':ios_description' => $ios_description,
            ':and_description' => $and_description,
            ':ios_download' => $ios_download,
            ':and_download' => $and_download,
        );
        $res =  $this->dao->conn(false)->noCache()->preparedSql($sql_app, $data_app)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }
    //商户详情
    public function details($id){
        $sql = 'select * from `merchant` as m LEFT JOIN  `merchant_app` as a on m.`id`=a.`id` LEFT JOIN `level` as l on m.level=l.level LEFT JOIN `by_level` as b on m.by_level=b.by_level  WHERE m.`id`=:id';
        $data = array(
            ':id' => $id,
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
    }
    //修改按钮
    public function modifyButtonUpdate($id,$app){
        if($app ==1 ){
            $app1=2;
        }else{
            $app1=1;
        }
        $sql = 'UPDATE `merchant_app` SET `app`=:app where id=:id';
        $data= array(
            ':id'        => $id,
            ':app'        => $app1,
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
    }
    //把收益写入数据库
    public function insertProfit($m_id,$money){
        $time = time()-(3600*24);
        $sql_app = 'INSERT INTO `profit` (`m_id`,`time`,`money`) VALUES (:m_id,:time,:money)';
        $data_app = array(
            ':m_id'        => $m_id,
            ':money'        => $money,
            ':time'        => $time,
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql_app, $data_app)->affectedCount();
    }
    //计算商户分润总额
    public function updateTransactio($id,$money){
        $sql = 'UPDATE `merchant` SET `transactio`=:money+`transactio` where id=:id';
        $data= array(
            ':id'        => $id,
            ':money'     => $money,
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
    }

    //用于商户注册列表查询
    public function inMerchart($id)
    {
        $sql = 'select `id`,`name` from `merchant` where id in(' . $id . ')';
        $data = array();
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }

    /*
     * @desc  获取代理列表
     * @return   array     $return    返回执行结果
     * */
    public function getMerchant(){
        $sql = 'select * from `merchant`';
        $data = array();
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }

    /*
     * @desc   通过域名获取商户详情
     * @param   string    $sld    二级域名
     * @return  array     $return 返回执行结果
     * */
    public function getDetails($sld){
        $sql = 'select * from `merchant` as m LEFT JOIN  `merchant_app` as a on m.`id`=a.`id` LEFT JOIN `level` as l on m.level=l.level LEFT JOIN `by_level` as b on m.by_level=b.by_level  WHERE m.`sld`=:sld';
        $data = array(
            ':sld' => $sld,
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }
}
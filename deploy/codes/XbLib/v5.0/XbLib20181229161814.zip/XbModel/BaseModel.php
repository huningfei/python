<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2014-9-22
 * UTF-8
 */
class XbModel_BaseModel{
    /**
     * @var null|XbLib_Dao
     */
    protected $dao = null;
	protected function _init($db_tag){
		$this->dao = new XbLib_Dao($db_tag);
	}
	
	/**
	 * build where 条件
	 * @param unknown $where
	 * @param unknown $data
	 * @return string
	 */
	protected function buildWhere($where,&$data){
		$where_str = '';
		$where_data = array();
		if(is_array($where) && !empty($where)){
			$keys = array_keys($where);
			foreach($keys as $wk){
				$where_str .= "`{$wk}`=:{$wk} AND";
				$where_data[":{$wk}"] = $where[$wk];
			}
		}else{
			return '';
		}
		if(!empty($where)){
			$where_str = "WHERE ".substr($where_str, 0, -4);
		}
		$data = $where_data;
		return $where_str;
	}
	
	/**
	 * 创建INSERTStr
	 * @param unknown $table
	 * @param unknown $arr
	 * @param unknown $data
	 * @return string
	 */
	protected function buildInsertStr($table,$arr,&$data){
		$sql = "INSERT INTO `{$table}` ";
		if(empty($arr) || !is_array($arr)){
			return '';
		}
		$str1 = '';
		$str2 = '';
		
		foreach ($arr as $key=>$val){
			$str1 .= "`{$key}`,";
			$str2 .= ":{$key},";
			$data[":{$key}"] = $val;
		}
		$str1 = substr($str1, 0, -1);
		$str2 = substr($str2, 0, -1);
		$sql .="({$str1}) VALUES ({$str2})";
		return $sql;
	}
	
	/**
	 * 组建更新字符串
	 * @param unknown $table
	 * @param unknown $arr
	 * @param unknown $where_arr
	 * @param unknown $data
	 * @return string
	 */
	protected function buildUpdateStr($table,$arr,$where_arr,&$data){
		$sql = "UPDATE `{$table}` SET ";
		if(empty($arr) || !is_array($arr)){
			return '';
		}
		foreach ($arr as $key=>$value){
			//构造数值
			$data[":{$key}"] = $value;
			//构造语句
			$sql .= "`{$key}`=:{$key},";
		}
		$sql = substr($sql, 0, -1);
		$where_data = array();
		$where_str = $this->buildWhere($where_arr, $where_data);
		$sql .= " ".$where_str;
		$data = array_merge($data, $where_data);
		return $sql;
	}
	
	/**
	 * 新增一条记录
	 * @param string $table
	 * @param array $arr
	 * @param boolean $cache
	 * @param string $tag_key
	 * @param boolean $returnLastId
	 * @return Ambigous <number, string>
	 */
	protected function insertData($table,$arr,$cache=false,$tag_key='',$returnLastId=true){
		$pre_data = array();
		$pre_sql = $this->buildInsertStr($table, $arr, $pre_data);
		
		$this->dao->conn(false);
		if($cache){
			$this->dao->setTag($tag_key);
		}else{
			$this->dao->noCache();
		}
		//新增一条记录
		if($returnLastId){
			$res = $this->dao->preparedSql($pre_sql, $pre_data)->lastInsertId();
		}else{
			$res = $this->dao->preparedSql($pre_sql, $pre_data)->affectedCount();
		}
		return $res;
	}
	
	/**
	 * 更新一条记录
	 * @param unknown $table
	 * @param unknown $arr
	 * @param unknown $where
	 * @param string $cache
	 * @param string $tag_key
	 * @return number
	 */
	protected function updateData($table,$arr,$where,$cache=false,$tag_key=''){
		$pre_data = array();
		$pre_sql = $this->buildUpdateStr($table, $arr, $where, $pre_data);
		
		$this->dao->conn(false);
		if($cache){
			$this->dao->setTag($tag_key);
		}else{
			$this->dao->noCache();
		}
		//修改一条记录
		$res = $this->dao->preparedSql($pre_sql, $pre_data)->affectedCount();
		return $res;
	}
    /**
     * 查询数据
     * @param unknown $table
     * @param unknown $arr
     * @param unknown $where
     * @param string $cache
     * @param string $tag_key
     * @return number
     */
    protected function queryData($table,$filed,$where,$key,$tag_key='',$need=1,$cache=false){
        $pre_data = array();
        $this->dao->conn();
        if($cache){
            $this->dao->setTag($tag_key);
        }else{
            $this->dao->noCache();
        }
        if(empty($filed)){
            $filed = ' * ';
        }
        if(!empty($where)){
            $where = ' WHERE '.$where;
        }
        $sql = "SELECT $filed FROM $table".$where;
        //查询记录
        $res = $this->dao->preparedSql($sql,array())->fetchAll();
        $result = array();
        $data_str = array();
        foreach($res as $v){
            if($need){
                if($v[$key] != 0){
                    $data_str []= $v[$key];
                }
                $result['res'][$v[$key]] = $v;
            }else{
                $result[$v[$key]] = $v;
            }

        }
        if ($need){
            $result['str'] = $data_str;
        }
        return $result;
    }
}
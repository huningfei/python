<?php
/**
 * 注册Library
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2014-9-21
 * UTF-8
 */

define("LIBRARY_DIR",dirname(__FILE__));
require_once LIBRARY_DIR.'/Core/loader.php';

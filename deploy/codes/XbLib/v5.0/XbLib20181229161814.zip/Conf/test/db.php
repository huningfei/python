<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2015-10-27
 * UTF-8
 */
$default_w_host = '127.0.0.1';
$default_w_port = '3306';
$default_w_user = 'root';
$default_w_password = '123456';
$default_w_charset = 'utf8';

$default_r_host = '127.0.0.1';
$default_r_port = '3306';
$default_r_user = 'root';
$default_r_password = '123456';
$default_r_charset = 'utf8';

//服务数据库
$db['cinfax_service'] = array(
		'writer' => array (
				'host' => $default_w_host,
				'port' => $default_w_port,
				'user' => $default_w_user,
				'password' => $default_w_password,
				'database' => 'cinfax_service',
				'charset' => $default_w_charset
		),
		'reader' => array (
				array (
					'host' => $default_r_host,
					'port' => $default_r_port,
					'user' => $default_r_user,
					'password' => $default_r_password,
					'database' => 'cinfax_service',
					'charset' => $default_r_charset
				)
		)
);
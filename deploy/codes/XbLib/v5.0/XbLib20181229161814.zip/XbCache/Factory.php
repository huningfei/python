<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2014-9-23
 * UTF-8
 */
class XbCache_Factory{
	private $XbCache_config;
	private $adapter;
	
	/**
	 * 获得Factory对象
	 * @param string $XbCache_adapter
	 * @throws Exception
	 */
	function __construct($cache_adapter='memcached'){
		$env = getenv('RUNTIME_ENVIROMENT') ? getenv('RUNTIME_ENVIROMENT') : (defined('SHELL_VARIABLE') ? SHELL_VARIABLE : '');
		$env = empty($env)?'local':$env;
		$config = require (LIBRARY_DIR.'/Conf/'.$env.'/cache.php');
		if(!isset($config[$cache_adapter])){
			throw new Exception('can not found the XbCache_config env:'.$env.' cache adapter:'.$cache_adapter);
		}
		$this->XbCache_config = $config[$cache_adapter];
		$this->adapter = $cache_adapter;
	}
	
	/**
	 * 
	 * @return Ambigous <NULL, TyXbCache_Abstract,TyXbCache_Interface>
	 */
	function getCacheAdapter(){
		$adapter = null;
		switch ($this->adapter){
			case 'memcache':
				$adapter = new XbCache_Adapter_Memcache($this->XbCache_config);
				break;
			case 'memcached':
				$adapter = new XbCache_Adapter_Memcached($this->XbCache_config);
				break;
			default:
		}
		return $adapter;
	}
}
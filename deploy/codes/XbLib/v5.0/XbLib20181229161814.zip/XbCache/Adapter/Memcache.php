<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2014-9-23
 * UTF-8
 */
class XbCache_Adapter_Memcache extends XbCache_Abstract implements XbCache_Interface {
	private $mem = null;
	
	function __construct($XbCache_config) {
		$this->mem = new Memcache ();
		foreach ( $XbCache_config as $config ) {
			$this->mem->addserver ( $config ['host'], $config ['port'],false, $config ['weight'] );
		}
		
	}
	
	/**
	 * (non-PHPdoc)
	 * @see TyXbCache_Interface::set()
	 */
	public function set($key, $value, $expire=600) {
		$obj = '';
		$obj = serialize($value);
		$result = $this->mem->replace ( $key, $obj, false, $expire );
		
		if (! $result) {
			$result = $this->mem->set ( $key, $obj, false, $expire );
			
		}
		
		return $result;
	}
	
	/**
	 * (non-PHPdoc)
	 * @see TyXbCache_Interface::get()
	 */
	public function get($key) {
		$result = $this->mem->get($key);
		$res = unserialize($result);
		if(empty($result)||empty($res)){
			return $result;
		}
		
		return $res;
	}
	
	/**
	 * (non-PHPdoc)
	 * @see TyXbCache_Interface::delete()
	 */
	public function delete($key){
		$result = $this->mem->delete($key);
		return $result;
	}
}
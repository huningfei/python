<?php
//定时计划脚本
//首期支付,其他期代付并在计划表中插入代付数据
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", empty($argv[1]) ? 'rls' : $argv[1]);
$page         = 1;
$num          = 10;
$mch_id       = 2;
$count        = 0;
$channel_id   = 5;
$channel_name = '雅酷酷宝';
$statusArr = array(0, 4);
do{
    //搜索需要执行的计划清单, 每次10个
    $limit = ($page - 1)*$num;
    $orderPlan = XbModule_Repayment_Order::getInstance($mch_id)->scriptOrderPlan($limit, $num);
    if(!$orderPlan){
        XbFunc_Log::write('orderPlanExec', '定时计划脚本执行结束', '此次共执行：'.$count.'条');
        break;
    }
    foreach($orderPlan as $k=>$v){
        //获取此计划订单是否正在执行
        $orderInfo = XbModule_Repayment_Order::getInstance($mch_id)->getOrderById($v['oid']);
        //第一期扣款，第二期先调用代付（打款）
        if($v['issue'] == 1){
            //如果订单执行过扣款以后，不执行
            if($v['real_status'] != 0){
                continue;
            }
            //判断订单状态，是否执行中
            if(!in_array($orderInfo['status'], $statusArr)){
                continue;
            }
            //调用扣款
            $res = XbModule_Repayment_Order::getInstance($mch_id)->orderPlanTrans($v, $orderInfo, $channel_id, $channel_name);
            if(!$res){
                XbFunc_Log::write('execRepaymentPlanError1', '刷卡失败，订单：'.$v['oid'], '订单号：'.$v['order_id']);
                continue;
            }
            $count++;
        }else{
            $issue = $v['issue'] - 1;
            if($issue < 1) continue;
            $checkPlan = XbModule_Repayment_Order::getInstance($mch_id)->getOrderByIssue($v['oid'], $issue, 1);
            if(!$checkPlan || $checkPlan['status'] != 1){
                continue;
            }
            $check = XbModule_Repayment_Order::getInstance($mch_id)->getOrderByIssue($v['oid'], $issue, 2);
            if($check){
                XbFunc_Log::write('execRepaymentPlan', '订单计划执行错误：'.json_encode($check));
                continue;
            }
            $withdrawInfo = XbModule_Repayment_Order::getInstance($mch_id)->getOrderByIssue($v['oid'], $issue, 1);
            if(!$withdrawInfo){
                XbFunc_Log::write('execRepaymentPlanError', '订单计划执行失败：查询上一期任务失败，导致无法体现'.json_encode($v));
                continue;
            }
            $res = XbModule_Repayment_Order::getInstance($mch_id)->orderPlanWithdraw($withdrawInfo, $orderInfo, $channel_id, $channel_name);
            if(!$res){
                XbFunc_Log::write('execRepaymentPlanError', '订单计划执行失败：代付提现失败'.json_encode($withdrawInfo));
                continue;
            }
        }
    }
    $page++;
}while(true);


echo 'ExecRepaymentPlan';

<?php
//用户注册还款通道

$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", 'rls');

$user = XbModule_Account_UsersProfile::getInstance()->getUsersByStatus(3);
//var_dump($user);exit;
foreach($user as $k=>$v){
    //var_dump($v);exit;
    XbModule_Repayment_UsersChannel::getInstance()->signUpChannel($v['uid']);
    usleep(500000);
}
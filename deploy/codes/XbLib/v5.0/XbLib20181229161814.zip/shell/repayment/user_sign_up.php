<?php
//还款通道 所有审核通过的用户进件
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", empty($argv[1]) ? 'rls' : $argv[1]);

//需要进件的通道
$channels = array(
    5 => 'yakukubao'
);

$num = 10;
$page = 1;
do{
    $limit = ($page - 1)*$num;
    $userProfile = XbModule_Account_UsersProfile::getInstance()->getUsersByStatus(3, $limit, $num);
    if(!$userProfile) break;
    foreach($userProfile as $key => $val){
        //获取用户已注册通道
        $user_hannel = [];
        $user_hannel =XbModule_Repayment_UsersChannel::getInstance()->getAllUserChannelByUid($val['uid']);
        $user_hannel_arr = array_column($user_hannel,'channel_id');


        foreach($channels as $kk=>$vv){
            if (in_array($kk, $user_hannel_arr)){
                //当前通道已经进件
                echo "用户ID【".$val['uid']."】通道".$kk."【".$vv."】已经进件\n";
                continue;
            }

            $res_signup = XbModule_Repayment_UsersChannel::getInstance()->userSignUp($kk, $val['uid']);
            if ($res_signup instanceof XbLib_WebError) {
                $msg = !empty($res_signup->getMessage()) ? $res_signup->getMessage() : '';
                echo "用户ID【".$val['uid']."】通道".$kk."【".$vv."】进件失败\n";
                XbFunc_Log::write('user_sign_up_repayment', '通道进件失败：'. $val['uid'] .' '. $kk .' '. $msg);
            }else{
                echo "用户ID【".$val['uid']."】通道".$kk."【".$vv."】进件成功.'user_channel_code id:'.$res_signup\n";
            }
        }
    }
    $page ++;
}while(true);

echo '执行完毕\n';


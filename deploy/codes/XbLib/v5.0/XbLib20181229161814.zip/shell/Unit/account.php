<?php
/**
 *
 * Author: abel
 * Date: 2017/12/12
 * Time: 12:00
 */

$unit_path = realpath(dirname(__FILE__));

include $unit_path . '/../../bootstrap.php';

use PHPUnit\Framework\TestCase;

class AccountTest extends TestCase {

    public function testSignup() {
        $phone = '18600019873';
        $password = '123456';
        $verification_code = '291113';
        $channel = 'ios';
        $sub_channel = '';
        $invite_phone = '';

        $res = XbModule_Account_Users::getInstance()->signup('ios', $phone, $password, $password, $verification_code, $channel, $sub_channel, $invite_phone);
        if ($res instanceof XbLib_WebError) {
            print $res->getMessage();
        }
    }

    public function testSignin() {
        $phone = "18600019873";
        $password = "123456";
        $res = XbModule_Account_Users::getInstance()->signin("ios", $phone, $password);

        if ($res instanceof XbLib_WebError) {
            print $res->getMessage();
            exit();
        }
        var_dump($res);
        exit();
    }
}
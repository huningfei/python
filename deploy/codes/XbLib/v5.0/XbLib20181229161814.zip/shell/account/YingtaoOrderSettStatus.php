<?php
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", 'rls');
$time = time();
$num = 20;
$page = 1;
do{
    $limit = ($page - 1)*$num;
    //获取没支付/结算中订单订单 order_play_money
    $orders  = XbModule_Repayment_Order::getInstance(1)->getPlayOrderByStatus('3','1', $limit, $num, $time);
    if(!$orders) exit;
    foreach($orders as $key => $val){
        $channel_id   =$val['channel_id'];
        $usersChannel = XbModule_Repayment_UsersChannel::getInstance()->getUserChannelInfo($val['uid'],$channel_id);
        $mch_id       = XbModule_Account_Users::getInstance()->getUserById($val['uid'])['mch_id'];
        //拉取结算状态
        $transfer['new_order_id'] =  XbModule_Account_OrderCode::getInstance()->getOrderCode();
        $transfer['order_id']     = $val['play_money_no'];
        $transfer['channel_code'] = $usersChannel['channel_code'];
        $transfer['channel_key']  = $usersChannel['channel_key'];
        $transfer_res = XbLib_Repayment_Channel::getInstance()->checkOrder($channel_id,$transfer);
        if($transfer_res && $transfer_res['res']['RESP_CODE'] != '0100' ){
            $res = $transfer_res['res'];
            //处理数据
            $params = array(
                'channel_id'   => $channel_id,
                'uid'          => $val['uid'],
                'serial_no'    => $res['ORDER_ID'],
                'order_no'     => $val['play_money_no'],
                'orderId'      => $res['ORG_ORDER_ID'],
                'externalld'   => $res['ORDER_ID'],
                'paytime'      => '',
                'pay_amount'   => $res['ORDER_AMT'],
                'after_amount' => $res['ORDER_AMT'],
                'amount'       => $res['ORDER_AMT'],
                'msg'          => $res['RESP_DESC'],
                'channel_code' => $res['USER_ID'],
                'code'         => $res['RESP_CODE']=='0000' ? 200 : $res['RESP_CODE'],
                'status'       => $res['RESP_CODE']=='0000' ? 1 : 2,
                'play_status'  => 1
            );

            //计算实际到账金额以及手机费
            $order =  XbModule_Repayment_Order::getInstance($mch_id)->getOrderByOrderId($val['order_no']);
            if(!$order){
                continue;
            }
            $params['order_id'] = $order['order_id'];
            $params['rate']     = $order['rate'];
            $params['fee']      = bcsub($order['amount'], $order['custom_amount'], 2);
            $res = XbModule_Repayment_Order::getInstance($mch_id)->settCallBackField($params, 2, $order);
            if($res){
                echo "订单【".$val['play_money_no'].'】通道【'.$channel_id."】拉取状态并更改结算状态成功\n";
            }else{
                echo "订单【".$val['play_money_no'].'】通道【'.$channel_id."】拉取状态并更改结算状态失败\n";
                XbFunc_Log::write('repaymentOrderStatus','修改订单结算状态失败：'.json_encode($params));
            }
        }else{
            echo "订单【".$val['play_money_no'].'】通道【'.$channel_id."】拉取状态失败\n";
            XbFunc_Log::write('repaymentOrderStatus','获取结算订单状态失败：'.json_encode($transfer));
        }
    }
    $page++;
}while(true);

echo 'yingtaoOrderSettStatus';




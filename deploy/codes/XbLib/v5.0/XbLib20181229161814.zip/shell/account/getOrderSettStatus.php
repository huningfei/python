<?php
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", 'rls');
$yibao_sett_status = array(
    'RECEIVED'   =>1,//已接收
    'PROCESSING' =>2,//处理中
    'SUCCESSED'  =>3,//打款成功
    'FAILED'     =>4,//打款失败
    'REFUNED'    =>5,//已退款
    'CANCELLED'  =>6//已撤销
);
do{
    //获取没支付/结算中订单订单
    $orders  = XbModule_Account_Order::getInstance(1)->getOrderByStatus('3');
    if(!$orders)  exit;
    foreach($orders as $key => $val){
        //获取结算订单号
        $play_money_no = XbModule_Account_Order::getInstance()->getOrderPlayData($val['axf_order_no']);
        if($play_money_no){
            $channel_level = XbModule_Account_Channel::getInstance()->getChannelInfoByChannelLevel($val['channel_id']);
            $channel_id     =$channel_level['channel_id'];
            $usersChannel = XbModule_Account_UsersChannel::getInstance()->getUsersChannelCode($val['uid'],$channel_id);
            $is_settlement = XbModule_Account_Channel::getInstance()->getChannelDetail( $channel_id);
            $mch_id = XbModule_Account_Users::getInstance()->getUserById($val['uid'])['mch_id'];
            //拉取结算状态
            $transfer['order_id'] = $play_money_no['play_money_no'];
            $transfer['channel_code'] = $usersChannel['channel_code'];
            $transfer['startTime'] =date('Y-m-d H:i:s',$play_money_no['create_time']-3600);
            $transfer['endTime'] = date('Y-m-d H:i:s',$play_money_no['create_time']+86400);
            $transfer_res = XbLib_ChannelFunc_Channel::getInstance()->transfer($channel_id,$transfer);
            if($transfer_res && $transfer_res['code'] == 0000 && count($transfer_res['transferRequests'])>0){
                $transfer_res = $transfer_res['transferRequests'][0];
                $arr['channel_code']            = $transfer_res['customerNumber'];
                $arr['play_money_no']           = $transfer_res['requestNo'];
                $arr['serial_no']               = $transfer_res['batchNo'];
                $arr['sett_transferway']       = 1;
                $arr['sett_amount']             = $transfer_res['amount'];
                $arr['sett_fee']                = bcsub($val['amount'],$transfer_res['amount'],2);
                $arr['sett_basic_fee']          = $transfer_res['basicFee'];
                $arr['sett_extarget_fee']       = $transfer_res['extTargetFee'];
                $arr['actual_amount']           = $transfer_res['actualAmount'];
                $arr['receiver']                 = $transfer_res['receiver'];
                $arr['receiver_bank']           = $transfer_res['receiverBank'];
                $arr['receiver_bank_card_no']  = $transfer_res['receiverBankCardNo'];
                $arr['reason']                   = $transfer_res['failReason'];
                $arr['pay_time']                 = $transfer_res['handleTime'];
                $arr['status']                   = $yibao_sett_status[$transfer_res['transferStatus']];
                $arr['uid']=$val['uid'];
                $res = XbModule_Account_Order::getInstance($mch_id)->callBackSettlement($arr);
                if($res){
                    echo "订单【".$val['order_id'].'】通道【'.$channel_id."】拉取状态并更改结算状态成功\n";
                }else{
                    echo "订单【".$val['order_id'].'】通道【'.$channel_id."】拉取状态并更改结算状态失败\n";
                    XbFunc_Log::write('orderCallback','修改订单结算状态失败：'.json_encode($play_money_data));
                }
            }else{
                echo "订单【".$val['order_id'].'】通道【'.$channel_id."】拉取状态失败\n";
                XbFunc_Log::write('orderCallback','获取结算订单状态失败：'.json_encode($transfer));
            }
        }else{
            echo "订单【".$val['order_id'].'】通道【'.$channel_id."】拉取状态并更改结算状态成功\n";
            XbFunc_Log::write('orderCallback','订单【'.$val['order_id'].'】没有结算订单：'.json_encode($val));
        }
    }
}while(true);






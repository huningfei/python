<?php
$http = new swoole_http_server("0.0.0.0", 9502);

$http->set([
    'worker_num' => 100,
    'task_worker_num' => 100,
    'open_tcp_nodelay' => true,
//    'daemonize' => 1,
    'log_file' => '/tmp/swoole_http_server_excel'.date('Y-m-d').'.log',
]);

$http->on('request', function(swoole_http_request $request, swoole_http_response $response) use ($http) {
    //请求过滤
    if($request->server['path_info'] == '/favicon.ico' || $request->server['request_uri'] == '/favicon.ico'){
        return $response->end('');
    }

    if (!$request->get['id']){
        return $response->end('ok');
    }

    $param = $request->get;
    $taskId = $http->task($param);
    $response->end("<h1>task_id: {$taskId} id: {$param['id']}</h1>");
});

$http->on('task', function($http, $taskId, $fromId, $data) {
    $unit_path = realpath(dirname(__FILE__));
    include $unit_path . '/../../bootstrap.php';
    XbFunc_Log::write('swoole_excel',"--$taskId-- 发送请求:id=".$data['id']);


    $id = $data['id'];
    $url = "https://m.xiaobaijinfu.com/Excel/importExecl?id=$id";
    $curl_obj = curl_init();
    curl_setopt($curl_obj, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($curl_obj, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($curl_obj, CURLOPT_SSLVERSION, 1);
    curl_setopt($curl_obj, CURLOPT_URL, $url);
    curl_setopt($curl_obj, CURLOPT_RETURNTRANSFER, 1 );

    $sContent = curl_exec($curl_obj);
    $aStatus = curl_getinfo($curl_obj);
    curl_close($curl_obj);
    XbFunc_Log::write('swoole_excel',"--$taskId-- 接收结果id:=".$data['id'].$sContent);

    //返回任务执行的结果
    $http->finish('');
});

$http->on('Finish', function($http, $taskId, $data){
    //TDDO 任务结束之后处理任务或者回调
    echo $data;
});

$http->start();
<?php
/**
 * Created by PhpStorm.
 * User: zq
 * Date: 2018/6/29
 * Time: 上午10:28
 */
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", 'rls');

$array = array(
            array('db'=>'xb_account', 'table'=>'users', 'field'=>'headimg', 'fromStr'=>'http://img.xiaobaijinfu.com', 'toStr'=>'https://img.xiaobaijinfu.com'),
            array('db'=>'xb_account', 'table'=>'users', 'field'=>'headimg', 'fromStr'=>'http://api.xiaobaijinfu.com', 'toStr'=>'https://api.xiaobaijinfu.com'),
            array('db'=>'xb_account','table'=>'users_invite_code','field'=>'qrcode_url'),
            array('db'=>'xb_account','table'=>'users_profile','field'=>'idcardImage1'),
            array('db'=>'xb_account','table'=>'users_profile','field'=>'idcardImage2'),
            array('db'=>'xb_account','table'=>'users_profile','field'=>'bankcardImage1'),
            array('db'=>'xb_account','table'=>'users_profile','field'=>'bankcardImage2'),
            array('db'=>'xb_act','table'=>'activity','field'=>'url'),
            array('db'=>'xb_mis','table'=>'merchant','field'=>'log'),
            array('db'=>'xb_mis','table'=>'merchant_app','field'=>'start_page'),
            array('db'=>'xb_mis','table'=>'merchant_app','field'=>'ios_download'),
            array('db'=>'xb_mis','table'=>'merchant_app','field'=>'and_download'),
            array('db'=>'xb_mis','table'=>'sharetheme','field'=>'shareimg'),
            array('db'=>'xb_mis','table'=>'sharetheme','field'=>'shareurl'),
         );

foreach ($array as $key => $value) {
    if(!isset($value['fromStr'])){
        $value['fromStr'] = 'http';
        $value['toStr']   = 'https';
    }
    $res_replace = XbModule_Account_Http2Https::getInstance()->http2https($value['db'], $value['table'], $value['field'], $value['fromStr'], $value['toStr']);
    if ($res_replace) {
        echo "修改表字段成功 ".$value['db'].".".$value['table']."---".$value['field']."\n";
    } else {
        echo "修改表字段失败 ".$value['db'].".".$value['table']."---".$value['field']."\n";
    }
}
echo "修改完毕 \n";
die();
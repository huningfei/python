<?php

$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", 'rls');

$merchant = XbModule_Merchant_Merchant::getInstance()->index();

if(count($merchant) > 0){
    $start = strtotime(date('Y-m-d',time()-3600*24));
    $end   = strtotime(date('Y-m-d',time()));
    foreach($merchant as $v){
        $orderInfo = XbModule_Account_Order::getInstance($v['id'])->getOrderByTime($start, $end);
        if(count($orderInfo) > 0){
            foreach($orderInfo as $v){
                $user = XbModule_Account_Users::getInstance()->getUserById($v['uid']);
                $res = XbModule_Account_Order::getInstance($v['id'])->updateOrderStatusHook($v['order_id'], $v['axf_order_no'], $user['mch_code'], $v['uid']);
            }
        }
    }
}
<?php

//设置进程名称，方便监控脚本检查运行状态
$process_title = 'php server.php: master';
if (function_exists('cli_set_process_title')) {
    cli_set_process_title($process_title);
}


$http = new swoole_http_server("0.0.0.0", 9501);
$http->set(array(
    'open_tcp_nodelay' => true,
    'daemonize' => 1,
    'log_file' => '/tmp/swoole_http_server.log',
    'log_level' => SWOOLE_LOG_INFO,
    'trace_flags' => SWOOLE_TRACE_ALL,
    'task_worker_num' => 8
));

$http->on('request', function ($request, $response) use ($http) {
    $taskId = $http->task(serialize($request->post));
    $response->end($taskId);
});
    
$http->on('task', function ($server, $task_id, $reactor_id, $data) {
    $data = unserialize($data);
    $cmd = $data['cmd'];
    $data = $data['data'];
    
    $cmd2Api = [
        'send_award' => 'https://api.xiaobaijinfu.com/AwardSend/sendAward',
        'excel_notice' => "https://m.xiaobaijinfu.com/Excel/importExecl"
    ];

    switch ($cmd) {
        case 'send_award':
            $url = $cmd2Api[$cmd];
            $curl_obj = curl_init();
            curl_setopt($curl_obj, CURLOPT_SSL_VERIFYPEER, FALSE);
            curl_setopt($curl_obj, CURLOPT_SSL_VERIFYHOST, FALSE);
            curl_setopt($curl_obj, CURLOPT_SSLVERSION, 1);
            curl_setopt($curl_obj, CURLOPT_URL, $url);
            curl_setopt($curl_obj, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl_obj, CURLOPT_POST, TRUE);
            curl_setopt($curl_obj, CURLOPT_POSTFIELDS, $data);
            
            $sContent = curl_exec($curl_obj);
            $aStatus = curl_getinfo($curl_obj);
            curl_close($curl_obj);
            break;
        case 'excel_notice':
            $url = $cmd2Api[$cmd] . '?id=' . $data['id'];
            $curl_obj = curl_init();
            curl_setopt($curl_obj, CURLOPT_SSL_VERIFYPEER, FALSE);
            curl_setopt($curl_obj, CURLOPT_SSL_VERIFYHOST, FALSE);
            curl_setopt($curl_obj, CURLOPT_SSLVERSION, 1);
            curl_setopt($curl_obj, CURLOPT_URL, $url);
            curl_setopt($curl_obj, CURLOPT_RETURNTRANSFER, 1 );
            
            $sContent = curl_exec($curl_obj);
            $aStatus = curl_getinfo($curl_obj);
            curl_close($curl_obj);
            break;
        default:
            $sContent = 'unkonwn';
            break;
    }
    
    $server->finish("$task_id -> OK: " . $sContent);
});
        
$http->on('finish', function ($server, $task_id, $data) {
    echo "[$task_id] finished: {$data}\n";
});

$http->start();
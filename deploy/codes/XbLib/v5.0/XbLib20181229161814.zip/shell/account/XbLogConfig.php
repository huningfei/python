<?php

return [
    //同一类错误，通知的最小时间间隔(最小10分钟)
    'alert_interval' => 1 * 60,
    
    //用户
    'users' => [
        'huqiang' => [
            'email' => 'huqiang@p2peye.com',
            'phone' => '18710031923',
        ],
        'zhuxuntao' => [
            'email' => 'zhuxuntao@p2peye.com',
            'phone' => '15101630800',
        ],
        'yanglijun' => [
            'email' => 'yanglijun@p2peye.com',
            'phone' => '15313380280',
        ],
        'zhangqiang' => [
            'email' => 'zhangqiang@p2peye.com',
            'phone' => '17610030699',
        ]
//        'test' => [
//            'email' => 'kl2001@163.com',
//            'phone' => '18016029156'
//        ]
    ],
    
    //用户组
    'user_group' => [
        'dev' => [
              'huqiang',
              'zhuxuntao',
              'yanglijun',
              'zhangqiang'
        ],
        'test' => [
            'test'
        ]
    ],
    
    //此处的用户会收到所有错误的通知（包括rule未定义的错误）
    'default' => [
        //通知的用户
        'user' => [],
        //通知的用户组
        'group' => ['dev'],
    ],
    
    //每隔类型错误需要通知的特殊用户
    'rule' => [
        //错误类型
        'upException' => [
            'name' => '数据更新异常',
            //通知的用户
            'user' => [],
            //通知的用户组
            'group' => [],
        ]
    ]
];
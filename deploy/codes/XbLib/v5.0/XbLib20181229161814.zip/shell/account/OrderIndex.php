<?php
/**
 * Created by PhpStorm.
 * User: yurong
 * Date: 2018/5/16
 * Time: 上午10:28
 */
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", empty($argv[1]) ? 'local' : $argv[1]);

$mch_id = 1;

$arrList = XbModule_Account_Order::getInstance($mch_id)->getAllOrder();
$str = '';

foreach ($arrList as $k => $v) {
    $index_data = array(
        ':order_table_num'  => $mch_id,
        ':order_table_id'   => $v['id'],
        ':order_id'         => $v['order_id'],
        ':uid'              => $v['uid'],
        ':create_time'      => $v['create_time']
    );
    $order_index = XbModule_Account_OrderIndex::getInstance()->createOrderIndex($index_data);
    if (!$order_index) {
        $str .= "失败: ".$v['id'] . "\n";
    }
}
var_dump($str);


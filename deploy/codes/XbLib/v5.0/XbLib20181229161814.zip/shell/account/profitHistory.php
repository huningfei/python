<?php

$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", 'rls');
error_reporting(E_ALL);

//获取订单支付成功并且is_profit= 0
$orders = XbModule_Account_Order::getInstance(1)->getIsProfitOrder(1531411200,0,1);
if($orders){
    foreach($orders as $key => $val){
        $res = XbModule_Account_Order::getInstance(1)->synOrderProfit($val['order_id'], $val['uid'], $val['rate'], $val['amount'], $val['id']);
        echo $val['order_id']."执行结果".$res."\n";
    }
}
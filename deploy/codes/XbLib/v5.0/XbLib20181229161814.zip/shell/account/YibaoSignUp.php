<?php
define('ROOT_PATH', '/home/yx/sites/xb_api');
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", 'rls');
$id = $argv[1]?$argv[1]:1;
$num = $argv[2]?$argv[2]:700;
$channel = new XbLib_Paychannel_Factory('yibao');
$yibao   = $channel->getPaychannelAdapter();
do{
    $userInfo = XbModule_Account_Users::getInstance()->getUserById($id);
    if($userInfo){
        $userChannel_code = XbModule_Account_UsersChannel::getInstance()->getUsersChannelCode($id, 1);
        if($userChannel_code){
            $id ++;
            continue;
        }
        $userProfile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($id);
        if(!$userProfile || $userProfile['status'] != 3){
            $id ++;
            continue;
        }

        //修改使用手机为预留手机
        $data    = array('phone'=> $userProfile['bankcard_phone']);
        $channelUserInfo = $yibao->buildSignData($data)->getUserData();
        if(!$channelUserInfo){
            $res = XbModule_Account_UsersChannel::getInstance()->signUpChannel($id);
            $id ++;
            continue;
        }
        $channelInfo = array(array('channel_id'=>1, 'channel_code'=>$channelUserInfo['retList'][0]['ledgeCustomerNumber']));
        XbModule_Account_UsersChannel::getInstance()->createChannelCode($id, $channelInfo);
    }
    $id++;
    if($id > $num){
        exit;
    }
}while(true);

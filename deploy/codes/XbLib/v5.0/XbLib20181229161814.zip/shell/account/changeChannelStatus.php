<?php
/**
 * Created by PhpStorm.
 * User: yurong
 * Date: 2018/5/16
 * Time: 上午10:28
 */
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", empty($argv[1]) ? 'local' : $argv[1]);
//获取前一天的通道关闭状态为其开启
    $end_time = strtotime(date("Y-m-d",strtotime("-1 day")).' 23:59:59');
$start_time = strtotime(date("Y-m-d",strtotime("-1 day")).' 00:00:00');
//获取前一天关闭的通道
$res = XbModule_Account_Channel::getInstance()->getChannelByUpdateTime($start_time,$end_time,6);

if($res){
    foreach($res as $key => $val){
        $res =  XbModule_Account_Channel::getInstance()->changChannelStatus($val['channel_id'],'20:18');
        XbFunc_Log::write('changeChannelStatus','通道ID【'.$val['channel_id'],'】变更状态结果'.$res);
    }

}
<?php
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", empty($argv[1]) ? 'rls' : $argv[1]);

$num = 10;
$page = 1;
do{
    $limit = ($page -1)*$num;
    $withdrawsBatch = XbModule_Account_Profit::getInstance(0)->getWithdrawBatch($limit, $num, false, 5);
    if($withdrawsBatch){
        foreach($withdrawsBatch as $k=>$v){
            $withdrawsBatch = XbModule_Account_Profit::getInstance(0)->searchWithdrawBatchResult($v['batchNo']);
        }
        $page++;
    }else{
        break;
    }
} while(true);
echo '查询批次状态';



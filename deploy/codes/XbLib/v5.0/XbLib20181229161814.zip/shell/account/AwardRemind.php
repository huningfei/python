<?php
/**
 * Created by PhpStorm.
 * User: yurong
 * Date: 2018/5/16
 * Time: 上午10:28
 */
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", empty($argv[1]) ? 'local' : $argv[1]);

//获取前一天未领取红包的数据
$status  = 1;
$time = time();
$date = strtotime(date('Y-m-d',$time));
$t  = 24*60*60;
$res = XbModule_Act_AwardItem::getInstance()->getAwardList($status);
if($res){
    $message = XbModule_Account_JpushApp::$message;
    $vp = new XbLib_Verification_PhoneCode();
    $type = 'awardremind';
    foreach($res as $key => $val){
        $res[$key]['count']  =0;
        if($val['count']==0){
            $deadline = strtotime(date('Y-m-d',$val['deadline']));
            if($deadline - $date == $t){
                //todo 发送红包过期提醒
//                //站内提醒
//                $title   = "您有".$val['money']."元红包 即将失效";
//                $content = "您的账户中有 ".$val['money']." 元的红包明天就失效了，立即点击领取吧";
//                XbModule_Account_JpushApp::getInstance()->addJpush($val['uid'],$title,$content,$type);
//                //微信模板提醒
//                $wxdata['uid']    =$val['uid'];
//                $wxdata['date']   = date('Y.m.d H:i',$time);
//                $wxdata['type']   = '返现红包';
//                $wxdata['status'] = '将于明天失效';
//                $wxdata['act']    = $val['title'];
//                $wxdata['detail'] = $val['act_type'] == 1?'办卡返现':'收款免费';
//                $res = XbLib_WechatTools_SendMsg::getInstance()->publicWxTemplateMsgSendFunc(13, $wxdata);

                //优化推送消息
                $res = XbLib_PushMsg::getInstance()->awardremind($val['uid'],array('item_id'=>$val['id']));

                //短信提醒
                //获取用户手机号
                $phone = XbModule_Account_Users::getInstance()->getUserById($val['uid'])['phone'];
                if($phone){
                    $checkType = $vp->set($type, $phone)->checkType($type);
                    if ($checkType instanceof XbLib_WebError) {
                        XbFunc_Log::write('award_remind','发送短信失败'.$checkType->getMessage());
                    }
                    $result = $vp->sendRemind($type,array('money'=>$val['money']));
                    if ($result instanceof XbLib_WebError) {
                        XbFunc_Log::write('award_remind','发送短信失败'.$result->getMessage());
                    }
                }else{
                    XbFunc_Log::write('award_remind','用户ID【'.$val['uid'].'】没有手机号');
                }
                $res[$key]['count'] =1;
            }else{
                echo $deadline-$date;
            }
        }else{
            echo "失败";
        }
    }
}
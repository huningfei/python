<?php
/**
 * 
 * @author wy
 * 2016-1-9
 * UTF-8
 */
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", 'rls');

// 资产分红后台程序
// 分红方式 1 对AB类投资者分红 2 对C类投资者分红 3 对ABC三类投资者分红
// 验证 投资人数大于0,分红人数大于0,分红金额大于0

// 1.获取待分红列表
$where = array();
$where['islock'] = 0;
$bonuslist = XbModule_Asset_BonusAssetRecord::getInstance()->getBonusAssetRecordAll($where);

if (! empty($bonuslist)) {
	// 2.修改待分红记录为lock状态
	$count = 0;
	foreach ($bonuslist as $key => $value) {
		$lock = array();
		$lock['id'] = $value['id'];
		$lock['islock'] = 1;
		$res = XbModule_Asset_BonusAssetRecord::getInstance()->UpdateBonusAssetRecordIsLock($lock);
		if (empty($res)) {
			$count += 1;
		}
	}
	// 判断是否有失败情况，如果失败取已经锁定状态的待分红记录
	if ($count > 0) {
		$where['islock'] = 1;
		$bonuslist = XbModule_Asset_BonusAssetRecord::getInstance()->getBonusAssetRecordAll($where);
	}
	
	// 循环待分红列表
	foreach ($bonuslist as $key => $value) {
		// 查询prop表,计算平台费，管理费
		$prop = XbModule_Asset_AssetProp::getInstance()->getAssetProp($value['aid']);
		if (empty($prop)) {
			// 记录日志
		    XbFunc_Log::write("bonus", "Error", "select  AssetProp  error,ID:[{$value['aid']}]");
			continue;
		}
		// 3.获取资产投资用户列表--验证投资人数
		$hold = array();
		$hold['aid'] = $value['aid'];
		$holdcount = XbModule_Asset_HoldingAssets::getInstance()->getHoldingAssetsCount($value['aid'], $hold);
		if (empty($holdcount)) {
			// 记录日志
		    XbFunc_Log::write("bonus", "Error", "select  Asset_Holding  error,ID:[{$value['aid']}]");
			continue;
		}
		
		//通过新浪接口待收企业分红金额，获取成功进行分红
		
		$A = 0.00;
		$B = 0.00;
		$C = 0.00;
		// 4.获取资产每个类型的投资总额和占比
		$holdgroup = XbModule_Asset_HoldingAssets::getInstance()->getHoldingAssetsGroup($value['aid']);
		foreach ($holdgroup as $holdkey => $holdvalue) {
			if ($holdvalue['risk_guarantee_type'] == 1) {
				$A = $holdvalue['amount'];
			}
			if ($holdvalue['risk_guarantee_type'] == 2) {
				$B = $holdvalue['amount'];
			}
			if ($holdvalue['risk_guarantee_type'] == 3) {
				$C = $holdvalue['amount'];
			}
		}
		// 占比
		$D = $A;
		$A = $A + $A * floatval($prop['guarantee_income']) / 100;
		$AF=floatval($prop['guarantee_income']) / 100;
		$total = $A + $B + $C;
		// 5.获取已经分红的总额
		$assettrack = XbModule_Asset_AssetTrack::getInstance()->getAssetTrack($value['aid']);
		$total_payback = $assettrack['total_payback'];
		
		$objbonus=bonus::getInstance();
		
		// 6.判断待分红以那种方式进行分配
		if ($total_payback >= $total) {
			// 分红方式3
			$objbonus->getBonus($value['id'], $value['amount'], 3, $total, $value['aid'], $D, $B, $C, $prop,$value['amount'],$AF);
		} else {
			if ($total_payback >= $A + $B) {
				if ($total_payback + floatval($value['amount']) <= $total) {
					// 分红方式2
					$objbonus->getBonus($value['id'], $value['amount'], 2, $C, $value['aid'], $D, $B, $C, $prop,$value['amount'],$AF);
				} else {
					// 分红方式3
					$Cbonus = $total_payback + floatval($value['amount']) - $total;
					$objbonus->getBonus($value['id'], $Cbonus, 3, $total, $value['aid'], $D, $B, $C, $prop,$value['amount'],$AF);
					// 分红方式2
					$ABbonus = floatval($value['amount']) - $Cbonus;
					$objbonus->getBonus($value['id'], $ABbonus, 2, $C, $value['aid'], $D, $B, $C, $prop,$value['amount'],$AF);
				}
			} else {
				if ($total_payback + floatval($value['amount']) <= $A + $B) {
					// 分红方式1
					$objbonus->getBonus($value['id'], $value['amount'], 1, $A + $B, $value['aid'], $D, $B, $C, $prop,$value['amount'],$AF);
				} else {
					// 分红方式2
					$Cbonus = $total_payback + floatval($value['amount']) - $A - $B;
					$objbonus->getBonus($value['id'], $Cbonus, 2, $C, $value['aid'], $D, $B, $C, $prop,$value['amount'],$AF);
					// 分红方式1
					$ABbonus = floatval($value['amount']) - $Cbonus;
					$objbonus->getBonus($value['id'], $ABbonus, 1, $A + $B, $value['aid'], $D, $B, $C, $prop,$value['amount'],$AF);
				}
			}
		}
		// 分红完成,修改资产已处置金额,修改待分红记录状态-解除lock
					$lock = array();
					$lock['id'] = $value['id'];
					$lock['islock'] = 2;
					$res = XbModule_Asset_BonusAssetRecord::getInstance()->UpdateBonusAssetRecord($lock, $value['aid'], $value['amount']);
					if (empty($res)) {
					    // 记录失败日志
					    XbFunc_Log::write("bonus", "Error", "Update  BonusAssetRecord error,ID:[{$value['id']}].AID:[{$value['aid']}].amount:[{$value['amount']}]");
					}
				
	}
}

/**
 * 分红操作类
 * 
 * @author yx
 *        
 */
class bonus
{
    private static $obj = null;
	/**
	 * 单例
	 * 
	 * @return XbModule_Asset_Asset
	 */
	public static function getInstance()
	{
		if (is_null(self::$obj)) {
			self::$obj = new bonus();
		}
		return self::$obj;
	}

	/**
	 * 分红方法
	 * $id 待分红记录id
	 * $amount 用户分红金额
	 * $type 分红方式
	 * $totalmoney 分类投资总额 $A+$B ,$C
	 * $aid 资产id
	 * $atotal A类总额
	 * $btotal B类总额
	 * $ctotal C类总额
	 * $prop 资产分配系数
	 * $amounttotal 分红总金额
	 * $AF  A类收益率
	 */
	public function getBonus($id, $amount, $type, $totalmoney, $aid, $atotal, $btotal, $ctotal, $prop,$amounttotal,$AF)
	{
	   // echo "分红方式:".$type."--------金额:".$amount."--------总金额:".$totalmoney."<br>";
		// 根据资产id,分红方式查询投资人列表
		$holdlist = XbModule_Asset_HoldingAssets::getInstance()->getHoldingAssetsByAidType($aid, $type);
		if (! empty($holdlist)) {
			if ($type == 1 || $type == 2) {
			    XbFunc_Log::write("bonus", "aid:{$aid},分红:{$amount}元,分红方式{$type}");
				foreach ($holdlist as $key => $value) {
				  //  echo "type:".$value['risk_guarantee_type']."--------金额:".$value['amount']."<br>";
					$famount = 0.00;
					// 根据分红方式计算分红金额--验证分红金额
					if($value['risk_guarantee_type']==1){
					    $famount = number_format(($value['amount']+$value['amount']*$AF) / $totalmoney * $amount , 2, '.', '');
					}else{
					    $famount = number_format($value['amount'] / $totalmoney * $amount, 2, '.', '');
					}
					if ($famount > 0) {
						// 添加用户分红记录bonus_user_record，添加用户交易记录表
					    $order_id = XbModule_Base_Order::getInstance()->getOrderId(8,$value['uid']);
						$userrecord = array();
						$userrecord['aid'] = $aid;
						$userrecord['uid'] = $value['uid'];
						$userrecord['baid'] = $id;
						$userrecord['type'] = $value['risk_guarantee_type'];
						$userrecord['trusteeship_status'] = 1;
						$userrecord['amount'] = $famount;
						$userrecord['order_id']=$order_id;
						$result = XbModule_Asset_BonusUserRecord::getInstance()->AddBonusUserRecord($userrecord);
						if (empty($result)) {
							// 记录失败日志
							XbFunc_Log::write("bonus", "Error", "ADD BonusUserRecord  error,AID:[{$aid}].UID:[{$value['uid']}].baid:[{$id}].Type:[{$value['risk_guarantee_type']}].trusteeship_status:[{1}].amount:[{$famount}]");
						}	
						
						//添加用户交易记录
						$userasset = XbModule_Account_UserAsset::getInstance()->getUserAssetByUid($value['uid']);
						$userbill = array();
						$userbill['uid'] = $value['uid'];
						$userbill['bef_total_debt'] = $userasset['total_debt'];
						$userbill['bef_total_income'] = $userasset['total_income'];
						$userbill['bef_total_invest'] = $userasset['total_invest'];
						$userbill['bef_total_asset_count'] = $userasset['total_asset_count'];
						$userbill['aft_total_debt'] = $userasset['total_debt'];
						$userbill['aft_total_income'] = $userasset['total_income'];
						$userbill['aft_total_invest'] = $userasset['total_invest'];
						$userbill['aft_total_asset_count'] = $userasset['total_asset_count'];
						$userbill['amount'] = $famount;
						$userbill['product_id'] = $aid;
						$userbill['order_id'] = $order_id;
						$userbill['type'] = 5; // 分红
						$userbill['desc'] = "资产" . $aid."分红".$famount . "元,分红时间:" . date("Y-m-d H:i:s",time());
						 
						$bill = new XbModel_Bill_UserBill();
						$resbill = $bill->addBill($userbill['uid'], $userbill['bef_total_debt'], $userbill['bef_total_income'], $userbill['bef_total_invest'], $userbill['bef_total_asset_count'], $userbill['aft_total_debt'], $userbill['aft_total_income'], $userbill['aft_total_invest'], $userbill['aft_total_asset_count'], $userbill['type'], $userbill['amount'], $userbill['product_id'], $userbill['order_id'], $userbill['desc']);
						if (empty($resbill)) {
						    $requestJson = json_encode($userbill);
						    XbFunc_Log::write("bonus", "adduserBill", "insert user_bill  error,userbill:[{$requestJson}]");
						}
						
						//修改用户分红总额
						$userassetmodel = array();
						$userassetmodel['uid'] = $value['uid'];
						$userassetmodel['total_income'] = $famount;
						
						$result=XbModule_Account_UserAsset::getInstance()->updateUserAsset($userassetmodel);
						if(empty($result)){
						    XbFunc_Log::write("bonus", "updateuserasset", "update user_asset  error,uid:[{$value['uid']}],famount:[{$famount}]");
						}
						//echo "aid:".$aid."-------------uid:".$value['uid']."----------------type:".$value['risk_guarantee_type']."------------amount:".$famount."</br>";
						// 7.调用新浪接口分账--进行付款
						$summary="托管代付";
						$configObj= XbModule_Tools_SinaPay::getInstance()->getConfigObj();
						$res=XbLib_SinaPay_Order::getInstance($configObj)->createSingleHostingPayTrade($order_id, $value['uid'],$famount , $summary,1);
						if(empty($res)){
						    XbFunc_Log::write("bonus", "Error", "createSingleHostingPayTrade  error,AID:[{$aid}].UID:[{$value['uid']}].baid:[{$id}].Type:[{$value['risk_guarantee_type']}].trusteeship_status:[{1}].amount:[{$famount}]");
						}
					}
				}
			}
			if ($type == 3) {
			    XbFunc_Log::write("bonus", "aid:{$aid},分红:{$amount}元,分红方式{$type}");
				$total = $atotal + $btotal + $ctotal;
				$AZ = $atotal / $total;
				$BZ = $btotal / $total;
				$CZ = $ctotal / $total;
				foreach ($holdlist as $key => $value) {
					$famount = 0.00;
					// 根据分红方式计算分红金额--验证分红金额
					if ($value['risk_guarantee_type'] == 1) {
						$famount = number_format($value['amount'] / $atotal * $AZ * $amount * $prop['risk_guarantee_principal'] / 100, 2, '.', '');
					}
					if ($value['risk_guarantee_type'] == 2) {
						$famount = number_format($value['amount'] / $btotal * $BZ * $amount * $prop['risk_guarantee_income'] / 100, 2, '.', '');
					}
					if ($value['risk_guarantee_type'] == 3) {
						$famount = number_format($value['amount'] / $ctotal * $CZ * $amount 
						    + $value['amount'] / $ctotal * ($AZ * $amount * (1 - $prop['risk_guarantee_principal'] / 100))
						     + $value['amount'] / $ctotal * ($BZ * $amount * (1 - $prop['risk_guarantee_income'] / 100)), 2, '.', '');
					}
					if ($famount > 0) {
						// 添加用户分红记录bonus_user_record，添加用户交易记录表
					    $order_id = XbModule_Base_Order::getInstance()->getOrderId(8,$value['uid']);
						$userrecord = array();
						$userrecord['aid'] = $aid;
						$userrecord['uid'] = $value['uid'];
						$userrecord['baid'] = $id;
						$userrecord['type'] = $value['risk_guarantee_type'];
						$userrecord['trusteeship_status'] = 1;
						$userrecord['amount'] = $famount;
						$userrecord['order_id']=$order_id;
						$result = XbModule_Asset_BonusUserRecord::getInstance()->AddBonusUserRecord($userrecord);
						if (empty($result)) {
							// 记录失败日志
							XbFunc_Log::write("bonus", "Error", "ADD BonusUserRecord  error,AID:[{$aid}].UID:[{$value['uid']}].baid:[{$id}].Type:[{$value['risk_guarantee_type']}].trusteeship_status:[{1}].amount:[{$famount}]");
				    	}
				    	
				    	//添加用户交易记录
				    	$userasset = XbModule_Account_UserAsset::getInstance()->getUserAssetByUid($value['uid']);
				    	$userbill = array();
				    	$userbill['uid'] = $value['uid'];
				    	$userbill['bef_total_debt'] = $userasset['total_debt'];
				    	$userbill['bef_total_income'] = $userasset['total_income'];
				    	$userbill['bef_total_invest'] = $userasset['total_invest'];
				    	$userbill['bef_total_asset_count'] = $userasset['total_asset_count'];
				    	$userbill['aft_total_debt'] = $userasset['total_debt'];
				    	$userbill['aft_total_income'] = $userasset['total_income'];
				    	$userbill['aft_total_invest'] = $userasset['total_invest'];
				    	$userbill['aft_total_asset_count'] = $userasset['total_asset_count'];
				    	$userbill['amount'] = $famount;
				    	$userbill['product_id'] = $aid;
				    	$userbill['order_id'] = $order_id;
				    	$userbill['type'] = 5; // 分红
				    	$userbill['desc'] = "资产" . $aid."分红".$famount . "元,分红时间:" . date("Y-m-d H:i:s",time());
				    		
				    	$bill = new XbModel_Bill_UserBill();
				    	$resbill = $bill->addBill($userbill['uid'], $userbill['bef_total_debt'], $userbill['bef_total_income'], $userbill['bef_total_invest'], $userbill['bef_total_asset_count'], $userbill['aft_total_debt'], $userbill['aft_total_income'], $userbill['aft_total_invest'], $userbill['aft_total_asset_count'], $userbill['type'], $userbill['amount'], $userbill['product_id'], $userbill['order_id'], $userbill['desc']);
				    	if (empty($resbill)) {
				    	    $requestJson = json_encode($userbill);
				    	    XbFunc_Log::write("bonus", "adduserBill", "insert user_bill  error,userbill:[{$requestJson}]]");
				    	}
				    	//修改用户分红总额
				    	$userassetmodel = array();
				    	$userassetmodel['uid'] = $value['uid'];
				    	$userassetmodel['total_income'] = $famount;
				    	
				    	$result=XbModule_Account_UserAsset::getInstance()->updateUserAsset($userassetmodel);
				    	if(empty($result)){
				    	    XbFunc_Log::write("bonus", "updateuserasset", "update user_asset  error,uid:[{$value['uid']}],famount:[{$famount}]");
				    	}
				    	//echo "aid:".$aid."-------------uid:".$value['uid']."----------------type:".$value['risk_guarantee_type']."------------amount:".$famount."</br>";
						// 7.调用新浪接口分账-进行付款
				    	$summary="托管代付";
				    	$configObj= XbModule_Tools_SinaPay::getInstance()->getConfigObj();
				    	$res=XbLib_SinaPay_Order::getInstance($configObj)->createSingleHostingPayTrade($order_id, $value['uid'],$famount , $summary,1);
				    	if(empty($res)){
				    	    XbFunc_Log::write("bonus", "Error", "createSingleHostingPayTrade  error,AID:[{$aid}].UID:[{$value['uid']}].baid:[{$id}].Type:[{$value['risk_guarantee_type']}].trusteeship_status:[{1}].amount:[{$famount}]");
				    	}
					}
				}
			}
		}
	}

}
          

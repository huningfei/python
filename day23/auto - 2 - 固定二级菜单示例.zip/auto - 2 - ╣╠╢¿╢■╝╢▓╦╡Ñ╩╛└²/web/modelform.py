from django.forms import ModelForm

from web import models


class OrderModelForm(ModelForm):
    class Meta:
        models = models.Order
        fields = "__all__"

        # error_messages = {  # 设置每个字段的报错提示信息
        #     "name": {
        #         "required": "订单名字不能为空"
        #     },
        # }

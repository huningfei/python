from django.apps import AppConfig


class RbacConfig(AppConfig):
    name = 'rbac'

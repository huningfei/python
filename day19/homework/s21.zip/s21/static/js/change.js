$(".login-box input").focus(function () {
    $(".error_old").text("");
    $(".error_new").text("")


    }
);


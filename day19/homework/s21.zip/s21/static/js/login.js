$(".login-box input").focus(function () {
    $(".error_msg").text("");

    }
);